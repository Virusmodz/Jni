#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include <cmath>   // C++ math functions (atan2, etc.)
#include <cfloat> // For FLT_MAX
#include <unordered_set>
#include <cstdlib>

//Target lib here
#define targetLibName OBFUSCATE("libcocos2dcpp.so")

#include "Includes/Macros.h"

static float hpvalue = 0.0f;  // Initialize to prevent garbage values

float isboost = 0;

bool isteleport;

// --- Global Settings ---
bool isAimbot, automille;

constexpr float PI_F = 3.14159265358979323846f;
constexpr float RAD2DEG = 180.0f / PI_F;

int (*getTeamId)(void* instance); // get players team id like 1 to 7, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead


using namespace std;

unordered_set<void *> playerslist;

// --- Data Structures ---
// We need to store the "Winner" of the distance tournament
// --- Data Structures ---
void* enemyPlayers = NULL;
void* localPlayer = NULL;
void* currentTarget = NULL;    // The locked target
void* bestCandidate = NULL;    // The candidate being calculated
float closestDistSq = FLT_MAX; // Use Squared Distance for performance

// Cached local player data (Performance optimization)
int cachedLocalTeam = -1;
float cachedLocalX = 0.0f;
float cachedLocalY = 0.0f;

// --- Function Pointers ---

float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);

void teleporting(){
	
		
		if (playerslist.empty() || !isteleport) {
          return; // Nothing to do
          }
		size_t size = playerslist.size();
		int random_steps = rand() % size; // Use rand() for simplicity for now

         // 3. Jump the Iterator to the Random Target
          auto it = playerslist.begin();
          // std::advance moves the iterator forward by 'random_steps' steps
        std::advance(it, random_steps); 

		
         // 4. Get the target
        void* randomTarget = *it;
		if (!isdead(randomTarget) || gethp(randomTarget) > 0){
		if (randomTarget ){
			void* targetBody = *(void **)((char *)randomTarget + 0x148);
           if (targetBody != NULL){
           float targetX = *(float *)((char *)targetBody + 0x2c);
		   float targetY = *(float *)((char *)targetBody + 0x34);
		   void *body = *(void **)((char *)localPlayer + 0x148);
     if (body != NULL) {

        float *posX = (float *)((char *)body + 0x2c);
        float *posY = (float *)((char *)body + 0x34);
           
          *posX = targetX;
          *posY = targetY;
          
                 isteleport = false;
                        
               }
               
			}
		}
		}
		
	}
	
// --- 1. LOCAL CONTROLLER (The Reset & Cache) ---
void (*old_SoldierLocalController)(void* instance ,float dt);
void SoldierLocalController(void *instance, float dt){
    if (instance != NULL) {
        localPlayer = instance;
      

        // 1. Lock in the target found in the previous frame
        currentTarget = bestCandidate;

        // 2. Reset calculations for this new frame
        closestDistSq = FLT_MAX; 
        bestCandidate = NULL;

        // 3. Cache local data (Optimization: Call these once per frame, not per enemy)
        if (getTeamId) cachedLocalTeam = getTeamId(instance);
        if (GetPositionX) cachedLocalX = GetPositionX(instance);
        if (GetPositionY) cachedLocalY = GetPositionY(instance);
    } else {
        localPlayer = NULL; // Safety reset
    }
    return old_SoldierLocalController(instance, dt);
} 



void (*old_removebody)(void* instance);
void removebody(void* instance){
if (instance != NULL){
old_removebody(instance);
playerslist.clear();

} 
return old_removebody(instance);
} 

// --- 2. REMOTE CONTROLLER (The Filter) ---
void (*old_SoldierRemoteController)(void* instance, float dt);
void SoldierRemoteController(void* instance, float dt){
    // Validation checks
    if (instance != NULL) {
    
    
	
    if (getTeamId(localPlayer) > 1 && getTeamId(localPlayer) != getTeamId(instance) && !isdead(instance) || gethp(instance) > 0) {
          enemyPlayers = instance;
    playerslist.insert(instance);
    } else if (!isdead(instance) || gethp(instance) > 0) {
    playerslist.insert(instance);
    enemyPlayers = instance;
    }
	
    	if(isteleport){
		teleporting();
		
	}
	
    
    
    
    
    if (localPlayer != NULL && isAimbot) {
        
        // Team Check
        int remoteTeam = getTeamId(instance);
        
        // If it's a teammate (and not solo mode), skip logic
        if (cachedLocalTeam > 1 && cachedLocalTeam == remoteTeam) {
            return old_SoldierRemoteController(instance, dt);
        }

        // Get Enemy Position
        float enX = GetPositionX(instance);
        float enY = GetPositionY(instance);

        // Calculate Difference
        float dx = cachedLocalX - enX;
        float dy = cachedLocalY - enY;

        // Optimization: Use Squared Distance (removes sqrtf)
        float distSq = (dx * dx) + (dy * dy);

        // Determine if this is the new best candidate
        if (distSq < closestDistSq) {
            // Optional: Add HP check here (ignore dead bodies early)   
                closestDistSq = distSq;
                bestCandidate = instance;
               
            
        }
    } 
 }

    return old_SoldierRemoteController(instance, dt);
} 

// --- 3. FIRE ANGLE (The Action) ---
float (*old_FireAngle)(void* instance);
float FireAngle(void* instance) {
    if (isAimbot && instance != NULL && localPlayer != NULL && currentTarget != NULL) {
        
        // Double check target validity to prevent shooting at ghosts
        if (!isdead(currentTarget) || gethp(currentTarget) > 0) {
            
            // Recalculate positions based on cached local or fresh local
            // Using fresh local here ensures aim is perfectly synced with rendering
            float px = GetPositionX(localPlayer);
            float py = GetPositionY(localPlayer);
            
            float ex = GetPositionX(currentTarget);
            float ey = GetPositionY(currentTarget);

            float dx = ex - px;
            float dy = py - ey;
            
            // Calculate Angle
            float angleRad = atan2f(dy, dx);
            float angleDeg = angleRad * RAD2DEG; 
            
            // Standardize 0-360
            if (angleDeg < 0) angleDeg += 360.0f;

            return angleDeg;
        }
    }
    
    return old_FireAngle(instance);
}

void (*punch)(void* instance);

void (*old_hud)(void* instance, float dt);
void hud(void* instance, float dt) {
     
     if (instance != NULL){
       if (automille){
       float mypy = GetPositionY(localPlayer);
       float mypx = GetPositionX(localPlayer);
       
       float enpy = GetPositionY(enemyPlayers);
       float enpx = GetPositionX(enemyPlayers);
       
       float dy = enpy - mypy;
       float dx = enpx - mypx;
       
       float distSq = (dx * dx) + (dy * dy);
        
        if (distSq < 400){
        punch(instance);
          
           }
        }
     }
 return old_hud(instance, dt);
}



float (*old_halte)(void *instance);  // Must be nullptr-initialized

float halte(void *instance) {
    if (instance != NULL) {
        // Capture AND return the original value
        hpvalue = old_halte(instance);
        
    }
    // Always chain to original function
    return old_halte(instance);
}


float (*old_boost)(void *instance);
float Boost(void *instance){
    if (instance != NULL){
        
        isboost = old_boost(instance);
        
        
    }
    return old_boost(instance);
}


std::string (*old_pacage)(void* instance);
std::string pacage(void* instance){
  if (instance != NULL){
  
  
  }
 return old_pacage(instance);
}


// JNI function remains the same
extern "C" JNIEXPORT jstring JNICALL
Java_com_android_support_Menu_Halthe(JNIEnv *env, jobject context) {
    int intValue = static_cast<int>(hpvalue);
    std::string anyString = std::to_string(intValue); 
    return env->NewStringUTF(anyString.c_str());
}



extern "C" JNIEXPORT jstring JNICALL
Java_com_android_support_Menu_Boostis(JNIEnv *env, jobject context) {
    int intValue = static_cast<int>(isboost);
    std::string anyString = std::to_string(intValue); 
    return env->NewStringUTF(anyString.c_str());
}






















// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    

    

#else //To compile this code for armv7 lib only.
MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x7ad9cc), (void *) halte, (void **) &old_halte);

HOOK_LIB("libcocos2dcpp.so", "0x7a4108", Boost, old_boost);

HOOK_LIB("libcocos2dcpp.so", "0x7a5170", SoldierLocalController, old_SoldierLocalController);

HOOK_LIB("libcocos2dcpp.so", "0x7b2d48", SoldierRemoteController, old_SoldierRemoteController);

HOOK_LIB("libcocos2dcpp.so", "0x5156b8", FireAngle, old_FireAngle);

getTeamId = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x4361e0); 
gethp = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1b8); 
isdead = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1f8); 
HOOK_LIB("libcocos2dcpp.so", "0x79e224", removebody, old_removebody);
HOOK_LIB("libcocos2dcpp.so", "0x8767d4", pacage, old_pacage);

GetPositionX = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c791); 
GetPositionY = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c79f); 

HOOK_LIB("libcocos2dcpp.so", "0x4fa4b4", hud, old_hud);

punch = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x4f50c4); 


    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    

    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
    /*if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;Boostview
        *p = 0;
    }*/

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_Player info"), //Not counted
            OBFUSCATE("Halteview_Health"),
            OBFUSCATE("Boostview_Boost"),
            
            OBFUSCATE("Category_Aimbot"), //Not counted
            OBFUSCATE("1_Toggle_AIMBOT"),
            OBFUSCATE("2_Button_Teleport"),
            
            OBFUSCATE("3_Toggle_Auto Punch1"),
            
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
       case 1:
    isAimbot = boolean;
          break;
    case 2:
    isteleport = true;
    break;
    case 3:
    automille = boolean;
    break;
    }
}

__attribute__((constructor))
void lib_main() {
    initCrashHandler();
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

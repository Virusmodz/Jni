#include <jni.h>
#include <android/log.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <cstring>
#include <string>
#include <vector>
#include <queue>
#include <mutex>
#include <thread>
#include <condition_variable>
#include <sstream>
#include <iomanip>
#include <memory>

// --- Configuration ---
#define TAG "GhostLogger" // Logcat Tag
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

// Target classes to dump
static const std::vector<std::string> TARGET_CLASSES = {
    "android.support.v4.app.sc.zNTerGgXH",
    "android.support.v4.media.session.iI.ECiAjKIV",
    "android.support.v4.media.session.iI.VZSJxYCf"
};

// Global JVM reference
static JavaVM* g_vm = nullptr;

// --- Utils: Time & String ---
static std::string getCurrentTimeFormatted() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    std::stringstream ss;
    ss << std::put_time(std::localtime(&in_time_t), "%Y%m%d_%H%M%S");
    return ss.str();
}

static std::string escapeJsonString(const std::string& s) {
    std::ostringstream o;
    for (char c : s) {
        switch (c) {
            case '"': o << "\\\""; break;
            case '\\': o << "\\\\"; break;
            case '\b': o << "\\b"; break;
            case '\f': o << "\\f"; break;
            case '\n': o << "\\n"; break;
            case '\r': o << "\\r"; break;
            case '\t': o << "\\t"; break;
            default:
                if ('\x00' <= c && c <= '\x1f') {
                    o << "\\u" << std::hex << std::setw(4) << std::setfill('0') << (int)c;
                } else {
                    o << c;
                }
        }
    }
    return o.str();
}

// --- Component: Async Logger (Thread-Safe) ---
class AsyncLogger {
private:
    std::queue<std::string> queue_;
    std::mutex mutex_;
    std::condition_variable cond_;
    std::thread worker_;
    bool running_;
    int fd_;

    void openLogFile() {
        // Try standard sdcard
        std::string dir = "/sdcard/MT2/dictionary/";
        // Recursive mkdir is painful in C, utilizing simple system calls for now
        mkdir("/sdcard/MT2", 0755);
        mkdir(dir.c_str(), 0755);
        
        std::string path = dir + "log_" + getCurrentTimeFormatted() + ".json";
        fd_ = open(path.c_str(), O_CREAT | O_WRONLY | O_APPEND, 0644);

        if (fd_ < 0) {
            // Fallback to internal app data if sdcard fails (Android 11+ Scoped Storage)
            LOGE("Failed to open sdcard path. Trying fallback.");
            mkdir("/data/data/com.pittvandewitt.wavelet/dictionary", 0755);
            std::string fallback = "/data/data/com.pittvandewitt.wavelet/dictionary/log_" + getCurrentTimeFormatted() + ".json";
            fd_ = open(fallback.c_str(), O_CREAT | O_WRONLY | O_APPEND, 0666);
        }
        
        if (fd_ >= 0) LOGD("Logging started at: %s", path.c_str());
    }

    void processQueue() {
        openLogFile();
        while (running_) {
            std::unique_lock<std::mutex> lock(mutex_);
            cond_.wait(lock, [this] { return !queue_.empty() || !running_; });

            while (!queue_.empty()) {
                std::string msg = queue_.front();
                queue_.pop();
                lock.unlock(); // Release lock while writing I/O

                if (fd_ >= 0) {
                    write(fd_, msg.c_str(), msg.size());
                    write(fd_, "\n", 1); // Add newline
                } else {
                    LOGD("FILE WRITE: %s", msg.c_str()); // Fallback to logcat
                }

                lock.lock();
            }
        }
        if (fd_ >= 0) close(fd_);
    }

public:
    AsyncLogger() : running_(true), fd_(-1) {
        worker_ = std::thread(&AsyncLogger::processQueue, this);
    }

    ~AsyncLogger() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            running_ = false;
        }
        cond_.notify_all();
        if (worker_.joinable()) worker_.join();
    }

    // Singleton instance
    static AsyncLogger& get() {
        static AsyncLogger instance;
        return instance;
    }

    void log(const std::string& entry) {
        std::lock_guard<std::mutex> lock(mutex_);
        queue_.push(entry);
        cond_.notify_one();
    }
};

// --- Component: JNI Helper (RAII) ---
class JniHelper {
public:
    static std::string toString(JNIEnv* env, jobject obj) {
        if (!obj) return "null";
        
        // Handle Byte Arrays specifically
        if (env->IsInstanceOf(obj, env->FindClass("[B"))) {
            return byteArrayToString(env, (jbyteArray)obj);
        }

        jclass cls = env->GetObjectClass(obj);
        jmethodID toStringID = env->GetMethodID(cls, "toString", "()Ljava/lang/String;");
        jstring jStr = (jstring)env->CallObjectMethod(obj, toStringID);
        
        if (!jStr) return "null";
        
        const char* chars = env->GetStringUTFChars(jStr, nullptr);
        std::string result(chars);
        env->ReleaseStringUTFChars(jStr, chars);
        env->DeleteLocalRef(jStr);
        env->DeleteLocalRef(cls);
        return result;
    }

    static std::string getStackTraceLocation(JNIEnv* env) {
        // PERF: This is heavy. Use sparingly.
        // We catch exceptions to prevent crashes during logging
        if (env->ExceptionCheck()) env->ExceptionClear();

        jclass threadCls = env->FindClass("java/lang/Thread");
        jmethodID currentThreadID = env->GetStaticMethodID(threadCls, "currentThread", "()Ljava/lang/Thread;");
        jobject currentThread = env->CallStaticObjectMethod(threadCls, currentThreadID);

        jmethodID getStackTraceID = env->GetMethodID(threadCls, "getStackTrace", "()[Ljava/lang/StackTraceElement;");
        jobjectArray stackTrace = (jobjectArray)env->CallObjectMethod(currentThread, getStackTraceID);

        if (!stackTrace) return "Unknown:0";

        // Skip standard index (Native Method -> Thread.getStackTrace -> YourLogMethod -> Caller)
        // Usually index 3 or 4 is the caller.
        int depth = 4;
        if (env->GetArrayLength(stackTrace) <= depth) depth = 0;
        
        jobject element = env->GetObjectArrayElement(stackTrace, depth);
        if (!element) return "Unknown:0";

        jclass steCls = env->FindClass("java/lang/StackTraceElement");
        jmethodID toStringID = env->GetMethodID(steCls, "toString", "()Ljava/lang/String;");
        jstring val = (jstring)env->CallObjectMethod(element, toStringID);
        
        const char* raw = env->GetStringUTFChars(val, nullptr);
        std::string res = raw ? raw : "Unknown";
        
        if (raw) env->ReleaseStringUTFChars(val, raw);
        
        // Cleanup locals
        env->DeleteLocalRef(threadCls);
        env->DeleteLocalRef(currentThread);
        env->DeleteLocalRef(stackTrace);
        env->DeleteLocalRef(element);
        env->DeleteLocalRef(steCls);
        env->DeleteLocalRef(val);

        return res;
    }

private:
    static std::string byteArrayToString(JNIEnv* env, jbyteArray arr) {
        jsize len = env->GetArrayLength(arr);
        jbyte* bytes = env->GetByteArrayElements(arr, nullptr);
        std::string res = "[";
        for (int i = 0; i < len; ++i) {
             res += std::to_string((int)bytes[i]) + (i < len - 1 ? "," : "");
        }
        res += "]";
        env->ReleaseByteArrayElements(arr, bytes, 0);
        return res;
    }
};

// --- Component: Dumper ---
void dumpStaticStrings(JNIEnv* env, jclass cld, const std::string& className) {
    jclass clazz = env->FindClass("java/lang/Class");
    jmethodID getDeclaredFields = env->GetMethodID(clazz, "getDeclaredFields", "()[Ljava/lang/reflect/Field;");
    jobjectArray fields = (jobjectArray)env->CallObjectMethod(cld, getDeclaredFields);

    if (!fields) return;

    jclass fieldClass = env->FindClass("java/lang/reflect/Field");
    jmethodID setAccessible = env->GetMethodID(fieldClass, "setAccessible", "(Z)V");
    jmethodID get = env->GetMethodID(fieldClass, "get", "(Ljava/lang/Object;)Ljava/lang/Object;");
    jmethodID getName = env->GetMethodID(fieldClass, "getName", "()Ljava/lang/String;");
    jmethodID getType = env->GetMethodID(fieldClass, "getType", "()Ljava/lang/Class;");
    
    // For checking static modifier
    jmethodID getModifiers = env->GetMethodID(fieldClass, "getModifiers", "()I");
    jclass modClass = env->FindClass("java/lang/reflect/Modifier");
    jmethodID isStaticID = env->GetStaticMethodID(modClass, "isStatic", "(I)Z");

    int len = env->GetArrayLength(fields);
    for (int i = 0; i < len; i++) {
        jobject field = env->GetObjectArrayElement(fields, i);
        
        // Check if Static
        int mods = env->CallIntMethod(field, getModifiers);
        if (!env->CallStaticBooleanMethod(modClass, isStaticID, mods)) {
             env->DeleteLocalRef(field); continue; 
        }

        // Check if String type
        jobject typeCls = env->CallObjectMethod(field, getType);
        jmethodID typeNameMethod = env->GetMethodID(clazz, "getName", "()Ljava/lang/String;");
        jstring typeNameJ = (jstring)env->CallObjectMethod(typeCls, typeNameMethod);
        const char* typeNameC = env->GetStringUTFChars(typeNameJ, nullptr);
        bool isString = (strcmp(typeNameC, "java.lang.String") == 0);
        env->ReleaseStringUTFChars(typeNameJ, typeNameC);
        
        if (isString) {
            env->CallVoidMethod(field, setAccessible, JNI_TRUE);
            
            // Get Field Name
            jstring fnameJ = (jstring)env->CallObjectMethod(field, getName);
            const char* fnameC = env->GetStringUTFChars(fnameJ, nullptr);
            std::string fieldName = fnameC;
            env->ReleaseStringUTFChars(fnameJ, fnameC);

            // Get Value (Pass null for static fields)
            jobject valObj = env->CallObjectMethod(field, get, nullptr);
            std::string valStr = JniHelper::toString(env, valObj);

            // Log it
            std::stringstream json;
            json << "{\"class\": \"" << className << "\", \"field\": \"" << fieldName 
                 << "\", \"value\": \"" << escapeJsonString(valStr) << "\"}";
            
            AsyncLogger::get().log(json.str());
            
            if (valObj) env->DeleteLocalRef(valObj);
        }
        
        env->DeleteLocalRef(field);
        env->DeleteLocalRef(typeCls);
        env->DeleteLocalRef(typeNameJ);
    }
}

// --- Main Logic ---

extern "C" JNIEXPORT void JNICALL mt_logstring(JNIEnv* env, jobject obj) {
    std::string val = JniHelper::toString(env, obj);
    std::string loc = JniHelper::getStackTraceLocation(env);
    
    std::stringstream ss;
    ss << "{\"location\": \"" << loc << "\", \"result\": \"" << escapeJsonString(val) << "\"}";
    
    AsyncLogger::get().log(ss.str());
}

// Background thread to find the classloader and dump classes
void dumpThreadTask() {
    JNIEnv* env;
    if (g_vm->AttachCurrentThread(&env, nullptr) != JNI_OK) return;

    LOGD("Dump thread started...");
    
    // 1. Get Application ClassLoader via ActivityThread
    // This is robust for most Android versions
    jclass activityThreadCls = env->FindClass("android/app/ActivityThread");
    jmethodID currentAppMethod = env->GetStaticMethodID(activityThreadCls, "currentApplication", "()Landroid/app/Application;");
    
    jobject app = nullptr;
    int retries = 0;
    
    // Wait for App to initialize
    while (retries < 50) {
        app = env->CallStaticObjectMethod(activityThreadCls, currentAppMethod);
        if (app) break;
        usleep(200000); // 200ms
        retries++;
    }

    if (app) {
        jclass appCls = env->GetObjectClass(app);
        jmethodID getClassLoader = env->GetMethodID(appCls, "getClassLoader", "()Ljava/lang/ClassLoader;");
        jobject classLoader = env->CallObjectMethod(app, getClassLoader);
        
        jclass classLoaderCls = env->FindClass("java/lang/ClassLoader");
        jmethodID loadClassMethod = env->GetMethodID(classLoaderCls, "loadClass", "(Ljava/lang/String;)Ljava/lang/Class;");

        for (const auto& className : TARGET_CLASSES) {
            jstring nameJ = env->NewStringUTF(className.c_str());
            
            // Try Loading Class
            jclass targetCls = (jclass)env->CallObjectMethod(classLoader, loadClassMethod, nameJ);
            
            if (targetCls) {
                LOGD("Dumping class: %s", className.c_str());
                dumpStaticStrings(env, targetCls, className);
            } else {
                LOGE("Failed to find class: %s", className.c_str());
                if (env->ExceptionCheck()) env->ExceptionClear(); // Don't crash
            }
            
            env->DeleteLocalRef(nameJ);
            if (targetCls) env->DeleteLocalRef(targetCls);
        }
    } else {
        LOGE("Could not get Context/Application!");
    }

    g_vm->DetachCurrentThread();
}

jint JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    
    // Start Dump Thread detached
    std::thread t(dumpThreadTask);
    t.detach();

    return JNI_VERSION_1_6;
}

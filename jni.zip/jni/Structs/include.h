#ifndef STRUCT_H
#define STRUCT_H
#include "classes.h"
#include "Object.h"
#include "Physics.h"
#include "Component.h"
#include "GameObject.h"
#include "Application.h"
#include "il2cpp.h"
#include "Transform.h"
#include "Camera.h"
#include "String.h"
#include "Time.h"
#include "Screen.h"
#include "Display.h"
#include "SceneManager.h"
#endif

namespace Structs {
    class String;
    class Application;
    class Camera;
    class Physics;
    class Component;
    class Transform;
    class Object;
    class GameObject;
    class Time;
    class SceneManager;
}

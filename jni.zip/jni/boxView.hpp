
std::string DisplayText = "checking...";

std::string Debugtext = "Log..";


    
extern "C"
JNIEXPORT jstring JNICALL
Java_com_android_support_BoxView_BoxText(JNIEnv *env, jobject thiz) {

    return env->NewStringUTF(DisplayText.c_str());
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_android_support_BoxView_GetDbugText(JNIEnv *env, jobject thiz) {

    std::string snapshot = GetDebugTextSnapshot();
    return env->NewStringUTF(snapshot.c_str());
}
/*

jstring BoxText(JNIEnv *env, jobject thiz) {
    return env->NewStringUTF(DisplayText);
}

*/

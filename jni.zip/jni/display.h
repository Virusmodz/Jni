
std::string value11 = "";


bool isdisplayvalue;



std::string (*org_getStringData)(void *p);
std::string getStringData(void *p) {
	
	if (p && isdisplayvalue){
		value11 = org_getStringData(p);
		
	}
	
	return org_getStringData(p);
}

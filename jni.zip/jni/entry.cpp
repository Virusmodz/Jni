#include <jni.h>
#include "dex.h"

JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void*) {

    JNIEnv* env = nullptr;
    if (vm->GetEnv((void**)&env, JNI_VERSION_1_6) != JNI_OK)
        return JNI_ERR;

    a(env);
    return JNI_VERSION_1_6;
}

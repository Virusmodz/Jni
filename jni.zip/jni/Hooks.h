//Component -> public Transform get_transform() { }
void *getTransform(void *player) {
    if (!player) return NULL;
    static const auto get_transform_injected = reinterpret_cast<uint64_t(__fastcall *)(void *)>(getAbsoluteAddress("libil2cpp.so", 0x0));
    return (void *) get_transform_injected(player);
}

//Transform -> get_position_Injected(out Vector3 ret) { }
Vector3 get_position(void *transform) {
    if (!transform)return Vector3();
    Vector3 position;
    static const auto get_position_injected = reinterpret_cast<uint64_t(__fastcall *)(void *,Vector3 &)>(getAbsoluteAddress("libil2cpp.so", 0x0));
    get_position_injected(transform, position);
    return position;
}

//Transform -> set_position_Injected(ref Vector3 value) { }
void set_position(void* transform, Vector3 test) {
    if (transform) {
        static const auto set_position_injected = reinterpret_cast<uintptr_t(__fastcall*)(void*, Vector3)>(getAbsoluteAddress("libil2cpp.so", 0x0));
        set_position_injected(transform, test);
    }
}

//Transform -> set_localScale_Injected(ref Vector3 value) { }
void set_localScale(void* transform, Vector3 test) {
    if (transform) {
        static const auto set_localScale_injected = reinterpret_cast<uintptr_t(__fastcall*)(void*, Vector3)>(getAbsoluteAddress("libil2cpp.so", 0x0));
        set_localScale_injected(transform, test);
    }
 }

//Camera -> private void WorldToScreenPoint_Injected(ref Vector3 position, Camera.MonoOrStereoscopicEye eye, out Vector3 ret) { }
Vector3 WorldToScreenPoint(void *transform, Vector3 test) {
    if (!transform)return Vector3();
    Vector3 position;
    static const auto WorldToScreenPoint_Injected = reinterpret_cast<uint64_t(__fastcall *)(void *,Vector3, int, Vector3 &)>(getAbsoluteAddress("libil2cpp.so", 0x0));
    WorldToScreenPoint_Injected(transform, test, 4, position);
    return position;
}

//Camera -> public static Camera get_main() { }
void *get_camera() {
    static const auto get_camera_injected = reinterpret_cast<uint64_t(__fastcall *)()>(getAbsoluteAddress("libil2cpp.so", 0x0));
    return (void *) get_camera_injected();
}

Vector3 GetPlayerLocation(void *player) {
    return get_position(getTransform(player));
}

 //ZombieBase -> public double get_totalHP() { }
/*double GetMaxHealth(void *player) {
    if (!player) return NULL;
    static const auto get_InitialHealth = reinterpret_cast<double (*) (void *)>(getAbsoluteAddress("libil2cpp.so", 0x1D2BA20));
    return (double) get_InitialHealth(player);
} 
*/
 //ZombieBase -> public double get_oldCurTotalHp() { }
float GetPlayerHealth(void *player) {
    if (!player) return NULL;
    static const auto get_CurrentHealth = reinterpret_cast<float (*) (void *)>(getAbsoluteAddress("libil2cpp.so", 0x0));
    return (float) get_CurrentHealth(player);
} 

/*const char* GetPlayerName(void* player) {
    if (!player) return NULL;
    static const auto get_PlayerName = reinterpret_cast<const char* (*) (void*)>(getAbsoluteAddress("libil2cpp.so", 0x5AB17C));
    return (const char*) get_PlayerName(player);
}*/
/*const char* GetPlayerName(void* player) {
    if (!player) return NULL;
    static const auto get_PlayerName = reinterpret_cast<const char* (*) (void*)>(getAbsoluteAddress("libil2cpp..so", 0x5AB17C));
    return (const char*) get_PlayerName(player);
}*/
/*monoString* getPlayerName(void *player) {
    if (!player) return NULL;
    static const auto get_playerName = reinterpret_cast<uint64_t(__fastcall *)(monoString *)>(getAbsoluteAddress("libil2cpp.so", 0x123456));
    return (monoString*) get_playerName(player);
}*/

//ZombieBase -> public bool isDead;
/*bool IsPlayerDead(void *player) {
    if (!player) return NULL;
    static const auto isDead = reinterpret_cast<bool (*) (void *)>(getAbsoluteAddress("libil2cpp.so", 0x5A4C7C));
    return (bool) isDead(player);
}

bool IsPlayerAlive(void *player) {
    return player != NULL && IsPlayerDead(player) != true;
}
*/


//If your game dont have isDead code then use this
bool IsPlayerAlive(void *player) {
    return player != NULL && GetPlayerHealth(player) > 0;
}

bool IsPlayerDead(void *player) {
    return player == NULL && GetPlayerHealth(player) < 1;
}


int string_to_int(string str) { 
    int value;
    value = std::stoi(str);
    return value;
}

string float_to_string (int value) {
    string str; 
    str = std::to_string(value);
    str += "M";
    return str;
}



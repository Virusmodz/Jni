#include <jni.h>
#include <android/log.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <fstream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <cxxabi.h>
#include <algorithm>
#include <iomanip>
#include <regex>
#include <dlfcn.h>
#include <limits.h>
#include <unistd.h>
#include <cstdlib>
#include <iostream>

// ELFIO Header (Header-only library)
#include "elfio.hpp"

// ----------------------------------------------------------------------------
// Configuration
// ----------------------------------------------------------------------------

#define LOG_TAG "Dumper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

// The library name to validate against (Security check)
static constexpr const char* EXPECTED_SONAME = "libVirusModz.so";

// ----------------------------------------------------------------------------
// Helper Structures & Functions
// ----------------------------------------------------------------------------

struct SymbolEntry {
    std::string name;       // The cleaned method/variable name
    std::string signature;  // The full signature (args)
    uint64_t offset;        // Virtual Address
    uint64_t size;          // Size of the symbol
    std::string type;       // "FUNC" or "OBJECT"
    bool isStatic;          // True if it's a static variable (STT_OBJECT)
};

// Returns the basename of a path
static std::string getBasename(const std::string& path) {
    auto pos = path.find_last_of('/');
    return (pos == std::string::npos) ? path : path.substr(pos + 1);
}

// Validates if the loaded library matches the expected name
bool validateLibraryName() {
    Dl_info info;
    if (dladdr((void*)validateLibraryName, &info) == 0 || info.dli_fname == nullptr) {
        LOGE("Failed to query loaded library info.");
        return false;
    }

    std::string realName = getBasename(info.dli_fname);
    if (realName != EXPECTED_SONAME) {
        LOGE("Library mismatch! Expected '%s', found '%s'", EXPECTED_SONAME, realName.c_str());
        return false;
    }
    return true;
}

static std::string demangle(const std::string& mangled_name) {
    int status = 0;
    std::unique_ptr<char, void(*)(void*)> res {
        abi::__cxa_demangle(mangled_name.c_str(), nullptr, nullptr, &status),
        std::free
    };
    return (status == 0) ? res.get() : mangled_name;
}

static bool make_folder(const std::string& path) {
    if (mkdir(path.c_str(), 0755) != 0) {
        if (errno == EEXIST) return true;
        LOGE("mkdir(%s) failed: %d", path.c_str(), errno);
        return false;
    }
    return true;
}

// ----------------------------------------------------------------------------
// Core Dumping Logic (C++17)
// ----------------------------------------------------------------------------

static void dumpElf(const std::string& soPath, const std::string& outDir) {
    ELFIO::elfio reader;
    if (!reader.load(soPath)) {
        LOGE("Failed to load ELF file: %s", soPath.c_str());
        return;
    }

    // Map: ClassName -> Vector of Symbols
    std::map<std::string, std::vector<SymbolEntry>> classes;

    // Iterate over sections to find symbol tables
    for (const auto& section : reader.sections) {
        if (section->get_type() != ELFIO::SHT_SYMTAB && 
            section->get_type() != ELFIO::SHT_DYNSYM) {
            continue;
        }

        ELFIO::symbol_section_accessor symbols(reader, section.get());
        
        for (unsigned int i = 0; i < symbols.get_symbols_num(); ++i) {
            std::string   name;
            ELFIO::Elf64_Addr value = 0;
            ELFIO::Elf_Xword  size = 0;
            unsigned char bind = 0;
            unsigned char type = 0;
            ELFIO::Elf_Half   section_index = 0;
            unsigned char other = 0;

            symbols.get_symbol(i, name, value, size, bind, type, section_index, other);

            // Filter: Only Functions and Objects (Variables), ignoring empty or undefined symbols
            if (name.empty() || value == 0 || section_index == ELFIO::SHN_UNDEF) continue;
            if (type != ELFIO::STT_FUNC && type != ELFIO::STT_OBJECT) continue;

            std::string demangled = demangle(name);
            
            // Basic C++ parsing to separate Class from Method
            // Pattern: Class::Method or Class::Method(Args)
            std::string className = "::Global"; // Default namespace
            std::string memberName = demangled;
            std::string signature = "";

            // 1. Extract arguments (if function)
            size_t argsStart = demangled.find('(');
            if (argsStart != std::string::npos) {
                signature = demangled.substr(argsStart); // "(int, float)"
                memberName = demangled.substr(0, argsStart);
            }

            // 2. Extract Class Name
            // Look for the last "::" to split Class and Member
            size_t splitPos = memberName.rfind("::");
            if (splitPos != std::string::npos) {
                className = memberName.substr(0, splitPos);
                memberName = memberName.substr(splitPos + 2);
            }

            // 3. Create Entry
            SymbolEntry entry;
            entry.name = memberName;
            entry.signature = signature;
            entry.offset = value;
            entry.size = size;
            entry.type = (type == ELFIO::STT_FUNC) ? "FUNC" : "OBJECT";
            entry.isStatic = (type == ELFIO::STT_OBJECT);

            classes[className].push_back(entry);
        }
    }

    if (!make_folder(outDir)) return;

    std::string outFilePath = outDir + "/dump_advanced.cpp";
    std::ofstream out(outFilePath);

    out << "// Dump generated by VirusModz Dumper (C++17)\n";
    out << "// Binary: " << getBasename(soPath) << "\n\n";

    // Iterate through classes
    for (auto& [clsName, entries] : classes) {
        // Sort entries by offset for cleaner reading
        std::sort(entries.begin(), entries.end(), [](const SymbolEntry& a, const SymbolEntry& b) {
            return a.offset < b.offset;
        });

        out << "// ============================================================================\n";
        out << "class " << clsName << " {\n";
        out << "public:\n";

        for (const auto& ent : entries) {
            out << "\n    // Offset: 0x" << std::hex << std::uppercase << ent.offset 
                << " | Size: 0x" << ent.size 
                << " | Type: " << ent.type << "\n";

            if (ent.isStatic) {
                // It's a static variable (Instance fields are not in .symtab)
                out << "    static void* " << ent.name << "; // [Data Field]\n";
            } else {
                // It's a function
                // Note: Return type is often not explicitly in the demangled string for top-level symbols
                // unless it's a template. We assume 'void' or 'auto' context for display.
                out << "    " << ent.name << ent.signature << ";\n";
            }
        }

        out << "};\n\n";
    }

    out.close();
    LOGI("Dump complete: %s", outFilePath.c_str());
}

// ----------------------------------------------------------------------------
// JNI Entry Point
// ----------------------------------------------------------------------------

extern "C"
JNIEXPORT void JNICALL
Java_com_virusModz_dumper_MainActivity_dumpSoFile(
    JNIEnv *env, jobject thiz, jstring jPath)
{
    const char* so_path = env->GetStringUTFChars(jPath, 0);
    std::string path(so_path);
    env->ReleaseStringUTFChars(jPath, so_path);

    // Prepare Output Directory
    std::string fname = getBasename(path);
    std::string baseName = fname;
    if (baseName.size() > 3 && baseName.substr(baseName.size()-3) == ".so")
        baseName = baseName.substr(0, baseName.size()-3);

    std::string outDir = "/sdcard/Android/VirusModz_Dumper/" + baseName;

    // Security & Dump
    if (validateLibraryName()) {
        dumpElf(path, outDir);

        // Notify User (Toast)
        jclass toastCls = env->FindClass("android/widget/Toast");
        if (toastCls) {
            jmethodID makeText = env->GetStaticMethodID(toastCls, "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
            jmethodID show = env->GetMethodID(toastCls, "show", "()V");
            if (makeText && show) {
                jstring msg = env->NewStringUTF("Advanced Dump Complete!");
                jobject toast = env->CallStaticObjectMethod(toastCls, makeText, thiz, msg, 0);
                env->CallVoidMethod(toast, show);
                env->DeleteLocalRef(msg);
                env->DeleteLocalRef(toast);
            }
            env->DeleteLocalRef(toastCls);
        }
    }
}
#include <jni.h>
#include <android/log.h>
#include <dirent.h>
#include <sys/stat.h>
#include <errno.h>
#include <fstream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <cxxabi.h>
#include <algorithm>
#include <iomanip>
#include <regex>
#include <dlfcn.h>
#include <limits.h>
#include <unistd.h>
#include <cstdlib>
#include <iostream>
#include <sstream>

// ELFIO Header (Header-only library)
#include "elfio.hpp"

// ----------------------------------------------------------------------------
// Configuration
// ----------------------------------------------------------------------------

#define LOG_TAG "VirusModz_Dumper"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO,  LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static constexpr const char* EXPECTED_SONAME = "libVirusModz.so";

// ----------------------------------------------------------------------------
// Helper Structures & Functions
// ----------------------------------------------------------------------------

struct SymbolEntry {
    std::string name;       // Method Name
    std::string signature;  // Args (e.g., "(int, float)")
    std::string returnType; // Return Type (e.g., "bool", "void")
    uint64_t offset;        // Virtual Address
    uint64_t size;          // Size of symbol
    std::string type;       // "FUNC", "OBJECT", "VTABLE"
    std::string dataPreview; // Hex dump
    bool isStatic;          // Static variable
    bool isCtor;            // Constructor
    bool isDtor;            // Destructor
    bool returnTypeGuessed; // True if we defaulted to void
};

// Returns the basename of a path
static std::string getBasename(const std::string& path) {
    auto pos = path.find_last_of('/');
    return (pos == std::string::npos) ? path : path.substr(pos + 1);
}

// Validate Library
bool validateLibraryName() {
    Dl_info info;
    if (dladdr((void*)validateLibraryName, &info) == 0 || info.dli_fname == nullptr) {
        return false;
    }
    std::string realName = getBasename(info.dli_fname);
    return realName == EXPECTED_SONAME;
}

// Demangler
static std::string demangle(const char* mangled_name) {
    if (!mangled_name) return "";
    int status = 0;
    std::unique_ptr<char, void(*)(void*)> res {
        abi::__cxa_demangle(mangled_name, nullptr, nullptr, &status),
        std::free
    };
    return (status == 0) ? res.get() : mangled_name;
}

static bool make_folder(const std::string& path) {
    if (mkdir(path.c_str(), 0777) != 0) {
        if (errno == EEXIST) return true;
        LOGE("mkdir(%s) failed: %d", path.c_str(), errno);
        return false;
    }
    return true;
}

static std::string getHexPreview(const char* data, size_t size, size_t limit = 8) {
    if (!data || size == 0) return "";
    std::stringstream ss;
    ss << "{ ";
    size_t count = std::min(size, limit);
    for (size_t i = 0; i < count; ++i) {
        ss << "0x" << std::hex << std::setw(2) << std::setfill('0') 
           << (static_cast<unsigned int>(data[i]) & 0xFF);
        if (i < count - 1) ss << ", ";
    }
    if (size > limit) ss << ", ... ";
    ss << " }";
    return ss.str();
}

// ----------------------------------------------------------------------------
// Advanced Parsing Logic
// ----------------------------------------------------------------------------

struct ParsedInfo {
    std::string className;
    std::string methodName;
    std::string signature;
    std::string returnType;
    bool returnTypeGuessed;
};

// Robust parser to handle "ReturnType Namespace::Class::Method(Args)"
ParsedInfo parseDemangledInfo(const std::string& demangled) {
    ParsedInfo info;
    info.className = "::Global";
    info.methodName = demangled;
    info.signature = "";
    info.returnType = "void"; 
    info.returnTypeGuessed = true;

    std::string temp = demangled;

    // 1. Extract Arguments (...)
    // Find the first '(' that is NOT inside template brackets < >
    size_t argsStart = std::string::npos;
    int templateDepth = 0;
    for (size_t i = 0; i < temp.size(); ++i) {
        if (temp[i] == '<') templateDepth++;
        else if (temp[i] == '>') templateDepth--;
        else if (temp[i] == '(' && templateDepth == 0) {
            argsStart = i;
            break;
        }
    }

    if (argsStart != std::string::npos) {
        info.signature = temp.substr(argsStart);
        temp = temp.substr(0, argsStart); // Remove args from working string
    }

    // 2. Separate Method Name from Class/Namespace
    // Scan backwards for the last "::" (ignoring templates)
    size_t splitPos = std::string::npos;
    templateDepth = 0;
    for (int i = temp.size() - 1; i >= 0; --i) {
        if (temp[i] == '>') templateDepth++;
        else if (temp[i] == '<') templateDepth--;
        else if (temp[i] == ':' && i > 0 && temp[i-1] == ':' && templateDepth == 0) {
            splitPos = i - 1;
            break;
        }
    }

    if (splitPos != std::string::npos) {
        info.methodName = temp.substr(splitPos + 2);
        std::string classAndType = temp.substr(0, splitPos);

        // 3. Separate Return Type from Class Name
        // Scan backwards for a Space that is NOT in templates
        // Example: "bool MyNamespace::MyClass" -> Space at index 4
        size_t spacePos = std::string::npos;
        templateDepth = 0;
        for (int i = classAndType.size() - 1; i >= 0; --i) {
            if (classAndType[i] == '>') templateDepth++;
            else if (classAndType[i] == '<') templateDepth--;
            else if (classAndType[i] == ' ' && templateDepth == 0) {
                spacePos = i;
                break;
            }
        }

        if (spacePos != std::string::npos) {
            // We found a return type!
            info.returnType = classAndType.substr(0, spacePos);
            info.className = classAndType.substr(spacePos + 1);
            info.returnTypeGuessed = false; // We found a real one
        } else {
            // No return type found (Standard C++ mangling often omits it)
            info.className = classAndType;
        }
    } else {
        // No "::" found, it's a global function or just a type
        // Check for space to see if return type exists: "void myFunc"
        size_t spacePos = std::string::npos;
        templateDepth = 0;
        for (int i = temp.size() - 1; i >= 0; --i) {
            if (temp[i] == '>') templateDepth++;
            else if (temp[i] == '<') templateDepth--;
            else if (temp[i] == ' ' && templateDepth == 0) {
                spacePos = i;
                break;
            }
        }
        if (spacePos != std::string::npos) {
            info.returnType = temp.substr(0, spacePos);
            info.methodName = temp.substr(spacePos + 1);
            info.returnTypeGuessed = false;
        } else {
            info.methodName = temp;
        }
    }

    return info;
}

// ----------------------------------------------------------------------------
// Core Dumping Logic
// ----------------------------------------------------------------------------

static void dumpElf(const std::string& soPath, const std::string& outDir) {
    ELFIO::elfio reader;
    if (!reader.load(soPath)) {
        LOGE("Failed to load ELF file: %s", soPath.c_str());
        return;
    }

    if (!make_folder(outDir)) return;
    std::string outFilePath = outDir + "/dump_advanced.h";
    std::ofstream out(outFilePath);

    out << "// Generated by VirusModz Dumper\n";
    out << "// Binary: " << getBasename(soPath) << "\n\n";

    // Data structure to hold symbols sorted by class
    std::map<std::string, std::vector<SymbolEntry>> classes;

    auto processSymbols = [&](ELFIO::section* sec) {
        if (!sec) return;
        ELFIO::symbol_section_accessor symbols(reader, sec);
        
        for (unsigned int i = 0; i < symbols.get_symbols_num(); ++i) {
            std::string name;
            ELFIO::Elf64_Addr value = 0;
            ELFIO::Elf_Xword size = 0;
            unsigned char bind = 0;
            unsigned char type = 0;
            ELFIO::Elf_Half section_index = 0;
            unsigned char other = 0;

            symbols.get_symbol(i, name, value, size, bind, type, section_index, other);

            if (name.empty() || value == 0 || section_index == ELFIO::SHN_UNDEF) continue;
            if (type != ELFIO::STT_FUNC && type != ELFIO::STT_OBJECT) continue;

            std::string demangled = demangle(name.c_str());
            
            // Check for VTable
            bool isVtable = false;
            if (demangled.rfind("vtable for", 0) == 0) {
                isVtable = true;
                demangled = demangled.substr(11);
            }

            // USE THE NEW PARSER
            ParsedInfo info = parseDemangledInfo(demangled);
            
            // Special checks for Ctor/Dtor
            bool isCtor = false;
            bool isDtor = false;
            
            std::string shortClass = getBasename(info.className);
            size_t tpl = shortClass.find('<');
            if (tpl != std::string::npos) shortClass = shortClass.substr(0, tpl);

            if (info.methodName == shortClass) isCtor = true;
            else if (info.methodName == "~" + shortClass) isDtor = true;

            // Hex Preview
            std::string hexPreview = "";
            if (type == ELFIO::STT_OBJECT && size > 0 && section_index < reader.sections.size()) {
                const auto& dataSec = reader.sections[section_index];
                if (value >= dataSec->get_address()) {
                    uint64_t offsetSec = value - dataSec->get_address();
                    if (offsetSec < dataSec->get_size()) {
                        hexPreview = getHexPreview(dataSec->get_data() + offsetSec, size);
                    }
                }
            }

            SymbolEntry entry;
            entry.name = info.methodName;
            entry.signature = info.signature;
            entry.returnType = info.returnType;
            entry.returnTypeGuessed = info.returnTypeGuessed;
            entry.offset = value;
            entry.size = size;
            entry.type = isVtable ? "VTABLE" : (type == ELFIO::STT_FUNC ? "FUNC" : "OBJECT");
            entry.isStatic = (type == ELFIO::STT_OBJECT);
            entry.dataPreview = hexPreview;
            entry.isCtor = isCtor;
            entry.isDtor = isDtor;

            classes[info.className].push_back(entry);
        }
    };

    for (const auto& sec : reader.sections) {
        if (sec->get_type() == ELFIO::SHT_SYMTAB || sec->get_type() == ELFIO::SHT_DYNSYM) {
            processSymbols(sec.get());
        }
    }

    // Output
    for (auto& [clsName, entries] : classes) {
        std::sort(entries.begin(), entries.end(), [](const SymbolEntry& a, const SymbolEntry& b) {
            return a.offset < b.offset;
        });

        out << "// ============================================================\n";
        out << "class " << clsName << " {\n";
        out << "public:\n";

        for (const auto& ent : entries) {
            out << "    // Offset: 0x" << std::hex << std::uppercase << ent.offset 
                << " | Size: 0x" << ent.size;
            if (!ent.dataPreview.empty()) out << " | Data: " << ent.dataPreview;
            out << "\n";

            if (ent.type == "VTABLE") {
                out << "    static void* vtable; // [VTable]\n";
            } else if (ent.isStatic) {
                out << "    static void* " << ent.name << "; // [Static Object]\n";
            } else {
                std::string prefix = ent.isStatic ? "static " : "";
                
                if (ent.isCtor) {
                    out << "    " << ent.name << ent.signature << "; // [Constructor]\n";
                } else if (ent.isDtor) {
                    out << "    " << ent.name << ent.signature << "; // [Destructor]\n";
                } else {
                    // Show return type. If guessed (void), add comment to clarify.
                    out << "    " << prefix << ent.returnType << " " << ent.name << ent.signature << ";";
                    if (ent.returnTypeGuessed && ent.returnType == "void") {
                        out << " // [Unknown Return Type]";
                    }
                    out << "\n";
                }
            }
        }
        out << "};\n\n";
    }

    out.close();
    LOGI("Dump complete: %s", outFilePath.c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_virusModz_dumper_MainActivity_dumpSoFile(
    JNIEnv *env, jobject thiz, jstring jPath)
{
    const char* so_path = env->GetStringUTFChars(jPath, 0);
    std::string path(so_path);
    env->ReleaseStringUTFChars(jPath, so_path);

    std::string baseName = getBasename(path);
    if (baseName.size() > 3 && baseName.substr(baseName.size()-3) == ".so")
        baseName = baseName.substr(0, baseName.size()-3);

    std::string outDir = "/sdcard/Android/data/com.virusModz.dumper/files/" + baseName;

    if (validateLibraryName()) {
        dumpElf(path, outDir);
        
        jclass toastCls = env->FindClass("android/widget/Toast");
        if (toastCls) {
            jmethodID makeText = env->GetStaticMethodID(toastCls, "makeText", "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
            jmethodID show = env->GetMethodID(toastCls, "show", "()V");
            if (makeText && show) {
                jstring msg = env->NewStringUTF("Dump Saved!");
                jobject toast = env->CallStaticObjectMethod(toastCls, makeText, thiz, msg, 0);
                env->CallVoidMethod(toast, show);
                env->DeleteLocalRef(msg);
                env->DeleteLocalRef(toast);
            }
        }
    }
}
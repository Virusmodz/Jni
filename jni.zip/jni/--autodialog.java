package --com.antik.dialog;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;

public class autodialog implements Application.ActivityLifecycleCallbacks {

    public static native void nativeOnActivityResumed(Activity activity);

    public static void init() {
        try {
            Class at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);

            if (app instanceof Application) {
                ((Application) app)
					.registerActivityLifecycleCallbacks(new autodialog());
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    public void onActivityResumed(Activity activity) {
        nativeOnActivityResumed(activity);
    }

    @Override public void onActivityCreated(Activity a, Bundle b) {
    }
    @Override public void onActivityStarted(Activity a) {
    }
    @Override public void onActivityPaused(Activity a) {
    }
    @Override public void onActivityStopped(Activity a) {
    }
    @Override public void onActivitySaveInstanceState(Activity a, Bundle b) {
    }
    @Override public void onActivityDestroyed(Activity a) {
    }
}

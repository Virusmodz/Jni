//------------------------------------------------------------------------------
//! \def ELFIO_VERSION
//! \brief Defines the version of the ELFIO library
#define ELFIO_VERSION "3.14"

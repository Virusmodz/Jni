#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <string>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include <cmath>  
#include <cfloat> 
#include <unordered_set>
#include <cstdlib>
#include <sstream>
#include <vector> 
#include "points.h"
#include "Includes/enc.h"
#include "display.h"
#include "boxview.h"

//Target lib here
#define targetLibName OBFUSCATE("libcocos2dcpp.so")

#include "Includes/Macros.h"

void* VoidOdj = NULL;
std::ostringstream oss;

struct Variables {
    std::string adrassas = "";

    bool VoidHook = false;
    const char *offsetToHookVoid;
    const char *offsetToCallVoid;
    bool iscallvoid = false;
    

    

} VM;

struct cpVect64 {
    double x;
    double y;
};

struct cpVect {
    double x;
    double y;
};
struct CCSize {
    float width;
    float height;
};
struct Color4B {
    uint8_t r;
    uint8_t g;
    uint8_t b;
    uint8_t a;  // alpha
};

struct Color3B {
    uint8_t r;
    uint8_t g;
    uint8_t b;
};

struct Vec4 {
    float x;
    float y;
    float z;
    float w;
};

//Vec4 getBodyVelocity();
static float hpvalue = 0.0f;  

float destincence;
float isboost = 0;
float distence;
bool isteleport, autothrowg, tpnadeto, isadrasss2, isseendmi, isaimonly, isautof, isdrawL;
void *(*Deagle6create)();         //_ZN6DEAGLE6createEv
int Esize;

float positionsX, positionsY;

bool isAimbot, automille, isadrasss, isadrasssEP, copyid;

constexpr float PI_F = 3.14159265358979323846f;
constexpr float RAD2DEG = 180.0f / PI_F;

int (*getTeamId)(void* instance); // get players team id like 1 to 7, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead

int (*getWeaponRange)(void* weapon);
void* (*getLocalPrimaryWeapon)(void* player) = nullptr;

void (*setPositionn)(void* thiz, cpVect pos);
using namespace std;

void* localWeapon = nullptr; 

unordered_set<void *> playerslist;

void* getnead = NULL;
void* enemyPlayers = NULL;
void* localPlayer = NULL;
void* currentTarget = NULL;   
void* bestCandidate = NULL;    
float closestDistSq = FLT_MAX; 
float (*old_boost)(void *instance);

void* gnade = NULL;

void* onbe = NULL;

void* Wm = NULL;

int cachedLocalTeam = -1;
float cachedLocalX = 0.0f;
float cachedLocalY = 0.0f;
float isplayerspeed, istimescal;


float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);

void (*SetPosition)(void* instance, float x, float y);

void (*SettPositionX)(void* instance, float X);
void (*SettPositionY)(void* instance, float Y);

void (*getBodyVelocity)(Vec4* out, void* SoldierController);


Vec4 getPlayerVelocity(void* instance) {
    if (!instance) return Vec4{1 ,2 ,3 ,4};;

 

    Vec4 result;
    getBodyVelocity(&result, instance);
    return result;
}

void *OdjM = NULL;

void getLocalPeerID(std::string* out, void* thiz);

int (*getQuickplayPopulation)();

std::string msg = "lg";
void *(*CCString_create_std)(const std::string &str);

void (*sentIM)(void* instance, void* thi);

int (*getValueint)(void* thi);

void (*sendMapVote)(void* instance, void* thi);

/*
void sendMapVote(void* instance, void* thi){

if (instance){

int item =
        getValueint(thi);

    LOGI("Disable Powerup ID: %d", item);

 }

return old_sendMapVote(instance, thi);
}

*/

int mapvoteV;

void *(*create_int)(int value);

int population;

void (*old_Stage)(void* instance, float dt);
void Stage(void* instance, float dt){
if (instance != NULL){
  
  
  population = getQuickplayPopulation();

OdjM = instance;


  if (isseendmi && onbe){
  
      *(bool*)((uintptr_t)onbe + 0x188) = false;
      
//  void *strObj = CCString_create_std(msg);
  void *intObj = create_int(mapvoteV);
  
  sendMapVote(instance, intObj);
//  sentIM(instance, strObj);
  
  isseendmi = false;
  }


} 
return old_Stage(instance, dt);
} 


void (*drawSegment)(const cpVect&, const cpVect&);


void (*old_draw)(void *instance);
void draw(void *instance){
if(instance != NULL){
  if (isdrawL) {
  /*
        drawSegment(
            cpVect{3123,654},
            cpVect{1891,814}
        );
        
    */
    
    }
  


}
return old_draw(instance);

}


void* (*sharedDirector_t)();
CCSize (*getWinSize)(void *thiz);




//#include <string>
void (*old_CCScheduler)(void *instance, float timespeed);
void CCScheduler(void *instance, float timespeed){

float gettis = timespeed * istimescal;

if(instance != NULL){
if (istimescal > 0){
old_CCScheduler(instance, gettis);

}

}
return old_CCScheduler(instance, timespeed);

}


void (*old_setAcceleration)(void *instance, float sp1, float sp2, float sp3);
void setAcceleration(void *instance, float sp1, float sp2, float sp3){
if(instance != NULL){
 
 /*
 sp1 = 999;
 sp2 = 999;
 sp2 = 999;
 
*/

}
return old_setAcceleration(instance, sp1, sp2, sp3);

}


void (*old_onBeforeMapVote)(void *thiz);

void onBeforeMapVote_hook(void *thiz) {

 if (thiz){
 
 onbe = thiz;
 
 }

    old_onBeforeMapVote(thiz);
}



void (*old_getCustomRoomKickData)(void* thiz, std::string, int);

void getCustomRoomKickData_hook(void* thiz,
                                   std::string roomId,
                                   int kickType)
{

if (thiz){
    LOGI("Room=%s Type=%d",
         roomId.c_str(),
         kickType);
      }

    return old_getCustomRoomKickData(
        thiz,
        roomId,
        kickType);
}






void (*Old_fragnade)(void* instance ,float dt);
    void fragnade(void *instance, float dt){
    if (instance != NULL && currentTarget != NULL) {
    
  getnead = instance;
       
    float y = GetPositionY(currentTarget);
    float x =  GetPositionX(currentTarget);
       
       if (tpnadeto){
       SettPositionX(instance, x);
       SettPositionY(instance, y);
       }
       
    
        
    }
    return Old_fragnade(instance, dt);
} 

bool create;

std::string name("ok");
void* (*createWorldIndicator)(void* ins, void* node, cpVect pos, Color3B cool, std::string& name);

void* (*getSoldierViewP)(void* thiz);

void (*addAlert)(void* thiz, std::string name);

void (*removeAlert)(void* thiz, std::string name);

std::string (*getPeerID)(void* thiz);

void* (*CCNode_getParent)(void* thz);

void (*onRadarAlert)(void* thiz, void* p);

void (*Old_radar)(void* instance ,float dt);
    void radar(void *instance, float dt){
    if (instance && currentTarget) {
    
    positionsX = GetPositionX(currentTarget);
     positionsY = GetPositionY(currentTarget);
       
    Color3B rade = {191, 0, 255};
        void* pview = getSoldierViewP(currentTarget);
        
        cpVect poss = {positionsX, positionsY};
    
    if(create && pview) {
  void* sprite =   createWorldIndicator(instance, pview, cpVect{0, 60}, rade, name);
    
  void* obj = CCString_create_std(getPeerID(currentTarget));
  
  onRadarAlert(instance, obj);
  
  addAlert(instance, getPeerID(currentTarget));
    
   // create = false;
    }
    
    
        
    }
    return Old_radar(instance, dt);
} 




float (*old_playerspeed)(void *instance);
float playerspeed(void *instance){
if (instance != NULL) {
if(isplayerspeed > 0){

return (float) isplayerspeed;
}
}
return old_playerspeed(instance);
}


void teleporting(){
	
		
		if (playerslist.empty() || !isteleport) {
          return; 
          }
		size_t size = playerslist.size();
		int random_steps = rand() % size; 

        
          auto it = playerslist.begin();
       
        std::advance(it, random_steps); 

		
       
        void* randomTarget = *it;
        
    
		if (!isdead(randomTarget) || gethp(randomTarget) > 0){
            
            
          
		if (randomTarget ){
			void* targetBody = *(void **)((char *)randomTarget + 0x148);
           if (targetBody != NULL){
           float targetX = *(float *)((char *)targetBody + 0x2c);
		   float targetY = *(float *)((char *)targetBody + 0x34);
		   void *body = *(void **)((char *)localPlayer + 0x148);
     if (body != NULL) {

        float *posX = (float *)((char *)body + 0x2c);
        float *posY = (float *)((char *)body + 0x34);
           
          *posX = targetX;
          *posY = targetY;
          
                 isteleport = false;
                        
               }
               }
			
		}
		}
		
	}
    
    void (*callvoid)(void* instance);
    
	void (*old_VoidHook)(void* instance ,float dt);
    void VoidHook(void *instance, float dt){
    if (instance != NULL) {
        
       if (VM.VoidHook){
       
       positionsX = GetPositionX(instance);
       positionsY = GetPositionY(instance);
       
       if (VM.iscallvoid){
       callvoid(instance);
       }
       
       VoidOdj = instance;
       
      //VM.adrassas = std::to_string(positionsX);
      
        std::ostringstream addressStream;
        addressStream << "0x" << std::hex << (uintptr_t)instance;
        VM.adrassas = addressStream.str(); 
       }
        
    }
    return old_VoidHook(instance, dt);
} 

bool applyi;

void (*applyWeaponMods)(void* thz, void* weapon);



void (*addDualWeapon)(void* thiz, void* weapon);


void (*old_SoldierLocalController)(void* instance ,float dt);
void SoldierLocalController(void *instance, float dt){
    if (instance != NULL) {
    
    if (applyi){
    void* item = Deagle6create();
    
    if (item) {
    addDualWeapon(instance, item);
    
  //  LOGI("DONE");
    
    applyi = false;
    }
    }
    
    void* body = *(void**)((uintptr_t)instance + 0x148);
    
   // setPositionn(instance, cpVect{200, 500});
   

//LOGI("vtable = %p", *(void**)body);


    Vec4 getpS = getPlayerVelocity(instance);
    
  //  DisplayText = std::to_string((float)getpS.y) + "| |" + std::to_string((float)getpS.w);
  //  Vec4 v = getPlayerVelocity(instance);

//LOGI("x=%f y=%f z=%f w=%f",
   //  getpS.x, getpS.y, getpS.z, getpS.w);
    void* playersspit = *(void**)((char*)instance + 0x148);
    
  //  LOGI("player=%p sprite=%p", instance, playersspit);
    
    void* odjc = sharedDirector_t();
    
   CCSize scrensize = getWinSize(odjc);
   
   std::string gg = "  ";
        
// DisplayText = std::to_string((int)scrensize.height) + " x " + std::to_string((int)scrensize.width);

    
  
    
   if (getLocalPrimaryWeapon) {
    localWeapon = getLocalPrimaryWeapon(instance);
      
      if (localWeapon) {
      int r = getWeaponRange(localWeapon);
      
    //  DisplayText = std::to_string((int)r);
      }
      }
        localPlayer = instance;
      /*
void *body = *(void **)((char *)instance + 0x148);
    if (body != NULL) {

            float *getBodyVelocityX = (float *)((char *)body + 0x38);
            float *getBodyVelocityY = (float *)((char *)body + 0x3c);
            
        //   getVelocityX = *getBodyVelocityX;
         //  getVelocityY = *getBodyVelocityY;
    } */
    
       
        
       
        currentTarget = bestCandidate;

     
        closestDistSq = FLT_MAX; 
        bestCandidate = NULL;

        
        if (getTeamId) cachedLocalTeam = getTeamId(instance);
        if (GetPositionX) cachedLocalX = GetPositionX(instance);
        if (GetPositionY) cachedLocalY = GetPositionY(instance);
    } else {
        localPlayer = NULL; 
    }
    

    
    return old_SoldierLocalController(instance, dt);
} 



void (*old_removebody)(void* instance);
void removebody(void* instance){
if (instance != NULL){
playerslist.erase(instance);

} 
return old_removebody(instance);
} 

void* g_MapManager = NULL;

// mapCollision: takes MapManager instance + cpVect, returns true if wall/collision at that point
bool (*mapCollision)(void* instance, cpVect64 point);


void (*old_MapManager_updateVisibleTiles)(void* instance, cpVect64 point, float dt);
void MapManager_updateVisibleTiles(void* instance, cpVect64 point, float dt) {
    if (instance != NULL) {
        g_MapManager = instance; // This captures the map pointer
    }
    old_MapManager_updateVisibleTiles(instance, point, dt);
}

bool isEnemyVisible(void* enemy) {
    if (!g_MapManager || !mapCollision || !localPlayer || !enemy) {
        return true;
    }

    double myX = (double)GetPositionX(localPlayer);
    double myY = (double)GetPositionY(localPlayer);
    double enemyX = (double)GetPositionX(enemy);
    double enemyY = (double)GetPositionY(enemy);

    double dx = enemyX - myX;
    double dy = enemyY - myY;
    double dist = sqrt(dx * dx + dy * dy);

    if (dist < 30.0) return true;

    int steps = (int)(dist / 22.0f);
    if (steps < 2) steps = 2;
    //if (steps > 6) steps = 6; 
    

    for (int i = 1; i < steps; i++) {
        double t = (double)i / (double)steps;
        cpVect64 checkPoint;
        checkPoint.x = myX + dx * t;
        checkPoint.y = myY + dy * t;

        if (mapCollision(g_MapManager, checkPoint)) {
            return false;
        }
    }

    return true;
}



void (*old_SoldierRemoteController)(void* instance, float dt);
void SoldierRemoteController(void* instance, float dt){
    
    if (instance != NULL) {
    
  Esize = playerslist.size();
        
  //      DisplayText = "t";
    
   enemyPlayers = instance;
	
    if (getTeamId(localPlayer) > 1 && getTeamId(instance) != getTeamId(localPlayer) && !isdead(instance) || gethp(instance) > 0) {
       
    playerslist.insert(instance);
    } else if (!isdead(instance) || gethp(instance) > 0 && getTeamId(localPlayer) == 1) {
    playerslist.insert(instance);
 
    } else {
        playerslist.erase(instance);
        
    }
	
    	if(isteleport){
		teleporting();
		
	}
	
    
    
    
    
   int remoteTeam = getTeamId(instance);
        
       
        if (cachedLocalTeam > 1 && cachedLocalTeam == remoteTeam) {
            return old_SoldierRemoteController(instance, dt);
        }

   
        float enX = GetPositionX(instance);
        float enY = GetPositionY(instance);
        float px = GetPositionX(localPlayer);
        float py = GetPositionY(localPlayer);
		
		/*
		std::string gg = "n/  /n";
        
        DisplayText + std::to_string((float)px) + gg + std::to_string((float)py);
*/
        float dx = px - enX;
        float dy = py - enY;
        float distSq = (dx * dx) + (dy * dy);
        
        float dist = sqrtf(dx*dx + dy*dy);
        
    //    DisplayText = std::to_string((int)dist);
      
		
		if (distSq > 23083004) {
			return old_SoldierRemoteController(instance, dt);
        
		}

		//DisplayText = std::to_string((int)distSq);
        // 3. Visibility Check + Target Selection
        // We only consider the enemy if they are visible
           if (isaimonly && isEnemyVisible(instance)) {
            if (distSq < closestDistSq) {
                closestDistSq = distSq;
                bestCandidate = instance;
         
            }
        
      } else if (!isaimonly){
          if (distSq < closestDistSq) {
                closestDistSq = distSq;
                bestCandidate = instance;
         
            }
    
    }
	}

    return old_SoldierRemoteController(instance, dt);
}


float (*old_FireAngle)(void* instance);
float FireAngle(void* instance) {
    if (isAimbot && instance != NULL && localPlayer != NULL && currentTarget != NULL) {
        
       
        if (!isdead(currentTarget) || gethp(currentTarget) > 0 ) {
            
            
           
            float px = GetPositionX(localPlayer);
            float py = GetPositionY(localPlayer);
            
            float ex = GetPositionX(currentTarget);
            float ey = GetPositionY(currentTarget);

            float dx = ex - px;
            float dy = py - ey;
            
            
            float angleRad = atan2f(dy, dx);
            float angleDeg = angleRad * RAD2DEG; 
            
            
            
            if (angleDeg < 0) angleDeg += 360.0f;
     // DisplayText = std::to_string((int)angleDeg);
            
            return angleDeg;
        }
    }
    
    return old_FireAngle(instance);
}

bool (*old_isfire)(void* instance);
bool isfire(void* instance){
if(instance != NULL){

if (currentTarget != NULL && !isdead(currentTarget) && isautof) {

                // Cached weapon se range lo
                float weapRange = 0.0f;
                if (localWeapon != NULL && getWeaponRange) {
                    int r = getWeaponRange(localWeapon);
                    if (r > 0) weapRange = (float)r;
                }

                float dx = GetPositionX(currentTarget) - GetPositionX(localPlayer);
                float dy = GetPositionY(currentTarget) - GetPositionY(localPlayer);
                float dist = sqrtf(dx*dx + dy*dy);

                //LOGD("WeapRange: %.1f | Dist: %.1f", weapRange, dist); // debug — baad mein hatao

                if (dist <= weapRange) {
                    return true;
                }
            }


} 
return old_isfire(instance);

} 

void (*punch)(void* instance);
void (*onPressGrenade)(void* instance);


void (*old_hud)(void* instance, float dt);
void hud(void* instance, float dt) {
     
     if (instance != NULL){
        if (automille && currentTarget != NULL){
            if (!isdead(currentTarget) || gethp(currentTarget) > 0) {
           
             float mypy = GetPositionY(localPlayer);
             float mypx = GetPositionX(localPlayer);
       
             float enpy = GetPositionY(currentTarget);
             float enpx = GetPositionX(currentTarget);
       
             float dy = enpy - mypy;
             float dx = enpx - mypx;
       
             float distSq = (dx * dx) + (dy * dy);
             destincence = distSq;
             if (distSq < 4000){
              punch(instance);
          
             }
           }
        }
        if (autothrowg && hpvalue < 2){
            onPressGrenade(instance);
        }
     }
 return old_hud(instance, dt);
}


void (*orig_sendPlayerSetup)(
    void* thiz,
    std::string playerName,
    int playerId,
    std::string roomName,
    int mode,
    std::string extra
);

void hook_sendPlayerSetup(
    void* thiz,
    std::string playerName,
    int playerId,
    std::string roomName,
    int mode,
    std::string extra
) {

if (thiz != NULL){
 

  }
  return orig_sendPlayerSetup(
        thiz,
        playerName,
        playerId,
        roomName,
        mode,
        extra
    );
}


void (*orig_connectToPeer)(
    void *thiz,
    std::string *peerId,
    std::string *address,
    int port,
    bool isSecure
);

void hook_connectToPeer(
    void *thiz,
    std::string *peerId,
    std::string *address,
    int port,
    bool isSecure
) {
    if (thiz != NULL) {

    }

    // Example: block connection
    // return;

    // Or modify values
    // port = 12345;
    // isSecure = false;

    // Call original
   return orig_connectToPeer(thiz, peerId, address, port, isSecure);
}

void (*old_setMaxPlayers)(void *instance, int pl);
void setMaxPlayers(void *instance, int pl){
if (instance != NULL){
 pl = 12;


}
return old_setMaxPlayers(instance, pl);
}

float (*old_halte)(void *instance);  

float halte(void *instance) {
    if (instance != NULL) {
      
       hpvalue = old_halte(instance);
        
       // DisplayText = std::to_string((float)old_halte(instance));
    }
    
    return old_halte(instance);
}

bool isadtaszboost;

float Boost(void *instance){
    if (instance != NULL){
        
        if(isadtaszboost){
        
        isadtaszboost = false;
        }
        isboost = old_boost(instance);
        
      //  DisplayText += "boost :" = std::to_string((float)old_boost(instance));
    }
    return old_boost(instance);
}


std::string (*old_pacage)(void* instance);
std::string pacage(void* instance){
  if (instance != NULL){
  
  
  }
 return old_pacage(instance);
}



void (*old_ProjectileManager)(void *instance, float dt);  
void ProjectileManager(void *instance, float dt) {
    if (instance != NULL) {
      
       
        
    }
    
    return old_ProjectileManager(instance, dt);
}
      

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_android_support_Menu_GetTextList(JNIEnv *env, jobject context) {
    
     
    
    std::vector<std::string> values;

    
    values.push_back(std::to_string((int)hpvalue)); //0
    values.push_back(std::to_string((int)isboost)); //1
    values.push_back(std::to_string(destincence)); //2
    values.push_back(std::to_string(positionsX)); //3
    values.push_back(std::to_string(positionsY)); //4
    values.push_back(VM.adrassas.c_str()); //5
    values.push_back(Scanner.resultText.c_str()); //6 
    values.push_back(std::to_string(Esize)); //7
  //  values.push_back(getid); //8

          

          


   
    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray ret = env->NewObjectArray(values.size(), stringClass, env->NewStringUTF(""));
    for (size_t i = 0; i < values.size(); i++) {
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(values[i].c_str()));
    }

    return ret;
}

std::vector<void*> RemotePlayers;

void* (*old_addRemotePlayer)(void*, std::string*);

void* addRemotePlayer_hook(void* thiz, std::string* id)
{
    void* remote = old_addRemotePlayer(thiz, id);

    if (remote)
    {
        LOGI("remote=%p", remote);

        void* view = *(void**)((uint32_t)remote + 0x104);
        LOGI("view=%p", view);

        if (view)
        {
        LOGI("childE0=%p", *(void**)((uintptr_t)view + 0xE0));
LOGI("child100=%p", *(void**)((uintptr_t)view + 0x100));
LOGI("child108=%p", *(void**)((uintptr_t)view + 0x108));
LOGI("child208=%p", *(void**)((uintptr_t)view + 0x208));


            
        }
    }

    return remote;
}

bool callone;


void (*old_itemPickup)(void* thiz, void* item);

void itemPickup_hook(void* thiz, void* item) {

 if (thiz){
 

}
    return old_itemPickup(thiz, item);
}
std::vector<void*> ItemList;

void (*itemPickup)(void* instance, void* thiz);
void (*setpowerType)(void* instance, int type);

void (*old_addItemToWorld)(void *thiz, void *item, bool spawnVisual);

void addItemToWorld_hook(void *thiz, void *item, bool spawnVisual) {

    if (thiz) {
    
    if (localPlayer && Wm && item && callone) {
    
    
    float px = GetPositionX(localPlayer);
    float py = GetPositionY(localPlayer);

       // uint32_t itemID = *(uint32_t *)((uintptr_t)item + 0x4);

         *(float*)((uintptr_t)item + 0x28) = px + 100;
         *(float*)((uintptr_t)item + 0x2C) = py + 50;
         
callone = false;
      // itemPickup(Wm, item);
         
         }
    }

    old_addItemToWorld(thiz, item, spawnVisual);
}


void (*addItemWorld)(void *thiz, void *item, bool spawnVisual);
void (*addItem)(void* thiz, void *item, int spawnVisual);
void (*shouldSpawnItem)(void *thiz, void *item);

bool (*Init_t)(void* item);



std::string (*getUUID)(void* item);

void (*old_WeaponManager)(void* instance, float dt);
void WeaponManager(void* instance, float dt) {
     
     if (instance != NULL){
    Wm = instance;
    
    if (callone && localPlayer){
   void* item = Deagle6create();
   
  // setpowerType(item, 14);
   shouldSpawnItem(instance, item);
      
    addItemWorld(instance, item, true);
    addItem(instance, item, 1);
    
    
    
  DisplayText = getUUID(item);
    
    float px = GetPositionX(localPlayer);
    float py = GetPositionY(localPlayer);

       // uint32_t itemID = *(uint32_t *)((uintptr_t)item + 0x4);

         *(float*)((uintptr_t)item + 0x28) = px + 100;
         *(float*)((uintptr_t)item + 0x2C) = py + 50;
     
  
     }
        
     }
 return old_WeaponManager(instance, dt);
}




// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    

    

#else //To compile this code for armv7 lib only.
MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x7ad9cc), (void *) halte, (void **) &old_halte);
PATCH_SYM("_ZN14NetworkManager18requestSpendTokensENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEi", "01 00 A0 E3 1E FF 2F E1");
HOOK_LIB("libcocos2dcpp.so", "0x7a4108", Boost, old_boost);

HOOK_LIB("libcocos2dcpp.so", "0x7a5170", SoldierLocalController, old_SoldierLocalController);
HOOK_LIB("libcocos2dcpp.so", "0x7b2d48", SoldierRemoteController, old_SoldierRemoteController);
SetPosition = (void (*)(void *, float, float))getAbsoluteAddress(targetLibName, 0xa9c721); 
HOOK_LIB("libcocos2dcpp.so", "0x5156b8", FireAngle, old_FireAngle);
setPositionn = (void (*)(void *, cpVect))getAbsoluteAddress(targetLibName, 0xA9C6B9); 
getTeamId = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x4361e0); 
gethp = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1b8); 
isdead = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1f8); 
HOOK_LIB("libcocos2dcpp.so", "0x79e224", removebody, old_removebody);
HOOK_LIB("libcocos2dcpp.so", "0x8767d4", pacage, old_pacage);

GetPositionX = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c791); 
GetPositionY = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c79f); 

HOOK_LIB("libcocos2dcpp.so", "0x4fa4b4", hud, old_hud);
addItemWorld = (void(*)(void*, void*, bool))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN13WeaponManager14addItemToWorldEP4Itemb"));

addItem = (void(*)(void*, void*, int))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN13WeaponManager7addItemEP4Item15ItemEquipAction"));

addDualWeapon = (void(*)(void*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN22SoldierLocalController9addWeaponEP6Weapon"));

punch = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x4f50c4); 
onPressGrenade = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x4f4fbc); 

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Weapon15getWeightFactorEv", playerspeed, old_playerspeed);

HOOK_LIB("libcocos2dcpp.so", "0x4b4e2c", fragnade, Old_fragnade);

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN7cocos2d11CCScheduler6updateEf", CCScheduler, old_CCScheduler);

SettPositionY = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0xa9c815); 
SettPositionX = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0xa9c7ad); 
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN18GameCustomizeLayer13setMaxPlayersEi", setMaxPlayers, old_setMaxPlayers);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN13WeaponManager10updateStepEf", WeaponManager, old_WeaponManager);
    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN14NetworkManager15sendPlayerSetupENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEiS6_iS6_", hook_sendPlayerSetup, orig_sendPlayerSetup);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN14NetworkManager13connectToPeerENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEES6_ib", hook_connectToPeer, orig_connectToPeer);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN17ProjectileManager9addBulletE6cpVectfS0_P6WeaponiS0_NSt6__ndk112basic_stringIcNS3_11char_traitsIcEENS3_9allocatorIcEEEE", ProjectileManager, old_ProjectileManager);
itemPickup = (void (*)(void*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN13WeaponManager10itemPickupEPN7cocos2d8CCObjectE"));
mapCollision = (bool(*)(void*, cpVect64))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN10MapManager12mapCollisionE6cpVect"));
// Add this below your other HOOKSYM_LIB calls (e.g. below hook_spriteFrameByName)
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN10MapManager18updateVisibleTilesE6cpVectf", MapManager_updateVisibleTiles, old_MapManager_updateVisibleTiles);

//HOOKSYM_LIB("libcocos2dcpp.so", "_ZN14NetworkManager11sendMapVoteEPN7cocos2d8CCObjectE", sendMapVote, old_sendMapVote);

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN5Stage15setAccelerationEfff", setAcceleration, old_setAcceleration);

CCString_create_std = (void *(*)(const std::string &))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7cocos2d8CCString6createERKNSt6__ndk112basic_stringIcNS1_11char_traitsIcEENS1_9allocatorIcEEEE"));
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN14NetworkManager20updateNetworkObjectsEf", Stage, old_Stage);

sentIM = (void(*)(void*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN14NetworkManager6sendIMEPN7cocos2d8CCObjectE"));

sendMapVote = (void(*)(void*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN14NetworkManager11sendMapVoteEPN7cocos2d8CCObjectE"));

create_int = (void *(*)(int))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7cocos2d9CCInteger6createEi"));

getValueint = (int (*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZNK7cocos2d9CCInteger8getValueEv"));

getQuickplayPopulation = (int (*)())dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN14NetworkManager22getQuickplayPopulationEv"));

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN23PlayerLobbyOnlineHosted22updateButtonVisibilityEv", onBeforeMapVote_hook, old_onBeforeMapVote);

getLocalPrimaryWeapon = (void*(*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN17SoldierController16getPrimaryWeaponEv"));
drawSegment = (void (*)(const cpVect&, const cpVect&))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7cocos2d10ccDrawLineERKNS_7CCPointES2_"));
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN7cocos2d10CCDirector9drawSceneEv", draw, old_draw);

getUUID = (std::string (*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN4Item11getPlayerIDEv"));
//HOOK_LIB("libcocos2dcpp.so", "0x820EDC", itemPickup_hook, old_itemPickup);
HOOK_LIB("libcocos2dcpp.so",
         "0x824604",
         addItemToWorld_hook,
         old_addItemToWorld);
setpowerType = (void(*)(void*, int))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7POWERUP11setAmmoTypeE8ItemType"));

//HOOKSYM_LIB("libcocos2dcpp.so", "_ZN14NetworkManager21sendDataMessageToPeerEPKviNSt6__ndk112basic_stringIcNS2_11char_traitsIcEENS2_9allocatorIcEEEEb", sendDataMessageToPeer_hook, old_sendDataMessageToPeer);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Joypad4fireEv", isfire, old_isfire);
sharedDirector_t = (void* (*)())dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7cocos2d10CCDirector14sharedDirectorEv"));
getWinSize = (CCSize (*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7cocos2d10CCDirector10getWinSizeEv"));

getBodyVelocity = (void (*)(Vec4*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN17SoldierController15getBodyVelocityEv"));

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN24NetworkMessageDispatcher21getCustomRoomKickDataENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEi", getCustomRoomKickData_hook, old_getCustomRoomKickData);

addAlert = (void (*)(void*, std::string))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN5Radar23findCollisionObjectByIdENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE"));
removeAlert = (void (*)(void*, std::string))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN5Radar11removeAlertENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE"));

shouldSpawnItem = (void(*)(void*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN13WeaponManager15shouldSpawnItemEP6Weapon"));

//addAlert = (void (*)(void*, std::string))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN5Radar8addAlertENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEE"));

Deagle6create = (void* (*)())dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN10RIOTSHIELD6createEv"));


getWeaponRange = (int(*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN6Weapon8getRangeEv"));

applyWeaponMods = (void(*)(void*, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN17SoldierController15applyWeaponModsEP6Weapon"));


PATCH("0x680a10", "ea000004");

CCNode_getParent = (void*(*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN7cocos2d6CCNode9getParentEv"));

createWorldIndicator = (void* (*)(void*, void*, cpVect, Color3B, std::string&))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN5Radar20createWorldIndicatorEPN7cocos2d6CCNodeE6cpVectNS0_10_ccColor3BENSt6__ndk112basic_stringIcNS5_11char_traitsIcEENS5_9allocatorIcEEEE"));

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN5Radar10updateStepEf", radar, Old_radar);

getPeerID = (std::string (*)(void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN17SoldierController9getPeerIDEv"));

HOOK_LIB("libcocos2dcpp.so",
         "0x7B07B0",
         addRemotePlayer_hook,
         old_addRemotePlayer);


getSoldierViewP = (void*(*)(void *))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN17SoldierController11getViewNodeEv"));   
onRadarAlert = (void(*)(void *, void*))dlsym(dlopen(targetLibName, 4), ENC_RT("_ZN5Radar12onRadarAlertEPN7cocos2d8CCObjectE"));   

    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
    /*if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;Boostview
        *p = 0;
    }*/

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_Player info"),
          
            OBFUSCATE("TextListValue_Health_0"), 
            OBFUSCATE("TextListValue_Boost_1"), 
            OBFUSCATE("TextListValue_Dist_2"), 
            OBFUSCATE("TextListValue_Enemys.._7"), 
            OBFUSCATE("TextListValue_Address_5"), 
            OBFUSCATE("TextListValue_PositionsX_3"), 
            OBFUSCATE("TextListValue_PositionsY_4"), 
            OBFUSCATE("TextListValue_ScanResult_6"), // <--- NEW: Show Scan Result (Index 6)
		    OBFUSCATE("-7_Toggle_Enable Floating Box"),
            
   
            
            OBFUSCATE("Category_Aimbot"), //Not counted
            OBFUSCATE("1_Toggle_AIMBOT"),
            OBFUSCATE("65_Toggle_Aim Only Visible Target"),
            OBFUSCATE("66_Toggle_Auto Fire Advanced"),
            OBFUSCATE("2_Button_Teleport"),
            OBFUSCATE("13_SeekBar_Speed_0.0000_5.0000"),
            OBFUSCATE("14_SeekBar_Game Speed_0.0000_10.0000"),
            OBFUSCATE("12_Button_Get Adrasss"),
            OBFUSCATE("-65_Button_COPY ID"),
            OBFUSCATE("17_Toggle_Tell Nade"),
            OBFUSCATE("18_Toggle_Magic Melli"),
            OBFUSCATE("19_Toggle_High Melee Length"),
            OBFUSCATE("20_Toggle_Hide Punch"),
            OBFUSCATE("23_Button_Spewn Weapon"),
            OBFUSCATE("24_Button_radar"),
            OBFUSCATE("25_Button_Add Shild"),
            
            OBFUSCATE("3_Toggle_Auto Punch"),
            OBFUSCATE("5_Toggle_Auto Nade"),
            OBFUSCATE("4_InputValue_Enter MapID"),
            OBFUSCATE("21_Button_Seend MI"),
            OBFUSCATE("22_Button_Draw Line"),
            
            
            OBFUSCATE("Collapse_Hook"),
            OBFUSCATE("6_CollapseAdd_InputText_Input Offset"),
            OBFUSCATE("7_CollapseAdd_Toggle_Hook"),
            OBFUSCATE("16_CollapseAdd_InputText_Offset to call"),
            OBFUSCATE("15_CollapseAdd_Toggle_Call Void"),
            
            OBFUSCATE("CollapseAdd_Category_Pointer Scanner"),     
            OBFUSCATE("8_CollapseAdd_InputText_Start Addr (Hex)"),
            OBFUSCATE("9_CollapseAdd_InputText_Target Addr (Hex)"),
            OBFUSCATE("10_CollapseAdd_InputValue_Max Range (Hex)"), 
            OBFUSCATE("11_CollapseAdd_Toggle_Start Scan"), // Changed to Toggle so you can 
            
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, 
                                        jint value1, jint value2, jint value3, jint value4,
                                        jboolean boolean, jstring str, jlong jng, jshort sht, jdouble dub) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value1,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
       case 1:
    isAimbot = boolean;
          break;
    case 2:
    isteleport = true;
    break;
    case 3:
    automille = boolean;
    break;
    case 4:
    mapvoteV = value1;
    break;
    case 5:
    autothrowg = boolean;
    break;
    case 6:
    VM.offsetToHookVoid = env->GetStringUTFChars(str, 0);
   
    break;
    case 7:
    VM.VoidHook = boolean;
    if (VM.offsetToHookVoid == NULL){
   
    } else if(VM.VoidHook){
   VirusmodzHook("libcocos2dcpp.so", VM.offsetToHookVoid, VoidHook, old_VoidHook);
   if(VM.offsetToCallVoid != NULL){
   callvoid = (void (*)(void *))getAbsoluteAddress("libcocos2dcpp.so", string2Offset(VM.offsetToCallVoid));
    }
    }
   // PatchVoidLong = (void (*)(void *, long))getAbsoluteAddress(NM.libname, string2Offset(NM.offsetToHookVoidLong));
    break;
    
    case 8: 
            Scanner.startAddress = HexToAddr(env->GetStringUTFChars(str, 0));
            break;
            
       case 9: 
            Scanner.targetAddress = HexToAddr(env->GetStringUTFChars(str, 0));
            break;
            
       case 10: 
            Scanner.maxRange = value1; 
            break;
            
       case 11: 
            if (boolean) {
                StartScanAsync();
            } else {
                StopScan();
            }
            break;
       case 12:
           isadrasss = true;
           isadrasssEP = true;
           isadtaszboost = true;
           isadrasss2 = true;
           break;
       case 13:
      isplayerspeed = dub;
       break;
       case 14:
       istimescal = dub;
       break;
       case 16:
    VM.offsetToCallVoid = env->GetStringUTFChars(str, 0);
    break;
    case 15:
    VM.iscallvoid = boolean;
    break;
    case 17:
  tpnadeto = boolean;
    break;
    case 18:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x4f1888", "00 1A B7 EE", boolean);
    break;
    case 19:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon14getMeleeLengthEv", "FF 0F 0F E3 1E FF 2F E1", boolean);
    
    break;
    case 20:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN14NetworkManager15sendPlayerPunchEPN7cocos2d8CCObjectE", "01 00 A0 E3 1E FF 2F E1", boolean);
     break;
     
     case 21:
     isseendmi = true;
     break;
     case 65:
     isaimonly = boolean;
     break;
     case 66:
     isautof = boolean;
     break;
     case 22:
     isdrawL = true;
     break;
     case 23:
     callone = true;
     break;
     case 24:
     create = true;
     break;
     case 25:
     applyi = true;
     break;
     
     
     
     
    }
    }


__attribute__((constructor))
void lib_main() {
InitializeLogger();
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
          //  {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IIIIZLjava/lang/String;JSD)V"), reinterpret_cast<void *>(Changes)},
    
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IIIIZLjava/lang/String;JSD)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

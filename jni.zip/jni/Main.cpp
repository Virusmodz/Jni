#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <string>
#include <map>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "Includes/enc.h"

//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"






 
 

// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    
    ProcMap il2cppMap;
 
    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    


#else //To compile this code for armv7 lib only.

    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
  /*  if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;
        *p = 0;
    }*/
    
    

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
        
        OBFUSCATE("Collapse_Profile"),
        OBFUSCATE("1_CollapseAdd_Toggle_Unlimited Gems"),
        OBFUSCATE("3_CollapseAdd_Toggle_Buy Item"),
        OBFUSCATE("2_CollapseAdd_Toggle_True_Remove Ads"),
        
        OBFUSCATE("Collapse_Team"),
        OBFUSCATE("4_CollapseAdd_Toggle_Unlimited Gold"),
        OBFUSCATE("5_CollapseAdd_Toggle_Unlimited Population"),
        OBFUSCATE("6_CollapseAdd_Toggle_Fast Build"),
        OBFUSCATE("9_CollapseAdd_Toggle_Spell Active"),
        OBFUSCATE("10_CollapseAdd_Toggle_Apply Healing"),
        OBFUSCATE("30_CollapseAdd_Toggle_Free Build"),
        OBFUSCATE("16_CollapseAdd_Spinner_Activate Spells_Miner Gold Rush,Swordwrath Rage,Archidon Rain,Spearton Madness,Spawn Meric,Statue Turret,Golden Spearton,The Elite,The Ancient Giant,Basic Loot Box,Lightning Storm,Training Haste,Raise Gold,Summon Dead Thrower,Summon Pouncer,Summon Stone Giant,Summon Golden Archidon,Summon Kai,Heal,Loot Box 2,Loot Box 3,Loot Box 4"),
        OBFUSCATE("17_CollapseAdd_Button_Activate"),
       
        OBFUSCATE("27_CollapseAdd_Spinner_Spawn Units_Minion,Swordwrath,Archer,Spearton,Magikill,Giant,Miner,Statue,Swordwrath General,Giant Boss,Giant Leader,Spearton Gold,Spearton Elite,Archer Elite,Barricade,Zombie,Zombie Riser,Zombie Tank,Zombie Thrower,Zombie Runner,Zombie Riser Crawler,Zombie Kai,Meric,Zombie Leader,Zombie Tank Leader,Spearton Atreyos,Swordwrath Endless Deads,Zombie Kai Giant,Zombie Stone Giant,King,Archer Golden,Castle Archer"),
        OBFUSCATE("28_CollapseAdd_Button_Spawn Team"),
     //   OBFUSCATE("29_CollapseAdd_Button_Spawn Enemy"),
        
        OBFUSCATE("Collapse_Team Abilities"),
        OBFUSCATE("18_CollapseAdd_Toggle_Maximum Hit Range"),
        OBFUSCATE("19_CollapseAdd_Toggle_God Mod"),
        OBFUSCATE("20_CollapseAdd_Toggle_One Hit Kill"),
        OBFUSCATE("31_CollapseAdd_Toggle_Repid Mining"),
        OBFUSCATE("15_CollapseAdd_SeekBar_Attack Speed_0_50"),//9
        OBFUSCATE("32_CollapseAdd_SeekBar_Run Speed_0_50"),//9
        
        OBFUSCATE("Collapse_Enemy"),
        OBFUSCATE("11_CollapseAdd_Toggle_Burn Enemy"),
        OBFUSCATE("12_CollapseAdd_Toggle_Slow Enemy"),
        OBFUSCATE("13_CollapseAdd_Toggle_Stun Enemy"),
        OBFUSCATE("14_CollapseAdd_Toggle_Poison Enemy"),
        
        OBFUSCATE("Collapse_Game"),
        OBFUSCATE("7_CollapseAdd_Toggle_Win"),
        OBFUSCATE("8_CollapseAdd_Toggle_Instant Upgradel"),
        OBFUSCATE("33_CollapseAdd_Toggle_Unlokd Level"),
        
        
        
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        
            
         
    }
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("Info"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Info)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

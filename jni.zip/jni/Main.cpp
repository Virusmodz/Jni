#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <string>
#include <map>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "Unity/Vector2.h"
#include "Unity/Vector3.h"
#include "Unity/Rect.h"
#include "Unity/Color.h"
#include "Unity/Quaternion.h"
#include "Includes/MonoString.h"
#include "Includes/Strings.h"
#include "Includes/RainbowColor.h"
#include "Includes/Chams.h"
#include "Hooks.h"
#include "Includes/ESP.h"
#include "Includes/ESPManager.h"
#include "Includes/enc.h"
#include <cmath>   // C++ math functions (atan2, etc.)
#include <set>
#include <string>
#include <jni.h>
#include <thread>  // Include for sleep function
#include <chrono>  // Include for duration
#include <atomic>  // Include for atomic boolean control
#include <dlfcn.h>
#include <string>
#include <map>
#include <vector>
#include <algorithm>
#include <mutex>
#include <locale>
#include <codecvt>
#include <sstream>
#include <dlfcn.h>
#include <iostream>
#include <string>
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <jni.h>
#include <string>
#include <android/log.h>
#include <sstream>
#include <iomanip>
#include <cctype>
#include <string>
#include <fstream>
#include <sstream>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <unistd.h>
// only this function changed minimally to add automatic failover
// parallel race version: first successful endpoint wins
#include <atomic>
#include <future>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include <atomic>
#include <thread>
#include <condition_variable>
#include <chrono>
#include <vector>
#include <string>
//Target lib here
#define targetLibName OBFUSCATE("libcocos2dcpp.so")

#include "Includes/Macros.h"

bool ServerLogin = false;
#include "loginUtils/json.hpp"
#include <iostream>
#include <string>

using json = nlohmann::json;
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>

#include <jni.h>
#include <string>
#include <android/log.h>

using namespace std::chrono;

#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <set>
#include <cctype>
#include <algorithm>

// SafeEnemyList.h
// C++17 - drop-in replacement for your enemy list / teleport helper
// Notes:
//  - Requires an implementation of `bool isdead(void* inst)` available at link time.
//  - Use LOGD(...) or replace with your favourite logging macro to trace crashes.
//  - Designed to minimize locking while calling into game code.

#pragma once

#include <vector>
#include <algorithm>
#include <mutex>
#include <cstddef>
#include <cstdint>
#include <iostream>

// Replace LOGD with your game's logging (Android: __android_log_print)


// Forward: you must provide this function (game-specific)


#ifndef LOGD
#define LOGD(...) ((void)0)
#endif

static inline std::string ltrim(std::string s) {
    s.erase(s.begin(), std::find_if(s.begin(), s.end(), [](unsigned char c){return !std::isspace(c);})); 
    return s;
}
static inline std::string rtrim(std::string s) {
    s.erase(std::find_if(s.rbegin(), s.rend(), [](unsigned char c){return !std::isspace(c);}).base(), s.end());
    return s;
}
static inline std::string trim(std::string s) { return rtrim(ltrim(s)); }
static inline bool starts_with(const std::string& s, const std::string& pre) {
    return s.size() >= pre.size() && std::equal(pre.begin(), pre.end(), s.begin());
}
static inline bool file_exists(const char* path) {
    struct stat st; return ::stat(path, &st) == 0;
}

bool isVPNConnected() {
    // Common VPN prefixes
    const std::vector<std::string> vpnPrefixes = {"tun", "tap", "ppp", "wg", "ipsec", "vpn"};
    // Whitelist of normal ifaces (don’t flag these)
    const std::vector<std::string> normalPrefixes = {"wlan", "rmnet", "ccmni", "eth", "usb", "p2p", "lo"};

    auto looksLikeVpn = [&](const std::string& ifn)->bool {
        for (auto& p : vpnPrefixes) if (starts_with(ifn, p)) return true;
        // tunX/tapX/pppX style
        if (ifn.size() >= 4) {
            std::string b = ifn.substr(0,3);
            if ((b=="tun"||b=="tap"||b=="ppp") && std::isdigit((unsigned char)ifn[3])) return true;
        }
        return false;
    };
    auto isNormal = [&](const std::string& ifn)->bool {
        for (auto& p : normalPrefixes) if (starts_with(ifn, p)) return true;
        return false;
    };

    // ---- Method 1: /proc/net/dev ----
    {
        std::ifstream f("/proc/net/dev");
        if (f.is_open()) {
            std::string line;
            while (std::getline(f, line)) {
                if (line.empty()) continue;
                if (line.find(':') == std::string::npos) continue;
                if (line.find("Inter-|") != std::string::npos) continue;
                size_t c = line.find(':');
                std::string iface = trim(line.substr(0, c));
                if (looksLikeVpn(iface)) {
                    LOGD("VPN via /proc/net/dev: %s", iface.c_str());
                    return true;
                }
                // ignore typical non-VPNs
                if (isNormal(iface)) continue;
            }
        } else {
            LOGD("Cannot open /proc/net/dev");
        }
    }

    // ---- Method 2: /proc/net/tun (active tun list) ----
    if (file_exists("/proc/net/tun")) {
        std::ifstream tf("/proc/net/tun");
        if (tf.is_open()) {
            std::string line;
            // often has a header line
            std::getline(tf, line);
            while (std::getline(tf, line)) {
                line = trim(line);
                if (!line.empty()) {
                    LOGD("Active TUN line in /proc/net/tun: %s", line.c_str());
                    return true;
                }
            }
        }
    }

    // ---- Method 3: /sys/class/net (list ifaces) ----
    if (DIR* d = ::opendir("/sys/class/net")) {
        struct dirent* ent;
        while ((ent = ::readdir(d)) != nullptr) {
            if (ent->d_name[0] == '.') continue;
            std::string iface = ent->d_name;
            if (looksLikeVpn(iface)) {
                LOGD("VPN via /sys/class/net: %s", iface.c_str());
                ::closedir(d);
                return true;
            }
        }
        ::closedir(d);
    }

    // ---- Method 3b: WireGuard proc (some kernels) ----
    if (file_exists("/proc/net/wireguard")) {
        std::ifstream wg("/proc/net/wireguard");
        if (wg.is_open()) {
            std::string line;
            while (std::getline(wg, line)) {
                if (!trim(line).empty()) {
                    LOGD("WireGuard present via /proc/net/wireguard");
                    return true;
                }
            }
        }
    }

    // ---- Method 4: routing table (/proc/net/route) ----
    {
        std::ifstream rf("/proc/net/route");
        if (rf.is_open()) {
            std::string line;
            // skip header
            std::getline(rf, line);
            while (std::getline(rf, line)) {
                if (line.empty()) continue;
                std::istringstream iss(line);
                std::string iface, dest, gateway, flags;
                // columns: Iface Destination Gateway Flags RefCnt Use Metric Mask MTU Window IRTT
                iss >> iface >> dest >> gateway >> flags;
                if (iface.empty()) continue;

                if (looksLikeVpn(iface)) {
                    LOGD("VPN route via iface: %s", iface.c_str());
                    return true;
                }
                // default route through unusual interface (not typical Wi-Fi/cell/lo)
                if (dest == "00000000") {
                    if (!isNormal(iface)) {
                        LOGD("Suspicious default route via %s", iface.c_str());
                        return true;
                    }
                }
            }
        }
    }

    LOGD("No VPN interfaces detected");
    return false;
}

// Function to check if an internet connection is active
bool isInternetConnected() {
    // Use a well-known public IP (Google DNS)
    const char* testIP = "8.8.8.8"; // Google DNS IP
    int testPort = 53;              // DNS port (always open)

    // Create a socket
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return false;

    sockaddr_in server{};
    server.sin_family = AF_INET;
    server.sin_port = htons(testPort);
    inet_pton(AF_INET, testIP, &server.sin_addr);

    // Set a 2-second timeout
    struct timeval timeout;
    timeout.tv_sec = 2;
    timeout.tv_usec = 0;
    setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));

    // Try to connect
    bool connected = (connect(sock, (struct sockaddr*)&server, sizeof(server)) == 0);
    close(sock);
    return connected;
}



/***ESP VARIABLE DON'T REMOVE***/
KingEsp es;
ESPManager *espManager;
/*******END********/

/*******ESP SETTINGS VARAIBLES******/
struct Value {
int PositionLine = 0;
int CrossSize = 30;
float TextSize = 15.0f;
Color Espcolor = Color::Red();
Color MyEspcolor = Color::Red();
float Thickness = 2.0f;
} Setting;
/******END******/

struct My_Patches {
 MemoryPatch lagitshealf; 
} hexPatches;

float isboost = 0;



bool isAimbot;
bool isteleport;
int switc = 0;
bool telllkilltime;
bool Autolag;
float isplayerspeed;

bool isfring = false;
bool modified = false;
float getXpositiont;
float getYpositiont;

bool isteleportenemy;
bool isteleportenemy2;
float teleportX;
float teleportY;
bool isbulletspeed;
bool isdisappear;
bool maxplauers;

typedef struct cpVect {
    float x, y;
} cpVect;

bool iscrouch = false;
const char *g_replacement = "VirusModz";

bool isteleport2;

int IsIgnoreTeam;
float getfirdsingde;
bool bullet_trake;
bool dual_fire;
bool setnae;
bool showenemyl;
void* enemyPlayex = NULL;
// my player instance
void* localPlayer = NULL;

// Store all enemy players
std::vector<void*> enemyPlayers;

constexpr float PI_F = 3.14159265358979323846f;

// Function declarations
//get position x y 
float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);

void (*activatePlayer)(void *instance);
void (*deactivatePlayer)(void *instance);


void (*addWeapon)(void* instance, void *weapons);

void (*setPlayerName_hook)(void* self, std::string name);

bool ischi;
bool sendmas;
bool isseendpunc;
float setWeaponrate;

bool isammos;

bool isbulletrenge;

std::string sendmasage;

std::string names;

float istimescal;

bool smap_SMS;

bool Isbulletrenhe = false;
int IsRoundsPerFire = 0;

void (*old_setMaxPlayers)(void *instance, int pl);
void setMaxPlayers(void *instance, int pl){
if (instance != NULL){
if (maxplauers){
old_setMaxPlayers(instance, 12);
}


}
return old_setMaxPlayers(instance, pl);
}

int (*old_RoundsPerFire)(void *instance);
int RoundsPerFire(void *instance) {
    if (instance != NULL && IsRoundsPerFire > 0) {
          return IsRoundsPerFire;
    }
    return old_RoundsPerFire(instance);
}
float (*old_bulletrenhe)(void *instance);
float bulletrenhe(void *instance) {
    if (instance != NULL && Isbulletrenhe) {
          return 999999;
    }
    return old_bulletrenhe(instance);
}
    

void (*old_CCScheduler)(void *instance, float timespeed);
void CCScheduler(void *instance, float timespeed){

float gettis = timespeed * istimescal;

if(instance != NULL){
if (istimescal > 0){
old_CCScheduler(instance, gettis);

}


static auto last_call = std::chrono::steady_clock::now();

if (Autolag) {
    auto now = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_call);

    if (elapsed.count() >= 2000) {
        if (modified) {
            hexPatches.lagitshealf.Restore();
            modified = false;
        } else {
            hexPatches.lagitshealf.Modify();
            modified = true;
        }
        last_call = now;
    }
} else {
    // Automatically restore if Autolag is turned off
    if (modified) {
        hexPatches.lagitshealf.Restore();
        modified = false;
    }
}


}
return old_CCScheduler(instance, timespeed);

}




float (*old_playerspeed)(void *instance);
float playerspeed(void *instance){
if (instance != NULL) {
if(isplayerspeed > 0){

return (float) isplayerspeed;
}

}

return old_playerspeed(instance);

}



void (*setRatew)(void *instance, float set);

void (*setClip)(void *instance, int ammo);

void (*setRangeMod)(void *instance, float speed);

void (*setRangeMod2)(void *instance, float speed);

void (*old_wepan)(void* instance, float dt);
void wepan(void *instance, float dt){

if (instance != NULL){
if (setWeaponrate > 0){
setRatew(instance, setWeaponrate);
}
if (isammos){
setClip(instance, 99);

}
if (isbulletspeed){
setRangeMod(instance, 1.25);
} else {
setRangeMod(instance, 1);
}
if (isbulletrenge){
setRangeMod2(instance, 1.25);
} else {
setRangeMod2(instance, 1);
}
}
return old_wepan(instance, dt);

}


// minimal ccColor3B (same layout as cocos2d)

struct ccColor3B { uint8_t r, g, b; };


void (*HUD_addMessage_t)(void* self, std::string text, ccColor3B color, short timeSec);

void (*showLabel)(void *instance);





void (*old_HUD)(void* instance, float dt);
void HUD(void *instance, float dt){
if(instance != NULL){
ccColor3B white = {0, 0, 0};
if (smap_SMS){

HUD_addMessage_t(instance, sendmasage, white, 5);


}


}
return old_HUD(instance, dt);
}


void (*t_sendDataMessage)(void* self, const void* data, int len, std::string msg, bool flag);

void (*sendPlayerPunch)(void* instance, void *CCObject);

void (*old_updateNetworkObjects)(void* instance, float xd);
void updateNetworkObjects(void* instance, float xd) {

if(instance != NULL){
if (isseendpunc){
sendPlayerPunch(instance, instance);
}

}

return old_updateNetworkObjects(instance, xd);
}

void (*old_lSoldierView)(void* instance, float xd);
void lSoldierView(void* instance, float xd){
if(instance != NULL){

if(setnae){
setPlayerName_hook(instance, std::string(names));

}
if (showenemyl){
showLabel(instance);
}


}
return old_lSoldierView(instance, xd);

}




void (*setPositionX)(void* instance, float posx);
void (*setPositionY)(void* instance, float pozy);

void* (*getPlayerView)(void* instance);

void *(*getEnemyView)(void* instance);
bool (*iscrousg)(void* instance);

bool (*isdead)(void* instance);
int (*isAaly)(void* instance);
float CalculateDistance(void* player1, void* player2);

int (*getTeamId)(void* instance);


bool (*old_isfire)(void* instance);
bool isfire(void* instance){
if(instance != NULL){

isfring = old_isfire(instance);

} 
return old_isfire(instance);

} 
int WeaponID = 0;

void *(*pObject)();

void *(*Deagle6create)();         //_ZN6DEAGLE6createEv
void *(*Magnum6create)();         //_ZN6MAGNUM6createEv
void *(*Tec96create)();           //_ZN4TEC96createEv
void *(*GdDeagle6create)();       //_ZN7GDEAGLE6createEv
void *(*Uzi6create)();            //_ZN3UZI6createEv
void *(*Mp56create)();            //_ZN2MP56createEv
void *(*Tavor6create)();          //_ZN5TAVOR6createEv
void *(*Ak476create)();           //_ZN5AK476createEv
void *(*Xm86create)();            //_ZN3XM86createEv
void *(*M166create)();            //_ZN4M166createEv
void *(*Aa126create)();           //_ZN4AA126createEv
void *(*Spas126create)();         //_ZN6SPAS126createEv
void *(*M18816create)();          //_ZN6M18816createEv
void *(*M146create)();            //_ZN4M146createEv
void *(*M93ba6create)();          //_ZN6M93BA6createEv
void *(*Flamethrower6create)();   //_ZN10FLAMETHROWER6createEv
void *(*Rg66create)();            //_ZN2RG66createEv
void *(*Smaw6create)();           //_ZN4SMAW6createEv
void *(*Sawgun6create)();         //_ZN6SAW6createEv
void *(*Minigun6create)();        //_ZN7MINIGUN6createEv
void *(*Machete6create)();        //_ZN7MACHETE6createEv
void *(*FlagBlue6create)();       //_ZN8FLAGBLUE6createEv
void *(*FlagOrange6create)();     //_ZN9FLAGORANGE6createEv
void *(*BombBlue6create)();       //_ZN8BOMBBLUE6createEv
void *(*BombOrange6create)();     //_ZN9BOMBORANGE6createEv
void *(*Phasr6create)();          //_ZN5PHASR6createEv


static std::vector<void*> g_enemyList;
static size_t g_currentTargetIndex = 0;
static std::mutex g_enemyMutex;

// ---------- Utility: lock-copy the enemy list ----------
static std::vector<void*> snapshotEnemyList() {
    std::lock_guard<std::mutex> lk(g_enemyMutex);
    return g_enemyList; // cheap copy of vector of pointers
}

// ---------- Check if an instance already present ----------
static bool enemyInList(void* inst) {
    if (!inst) return false;
    std::lock_guard<std::mutex> lk(g_enemyMutex);
    return std::find(g_enemyList.begin(), g_enemyList.end(), inst) != g_enemyList.end();
}

// ---------- Add enemy if not present ----------
static void addEnemyToList(void* inst) {
    if (!inst) return;
    std::lock_guard<std::mutex> lk(g_enemyMutex);
    if (std::find(g_enemyList.begin(), g_enemyList.end(), inst) == g_enemyList.end()) {
        g_enemyList.push_back(inst);
        LOGD("Added enemy %p, new size=%zu", inst, g_enemyList.size());
    }
}

// ---------- Remove enemy by pointer (safe index adjust) ----------
static void removeEnemyFromList(void* inst) {
    if (!inst) return;
    std::lock_guard<std::mutex> lk(g_enemyMutex);
    auto it = std::find(g_enemyList.begin(), g_enemyList.end(), inst);
    if (it == g_enemyList.end()) {
        return;
    }
    size_t idx = static_cast<size_t>(std::distance(g_enemyList.begin(), it));
    g_enemyList.erase(it);
    // Adjust g_currentTargetIndex safely
    if (g_currentTargetIndex > 0 && idx < g_currentTargetIndex) {
        --g_currentTargetIndex;
    }
    if (g_currentTargetIndex >= g_enemyList.size()) {
        g_currentTargetIndex = 0;
    }
    LOGD("Removed enemy %p (idx=%zu), new size=%zu, curIdx=%zu",
         inst, idx, g_enemyList.size(), g_currentTargetIndex);
}

// ---------- Clear entire list (map change / respawn) ----------
static void clearEnemyList() {
    std::lock_guard<std::mutex> lk(g_enemyMutex);
    g_enemyList.clear();
    g_currentTargetIndex = 0;
    LOGD("Cleared enemy list");
}

// ---------- Purge nullptrs only (no game calls) ----------
static void purgeNullsLocked() {
    // Must be called while holding lock if used; provided for internal use.
    g_enemyList.erase(std::remove(g_enemyList.begin(), g_enemyList.end(), nullptr),
                      g_enemyList.end());
    if (g_currentTargetIndex >= g_enemyList.size()) g_currentTargetIndex = 0;
}

// ---------- getNextAliveEnemy (safe version) ----------
static void* getNextAliveEnemy() {
    // 1) Snapshot list under lock (fast)
    std::vector<void*> snapshot = snapshotEnemyList();
    if (snapshot.empty()) {
        return nullptr;
    }

    // 2) capture a stable local start index based on global state
    size_t localStart = 0;
    {
        std::lock_guard<std::mutex> lk(g_enemyMutex);
        if (!g_enemyList.empty()) {
            // keep index within [0..size-1]
            localStart = g_currentTargetIndex % g_enemyList.size();
        } else {
            localStart = 0;
        }
    }

    // 3) iterate the snapshot WITHOUT holding the global lock.
    //    This avoids deadlocks if isdead() calls game code that may call back into our hooks.
    void* chosenInst = nullptr;
    size_t snapshotSize = snapshot.size();
    for (size_t i = 0; i < snapshotSize; ++i) {
        size_t idx = (localStart + i) % snapshotSize;
        void* inst = snapshot[idx];
        if (!inst) continue; // skip null pointers
        // NOTE: isdead may crash if 'inst' is freed. This code reduces race/deadlock risk,
        // but cannot fully prevent deref of freed memory. Best fix = stable IDs or game callbacks.
        bool dead = false;
        // Wrap isdead in a small try-catch? (Segfaults cannot be caught here.)
        dead = isdead(inst);
        if (!dead) {
            chosenInst = inst;
            // We'll set the global next start index to the element AFTER the real list's position
            // (translated later while holding lock).
            break;
        }
    }

    if (!chosenInst) {
        // No alive entity found in snapshot. Purge nulls from master list (no isdead calls).
        {
            std::lock_guard<std::mutex> lk(g_enemyMutex);
            purgeNullsLocked();
        }
        return nullptr;
    }

    // 4) Translate chosenInst into real-list index and update global g_currentTargetIndex
    {
        std::lock_guard<std::mutex> lk(g_enemyMutex);
        auto itReal = std::find(g_enemyList.begin(), g_enemyList.end(), chosenInst);
        if (itReal == g_enemyList.end()) {
            // chosen instance disappeared between snapshot and update
            if (g_currentTargetIndex >= g_enemyList.size()) g_currentTargetIndex = 0;
        } else {
            size_t realIdx = static_cast<size_t>(std::distance(g_enemyList.begin(), itReal));
            if (!g_enemyList.empty()) {
                g_currentTargetIndex = (realIdx + 1) % g_enemyList.size();
            } else {
                g_currentTargetIndex = 0;
            }
        }
    }

    // 5) Return chosen live pointer (may still be freed immediately after return; caller must be careful)
    return chosenInst;
}

// ---------- Optional helper: pickNextAliveAndTeleport(callback) ----------
// Example usage: pass a lambda that performs teleport given a live enemy pointer.
// This will validate before calling and gives a single safe call site for teleport.
template <typename TeleportFn>
static bool pickNextAliveAndTeleport(TeleportFn teleport) {
    void* target = getNextAliveEnemy();
    if (!target) {
        LOGD("No target found to teleport to");
        return false;
    }
    // Teleport is executed by caller-provided function. It is their responsibility to be careful.
    try {
        teleport(target);
    } catch (...) {
        // can't catch native segfaults, but catch C++ exceptions if any
        LOGD("Exception during teleport to %p", target);
        return false;
    }
    return true;
}

void (*old_SoldierLocalController)(void* instance, float dt);
void SoldierLocalController(void* instance, float dt) {
    if (instance != NULL) {
        old_SoldierLocalController(instance, dt);
        //  void *playerView = getPlayerView(instance);  // corrected this line
        //  void* body = *(void**)((char*)instance + 0x148);
        localPlayer = instance;
        void *body = *(void **)((char *)instance + 0x148);

        if (body != NULL) {

            float *posX = (float *)((char *)body + 0x2c);
            float *posY = (float *)((char *)body + 0x34);

            if (isteleport) {
                *posX = (float) teleportX;
                *posY = (float) teleportY;
            }

            void *view = getPlayerView(instance);

        }

        void* weapon = NULL;
        if (WeaponID == 1) weapon = Deagle6create();
        else if (WeaponID == 2) weapon = Magnum6create();
        else if (WeaponID == 3) weapon = Tec96create();
        else if (WeaponID == 4) weapon = GdDeagle6create();
        else if (WeaponID == 5) weapon = Uzi6create();
        else if (WeaponID == 6) weapon = Mp56create();
        else if (WeaponID == 7) weapon = Tavor6create();
        else if (WeaponID == 8) weapon = Ak476create();
        else if (WeaponID == 9) weapon = Xm86create();
        else if (WeaponID == 10) weapon = M166create();
        else if (WeaponID == 11) weapon = Aa126create();
        else if (WeaponID == 12) weapon = Spas126create();
        else if (WeaponID == 13) weapon = M18816create();
        else if (WeaponID == 14) weapon = M146create();
        else if (WeaponID == 15) weapon = M93ba6create();
        else if (WeaponID == 16) weapon = Flamethrower6create();
        else if (WeaponID == 17) weapon = Rg66create();
        else if (WeaponID == 18) weapon = Smaw6create();
        else if (WeaponID == 19) weapon = Sawgun6create();
        else if (WeaponID == 20) weapon = Minigun6create();
        else if (WeaponID == 21) weapon = Machete6create();
        else if (WeaponID == 22) weapon = FlagBlue6create();
        else if (WeaponID == 23) weapon = FlagOrange6create();
        else if (WeaponID == 24) weapon = BombBlue6create();
        else if (WeaponID == 25) weapon = BombOrange6create();
        else if (WeaponID == 26) weapon = Phasr6create();

        if (weapon != NULL) {
            addWeapon(instance, weapon);
            WeaponID = 0;
        }

        if (isdisappear && !isdead(instance)) {
            deactivatePlayer(instance);
            isdisappear = false;
        } else if (isdisappear && isdead(instance)) {
            activatePlayer(instance);
            isdisappear = false;
        }

        static auto last_call = std::chrono::steady_clock::now();

        if (isteleportenemy2 && body != NULL) {
            void* targetEnemy2 = getNextAliveEnemy();

            if (targetEnemy2 != nullptr) {                       // <- was || returned before; now we only proceed when valid
                // Get target enemy body and its pos
                void* targetBody = *(void **)((char *)targetEnemy2 + 0x148);
                if (targetBody == NULL) {
                    // it might have become invalid; remove but don't return from the outer function
                    removeEnemyFromList(targetEnemy2);
                } else {
                    // read enemy pos
                    float targetX = *(float *)((char *)targetBody + 0x2c);
                    float targetY = *(float *)((char *)targetBody + 0x34);

                    auto now = std::chrono::steady_clock::now();
                    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(now - last_call);

                    if (elapsed.count() >= 3000) {
                        // apply teleport: put local player's body at target position
                        float *posX = (float *)((char *)body + 0x2c);
                        float *posY = (float *)((char *)body + 0x34);

                        // optional: add small offset so you're not overlapping exactly (avoid clipping)
                        const float safeOffset = 0.0f;
                        *posX = targetX + safeOffset;
                        *posY = targetY + safeOffset;

                        last_call = now;
                    }
                }
            }
}
            if (isteleportenemy && body != NULL) {
                void* targetEnemy = getNextAliveEnemy();
                if (targetEnemy == nullptr) {
                    // nothing to teleport to
                    return;
                }

                // Get target enemy body and its pos
                void* targetBody = *(void **)((char *)targetEnemy + 0x148);
                if (targetBody == NULL) {
                    // it might have become invalid; remove and bail
                    removeEnemyFromList(targetEnemy);
                    return;
                }

                // read enemy pos
                float targetX = *(float *)((char *)targetBody + 0x2c);
                float targetY = *(float *)((char *)targetBody + 0x34);

                // apply teleport: put local player's body at target position
                float *posX = (float *)((char *)body + 0x2c);
                float *posY = (float *)((char *)body + 0x34);

                // optional: add small offset so you're not overlapping exactly (avoid clipping)
                const float safeOffset = 0.0f;
                *posX = targetX + safeOffset;
                *posY = targetY + safeOffset;

                isteleportenemy = false;
            }

            // minimal, self-contained fix for "auto call"

            // NOTE: do NOT return here — allow the hooked function to continue normally
        }

    

    return old_SoldierLocalController(instance, dt);
}

void (*old_SoldierRemoteController)(void* instance, float dt);
void SoldierRemoteController(void* instance, float dt) {
    if (instance != NULL) {
    void *playerView = getEnemyView(instance);
    enemyPlayex = instance;
    
            void *body = *(void **)((char *)instance + 0x148);
    
     
        if (body != NULL && !isdead(instance) && getTeamId(localPlayer) > 1 && getTeamId(instance) != getTeamId(localPlayer) ) {
        // add to the enemy list if not already present
        addEnemyToList(instance);
        // optionally you could cache position here if you prefer storing positions instead of instances
    } else if(body != NULL && !isdead(instance) && getTeamId(localPlayer) == 1 ){
        // dead or no body -> remove from list if present
        
		addEnemyToList(instance);
    } else {
		removeEnemyFromList(instance);
		
	}
        // Add to enemy list if not already present
        if (std::find(enemyPlayers.begin(), enemyPlayers.end(), instance) == enemyPlayers.end() && !isdead(instance)) {
            enemyPlayers.push_back(instance);
        }
            if (isteleport){
    setPositionX(playerView, 2000);
    
    }
    }
    return old_SoldierRemoteController(instance, dt);
}

// Helper function to calculate distance between two players
float CalculateDistance(void* player1, void* player2) {
    if (!player1 || !player2) return FLT_MAX;
    
    float x1 = GetPositionX(player1);
    float y1 = GetPositionY(player1);
    float x2 = GetPositionX(player2);
    float y2 = GetPositionY(player2);
    
    float dx = x2 - x1;
    float dy = y2 - y1;
    
    return sqrtf(dx * dx + dy * dy);
}



void* FindClosestAliveEnemy() {
    if (!localPlayer || enemyPlayers.empty()) return NULL;

    // Detect if it's a team match
    std::set<int> teamIds;
    for (auto enemy : enemyPlayers) {
        teamIds.insert(getTeamId(enemy));
    }
    
    if (getTeamId(localPlayer) > 1 && getTeamId(enemyPlayex) == getTeamId(localPlayer)){
    IsIgnoreTeam > 1;
    }else {
    IsIgnoreTeam = 0;
    }
    bool isTeamMatch = (teamIds.size() > IsIgnoreTeam); // More than 1 unique team ID means team match

    void* closestEnemy = NULL;
    float closestDistance = FLT_MAX;

    // Clean up dead enemies and find closest alive one
    for (auto it = enemyPlayers.begin(); it != enemyPlayers.end();) {
        void* enemy = *it;
        
    
        // Remove dead enemies
        if (isdead(enemy)) {
            it = enemyPlayers.erase(it);
            continue;
        }

        // Skip same-team players ONLY if it's a team match
        if (isTeamMatch && getTeamId(enemy) == getTeamId(localPlayer) && getTeamId(localPlayer) > 1) {
            ++it;
            continue;
        }

        // Find closest enemy
        float distance = CalculateDistance(localPlayer, enemy);
        if (distance < closestDistance) {
            closestDistance = distance;
            closestEnemy = enemy;
        }
        ++it;
    }

    return closestEnemy;
}

float (*old_FireAngle)(void* instance);
float FireAngle(void* instance) {
    if (instance != NULL && localPlayer != NULL) {
        float px = GetPositionX(localPlayer);
        float py = GetPositionY(localPlayer);
        
        // Find the closest alive enemy
        void* targetEnemy = FindClosestAliveEnemy();
        
        if (targetEnemy != NULL) {
            float ex = GetPositionX(targetEnemy);
            float ey = GetPositionY(targetEnemy);
            
            float dx = ex - px;
            float dy = py - ey;
            
            float angleRad = atan2f(dy, dx);
            float angleDeg = angleRad * (180.0f / PI_F);
            if (angleDeg < 0) angleDeg += 360.0f;
            getfirdsingde = angleDeg;
            
            // FIXED: Use separate if statements instead of else-if chain
            if (isAimbot && switc == 0) {
                // Normal Aim - always active when aimbot is on
                return angleDeg;
            }
            
            if (isAimbot && switc == 1 && isfring) {
                // Fire Aim - only when shooting
                return angleDeg;
            }
            
            if (isAimbot && switc == 2 && iscrousg(localPlayer)) {
                // Crouch Aim - only when crouching
                return angleDeg;
            }
        }
    }
    return old_FireAngle(instance);
}


float (*old_bullat)(void* instance);
float bullat(void* instance){
    if (instance != NULL){
        if(bullet_trake){
            return getfirdsingde;
        }
    }
    return old_bullat(instance);
}

float (*old_Dualfire)(void* instance);
float Dualfire(void* instance){
    if (instance != NULL){
        if(bullet_trake){
            return getfirdsingde;
        }
    }
    return old_Dualfire(instance);
}



// Optional: Cleanup function to remove all enemies (call this when needed)
void ClearEnemyList() {
    enemyPlayers.clear();
}

void (*old_removebody)(void* instance); // this function call when any Player leave the match or game end
void removebody(void* instance){
if (instance != NULL){
old_removebody(instance);
enemyPlayers.clear();
clearEnemyList();


} 
return old_removebody(instance);
} 

 
 
extern "C"
JNIEXPORT void JNICALL
Java_com_android_support_Menu_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
    es = KingEsp(env, espView, canvas);
}
 
extern "C"
JNIEXPORT void JNICALL
Java_com_android_support_Menu_onGraphValueChanged(JNIEnv *env, jobject thiz, jfloat x, jfloat y) {
  teleportX = x;
   teleportY = y;
}




/*---------function started encrypt url---------------*/
std::string urlEncode(const std::string& value) {
    std::ostringstream encoded;
    encoded << std::hex << std::uppercase;

    for (char c : value) {
        if (std::isalnum(static_cast<unsigned char>(c)) ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            // These characters do not need encoding
            encoded << c;
        } else if (c == ' ') {
            // Encode space as '%20'
            encoded << "%20";
        } else {
            // Encode other characters with '%' followed by their hex value
            encoded << '%' << std::setw(2) << std::setfill('0')
                    << static_cast<int>(static_cast<unsigned char>(c));
        }
    }

    return encoded.str();
}




size_t writeCallback(char *contents, size_t size, size_t nmemb, std::string *userp) {
  userp->append(contents, size * nmemb);
  return size * nmemb;
}



// ================= NEW OPTIMIZED STRUCTURES ================= //

// structure to hold data safely across threads without crashing
struct LoginRaceState {
    std::mutex mtx;
    std::condition_variable cv;
    std::string winnerResponse;
    bool isFinished = false;
    bool isSuccess = false;
    bool isWrongKey = false; // <--- ADD THIS LINE
};
// ================= OPTIMIZED GET FUNCTION ================= //
std::string get(const char *url) {
  CURL *curl;
  CURLcode res;
  std::string response;

  curl = curl_easy_init();
  if (curl) {
    curl_easy_setopt(curl, CURLOPT_URL, url);
    
    // [OPTIMIZATION] Follow redirects
    curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
    
    // [OPTIMIZATION] Skip SSL verify for speed (safe for game mods)
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L);
    curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
    
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
    curl_easy_setopt(curl, CURLOPT_WRITEDATA, &response);
    
    // [OPTIMIZATION] Accept compressed data (faster download)
    curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "gzip, deflate"); 
    
    // [OPTIMIZATION] Force IPv4 (Faster on 4G/5G in India)
    curl_easy_setopt(curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); 

    // [OPTIMIZATION] Timeouts - Crucial for speed!
    // Don't wait more than 3 seconds to connect
    curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT_MS, 3000L);
    // Don't wait more than 5 seconds for the whole process
    curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 5000L);

    // [OPTIMIZATION] No Signals (Prevents random crashes on Android)
    curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);

    res = curl_easy_perform(curl);
    
    if (res != CURLE_OK) {
      // Optional: Log error if needed, but keep it silent for users
      // LOGD("Curl Failed: %s", curl_easy_strerror(res));
      return "";
    }

    curl_easy_cleanup(curl);
  }

  return response;
}

// ================= SUPER ADVANCED LOGIN FUNCTION ================= //
// ================= ADVANCED LOGIN FUNCTION WITH DETAILED TOASTS ================= //
// Note: Assumes 'LoginRaceState' struct and optimized 'get' function are still above this.

std::string login(JNIEnv *env, jobject obj, const char *key) {
    std::string failedLogin = ENC_RT("false");
    
    // --- Detailed Toast Check 1: No Internet ---
    
    // --- Detailed Toast Check 2: VPN ---
    if (isVPNConnected()){
        Toast(env,obj,OBFUSCATE("VPN/Proxy Detected! Please turn off your VPN to log in."), ToastLength::LENGTH_LONG);
        return failedLogin;
    } 
    
    std::string hwid = key;
    std::string LoggedIn = ENC_RT("true");

    static const char* LOGIN_URLS[] = {
        ENC_RT("https://script.google.com/macros/s/AKfycbxDTcYOP1wSSZbCQMdaKCxOBT3C_pq4iHYOBGJJtphUDhYfwSJzJIFCKbrcvXAzHaDf"),
        ENC_RT("https://script.google.com/macros/s/AKfycbzcZw4_6u_eLR4neSOmT0w4jCzTW5G20yx3HepP0gxkL7F_mVkZR87dPPoWbLV8CIo6"),
        ENC_RT("https://script.google.com/macros/s/AKfycbz_Wma4pcEOnTp26LFI40K06F3K-cQ5WKlRdtIqQqZInkb9XNaTjXKnYNenj9DfrFqffA"),
        ENC_RT("https://script.google.com/macros/s/AKfycbzFq-qosm6aetJGpSz_SAFSMDHW4728liI_3N2yvEzP5X-CakI-ss2tpdVXlCmcmvXo")
    };
    const int LOGIN_URLS_COUNT = 4;

    static const char *integrityKey = ENC_RT("minimilitiaclaiic");
    static const char *U1 = ENC_RT("/exec?key=");
    static const char *U3 = ENC_RT("&integrityKey=");

    std::string encodedKey = urlEncode(key);
    std::string fullUrlBase = encodedKey + U3 + integrityKey;

    auto state = std::make_shared<LoginRaceState>();

    // --- Toast: Starting Login Attempt ---
    Toast(env, obj, OBFUSCATE("Connecting to Server..."), ToastLength::LENGTH_SHORT);

    for (int i = 0; i < LOGIN_URLS_COUNT; ++i) {
        std::thread([i, fullUrlBase, key, state]() {
            // Stop if another thread already won
            {
                std::lock_guard<std::mutex> lock(state->mtx);
                if (state->isFinished) return;
            }

            std::string SERVERURL = std::string(LOGIN_URLS[i]) + U1 + fullUrlBase;
            std::string response = get(SERVERURL.c_str());

            if (!response.empty()) {
                try {
                    auto data = json::parse(response);
                    
                    // 1. Check for Success
                    if (data["Status"] == ENC_RT("Success") && data["Username"] == key) {
                        std::lock_guard<std::mutex> lock(state->mtx);
                        if (!state->isFinished) {
                            state->winnerResponse = response;
                            state->isSuccess = true;
                            state->isFinished = true;
                            state->cv.notify_one(); 
                        }
                    } 
                    // 2. Logic for WRONG KEY
                    // If we got a valid JSON response, but it wasn't "Success", the key is wrong.
                    else {
                        std::lock_guard<std::mutex> lock(state->mtx);
                        // We mark this as true, but we don't finish yet (in case another server says yes)
                        state->isWrongKey = true; 
                    }

                } catch (...) {
                    // JSON parsing failed. This is a server/data error, ignore this thread.
                }
            }
        }).detach(); 
    }

    // Wait for winner or timeout (3.5 seconds)
    std::unique_lock<std::mutex> lock(state->mtx);
    if (state->cv.wait_for(lock, std::chrono::milliseconds(3500), [&]{ return state->isFinished; })) {
        if (state->isSuccess) {
            // --- Toast 3: Success ---
            Toast(env,obj,OBFUSCATE("Login Successful! Welcome."),ToastLength::LENGTH_LONG);
            return LoggedIn;
        }
    }

    // Stop waiting
    state->isFinished = true; 
    
    // ================= NEW ERROR HANDLING LOGIC ================= //

    // Scenario A: Server replied, but key was rejected
    if (state->isWrongKey) {
        Toast(env, obj, OBFUSCATE("Access Denied! Your key is invalid or expired."), ToastLength::LENGTH_LONG);
    } 
    // Scenario B: No response received at all (Timeout) or invalid data
    else {
        Toast(env, obj, OBFUSCATE("Server Error: Connection timed out. Try again later."), ToastLength::LENGTH_LONG);
    }

    return failedLogin;
}
// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));
    espManager = new ESPManager();
    
    ProcMap il2cppMap;
 
    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    


#else //To compile this code for armv7 lib only.
//MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x7ad9cc), (void *) halte, (void **) &old_halte);

//HOOK_LIB("libcocos2dcpp.so", "0x7a4108", Boost, old_boost);
HOOK_LIB("libcocos2dcpp.so", "0x7b9b48", lSoldierView, old_lSoldierView);


HOOK_LIB("libcocos2dcpp.so", "0x7a5170", SoldierLocalController, old_SoldierLocalController);
HOOK_LIB("libcocos2dcpp.so", "0x7a4074", bullat, old_bullat);
HOOK_LIB("libcocos2dcpp.so", "0x7a404c", Dualfire, old_Dualfire);

HOOK_LIB("libcocos2dcpp.so", "0x7b2d48", SoldierRemoteController, old_SoldierRemoteController);

HOOK_LIB("libcocos2dcpp.so", "0x5156b8", FireAngle, old_FireAngle);

HOOK_LIB("libcocos2dcpp.so", "0x515c88", isfire, old_isfire);
HOOK_LIB("libcocos2dcpp.so", "0x79e224", removebody, old_removebody);

// inside your init hooking sequence (where other HOOK_LIB are placed)
HOOK_LIB("libcocos2dcpp.so", "0x8128b0", wepan, old_wepan);

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Weapon15getWeightFactorEv", playerspeed, old_playerspeed);


HOOKSYM_LIB("libcocos2dcpp.so", "_ZN18GameCustomizeLayer13setMaxPlayersEi", setMaxPlayers, old_setMaxPlayers);

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN7cocos2d11CCScheduler6updateEf", CCScheduler, old_CCScheduler);

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Weapon8getRangeEv", bulletrenhe, old_bulletrenhe);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Weapon16getRoundsPerFireEv", RoundsPerFire, old_RoundsPerFire);

t_sendDataMessage = (void (*)(void *, const void *, int, std::string, bool))getAbsoluteAddress(targetLibName, 0x5b0e1c); 

HOOK_LIB("libcocos2dcpp.so", "0x5b5384", updateNetworkObjects, old_updateNetworkObjects);
    
HOOK_LIB("libcocos2dcpp.so", "0x4fa4b4", HUD, old_HUD);

HUD_addMessage_t = (void (*)(void *, std::string, ccColor3B, short))getAbsoluteAddress(targetLibName, 0x4f87a8);
setRangeMod2 = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0x813b68);
setRangeMod = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0x813b90);
setRatew = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0x813334);
setClip = (void (*)(void *, int))getAbsoluteAddress(targetLibName, 0x812c30);
showLabel = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x7bd894); 
GetPositionX = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c791); 
GetPositionY = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c79f); 
isdead = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1f8); 
isAaly = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x7ad2b8); 
//getplayersname = (std::string  (*)(void *))getAbsoluteAddress(targetLibName, 0x7bc2ec); 
//0x7ad2b8

hexPatches.lagitshealf = MemoryPatch::createWithHex("libil2cpp.so", 0x5b2108, "01 00 A0 E3 1E FF 2F E1");
getTeamId = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x4361e0); 

getPlayerView = (void* (*)(void *))getAbsoluteAddress(targetLibName, 0x7a4140); 
getEnemyView = (void* (*)(void *))getAbsoluteAddress(targetLibName, 0x7b5728); 

setPlayerName_hook = (void (*)(void *, std::string))getAbsoluteAddress(targetLibName, 0x7bc15c); 

sendPlayerPunch = (void (*)(void *, void *))getAbsoluteAddress(targetLibName, 0x5ae8b4); 

//M93BA = (void* (*)(void *))getAbsoluteAddress(targetLibName, 0x81c3ec); 
activatePlayer = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x7aa694); 
deactivatePlayer = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x7aa73c); 


setPositionX = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0xa9c7ad);
setPositionY = (void (*)(void *, float))getAbsoluteAddress(targetLibName, 0xa9c815);

addWeapon = (void (*)(void *, void*))getAbsoluteAddress(targetLibName, 0x7a4158); 

iscrousg = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79f23c); 


    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    
Deagle6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81ba5c);

Magnum6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81b990);

Tec96create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81bbf4);

GdDeagle6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81bcc0);

Uzi6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81bb28);

Mp56create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81bd8c);

Tavor6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81d178);

Ak476create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81bf24);

Xm86create = (void *(*)())getAbsoluteAddress(targetLibName, 0xa9c791);

M166create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81be58);

Aa126create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c188);

Spas126create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c0bc);

M18816create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c254);

M146create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c320);

M93ba6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c3ec);

Flamethrower6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c8b4);

Rg66create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81d310);

Smaw6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81c980);

Sawgun6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81cfe0);

Machete6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81cb18);

FlagBlue6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81cbe4);

FlagOrange6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81ccb0);

BombBlue6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81cd7c);

BombOrange6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81ce48);

Phasr6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81bff0);

Minigun6create = (void *(*)())getAbsoluteAddress(targetLibName, 0x81d244);




    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
  /*  if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;
        *p = 0;
    }*/
    
    

    return NULL;
}
jobjectArray Login(JNIEnv *env, jobject context) {
    jobjectArray ret;
    

    const char *features[] = {
    OBFUSCATE("Category_Login First"),
    OBFUSCATE("5000_InputTextKey_Input Key"),
    OBFUSCATE("-999_Button_Login"),
    OBFUSCATE("ButtonLink_Get Key_https://virusmodz766.kesug.com/loginfinal.php?users=1"),
    OBFUSCATE("RichTextView_Watch Video How to Get Key"),
    OBFUSCATE("ButtonLink_Watch Video_https://youtube.com/shorts/n4xezqeWbHA?si=rhIviiK8honshayh"),
    OBFUSCATE("ButtonLink_Report Bug Error_https://virusmodz766.kesug.com/bot.html?i=2"),
    
    
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    //pthread_t ptid;
  //  pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
    
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *loggedIn[] = {
        
        OBFUSCATE("Collapse_Players Mods"),
        OBFUSCATE("1_CollapseAdd_Toggle_Unlimited Boost"), //It will assigned
        OBFUSCATE("2_CollapseAdd_Toggle_High Melee Length_long range punch"), 
        OBFUSCATE("3_CollapseAdd_Toggle_Instead Fly_Instead, 'fly' means to fly without delay."),//9
        OBFUSCATE("4_CollapseAdd_Toggle_Magic Melee Punch"),//9
        OBFUSCATE("5_CollapseAdd_Toggle_Magic Grenade"),
        OBFUSCATE("11_CollapseAdd_Toggle_Seend Punch_Show Fake Punch 👊 to Enemy"),
        OBFUSCATE("24_CollapseAdd_Toggle_Hide Your Weapons"),//9
        OBFUSCATE("27_CollapseAdd_Toggle_Fake Lag_enemy see your player lagging "),//9
        //OBFUSCATE("57_CollapseAdd_Toggle_Tell Kill"), //It will assigned
        OBFUSCATE("CollapseAdd_RichTextView_hold this teleport button to create mini button again hold to remove"),
        OBFUSCATE("57_CollapseAdd_Button_Telepprt/R"),
        OBFUSCATE("58_CollapseAdd_Toggle_Tell Kill 2_automatic teleport to enemy after 3 second"),//9
      //  OBFUSCATE("19_CollapseAdd_SeekBarDecimal_Player Speed_1_2"),//9
        OBFUSCATE("19_CollapseAdd_SeekBar_Player Speed_0_22"), // 9
        OBFUSCATE("55_CollapseAdd_Toggle_Hide Punch_enemy can't see your punch"),//9
        OBFUSCATE("62_CollapseAdd_ButtonOnOff_Invisible Mod"),//9
       // OBFUSCATE("39_CollapseAdd_Button_Disappear/R"),
        OBFUSCATE("30_CollapseAdd_Toggle_True_Remove Ads"),
        
        OBFUSCATE("Collapse_Enemy Manager"),
        OBFUSCATE("31_CollapseAdd_Toggle_Freeze Enemy"),//9
        OBFUSCATE("32_CollapseAdd_Toggle_Enemy Naver dead"),//9
        OBFUSCATE("33_CollapseAdd_Toggle_Kill Team Mate"),//9
        OBFUSCATE("34_CollapseAdd_Toggle_Enemy Lebal Never Hind"),//9
        OBFUSCATE("35_CollapseAdd_Toggle_Enemy Shield Not Working"),//9
        //OBFUSCATE("43_CollapseAdd_Toggle_Magic Bullet_enable in lobby and you cannot disable magic bullet in game you need to exit the game to disable it"),
        OBFUSCATE("37_CollapseAdd_InputText_Enter Name"),
        OBFUSCATE("38_CollapseAdd_Toggle_Set Enemy Name"),
        
        
        
        OBFUSCATE("Collapse_Weapons Mods"),
        OBFUSCATE("6_CollapseAdd_Toggle_BulletTrack"),
        OBFUSCATE("7_CollapseAdd_Toggle_AIMBOT"),
        OBFUSCATE("8_CollapseAdd_RadioButton_Aimbot Mod_Normal Aim,Fire Aim,Crouch Aim"),         
        OBFUSCATE("59_CollapseAdd_Toggle_Auto Fire"),//9
        OBFUSCATE("60_CollapseAdd_Toggle_No Dual Throw"),//9
        OBFUSCATE("20_CollapseAdd_Toggle_All Weapon Laser"),//9
        OBFUSCATE("21_CollapseAdd_Toggle_No Bullet Spread"),//9
        OBFUSCATE("22_CollapseAdd_Toggle_Enable Weapon Drop"),//9
        OBFUSCATE("23_CollapseAdd_Toggle_Magic Zoom"),//9
     //   OBFUSCATE("28_CollapseAdd_SeekBar_Spray Speed_0_26"), // 
        OBFUSCATE("56_CollapseAdd_Toggle_2x Bullet Speed"),
        OBFUSCATE("61_CollapseAdd_Toggle_2x Bullet Renge"),
        OBFUSCATE("36_CollapseAdd_Toggle_All Gun Death Sprayer"),//9
        
        
        OBFUSCATE("Collapse_Map Mods"),
        OBFUSCATE("25_CollapseAdd_Toggle_Fly Through Walls_enable before game start"),//9
        OBFUSCATE("26_CollapseAdd_Toggle_Anti Gravity_enable before the game start"),//9
        
        OBFUSCATE("29_CollapseAdd_Spinner_Radar_default,Radar 1,Radar 2"),
        OBFUSCATE("18_CollapseAdd_Graph_Teleport_3_6_2_6"),
        OBFUSCATE("10_CollapseAdd_Toggle_TELEPORT"),
        
        OBFUSCATE("Collapse_Game Manager"),
       // OBFUSCATE("44_CollapseAdd_Toggle_Freeze Tokens_using this mode you can create unlimited rank match without spending a single token"),
        OBFUSCATE("42_CollapseAdd_SeekBar_Time Scale_0_19"), // 9
        OBFUSCATE("63_CollapseAdd_Toggle_12 Player In Rank"),
        OBFUSCATE("53_CollapseAdd_Toggle_Game Run In Background"),//9
        OBFUSCATE("40_CollapseAdd_InputText_Enter Masage"),
        OBFUSCATE("41_CollapseAdd_Toggle_Show Massage"),
        
        OBFUSCATE("Collapse_Offline"),
        OBFUSCATE("CollapseAdd_RichTextView_remember do not use offline mode in online match"),
        OBFUSCATE("45_CollapseAdd_Toggle_Unlimited Health"),
        OBFUSCATE("46_CollapseAdd_Toggle_Unlimited Ammo"),
        OBFUSCATE("47_CollapseAdd_Toggle_No Reload"),
        OBFUSCATE("48_CollapseAdd_Toggle_Bullet Through Walls"),
        OBFUSCATE("49_CollapseAdd_Toggle_Max Bullet Range"),
        OBFUSCATE("50_CollapseAdd_Toggle_Max Bullet Damage"),
        OBFUSCATE("51_CollapseAdd_Toggle_Max Melee Damage"),
        OBFUSCATE("52_CollapseAdd_Toggle_Any Gun Dual Wield"),
        OBFUSCATE("54_CollapseAdd_SeekBar_Bullet Per Shot_0_25"), // 9
        OBFUSCATE("9_CollapseAdd_Spinner_Add Weapon_OFF,DEAGLE,MAGNUM,TEC9,GDEAGLE,UZI,MP5,TAVOR,AK47,XM8,M16,AA12,SPAS12,M1881,M14,M93BA,FLAMETHROWER,RG6,SMAW,SAW GUN,MINIGUN,MACHETE,FLAG BLUE,FLAG ORANGE,BOMB BLUE,BOMB ORANGE,PHASR"),
        
        
        
    };
    
    const char *notloggedIn[] = {
            OBFUSCATE("-9_Button_Back To Login"),
            OBFUSCATE("RichTextView_An *invalid or *wrong key message means your key has expired or is incorrect. Please follow the original process to get a new one."),
	};
	
	
    
 const char **features =ServerLogin == true? loggedIn :notloggedIn ;

    //Now you dont have to manually update the number everytime;
int Total_Feature = ServerLogin ? (sizeof loggedIn / sizeof loggedIn[0]) : (sizeof notloggedIn / sizeof notloggedIn[0]); // replace 
   
  
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, 
                                        jint value1, jint value2, jint value3, jint value4,
                                        jboolean boolean, jstring str, jlong jng, jshort sht, jdouble dub) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value1,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        case 1:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN22SoldierLocalController8hasPowerEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
        case 2:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon14getMeleeLengthEv", "FF 0F 0F E3 1E FF 2F E1", boolean);
    
    break;
    case 3:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x7a23a8", "00 F0 20 E3", boolean);
    break;
    case 4:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x4f1888", "00 1A B7 EE", boolean);
    break;
    case 5:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x4f199c", "08 1A B7 EE", boolean);
    break;
    case 7:
    isAimbot = boolean;
          break;
          case 8:
            switch (value1) {
                //For noobies
                case 1:
                    switc = 0;
                    break;
                case 2:
                    switc = 1;
                    break;
                case 3:
                    switc = 2;
                    break;
            }
                 break;
                     case 9:
    switch (value1) {
        case 0:
            WeaponID = 0; // OFF or no selection
            break;
        case 1:
            WeaponID = 1; // DEAGLE
            break;
        case 2:
            WeaponID = 2; // MAGNUM
            break;
        case 3:
            WeaponID = 3; // TEC9
            break;
        case 4:
            WeaponID = 4; // GDEAGLE
            break;
        case 5:
            WeaponID = 5; // UZI
            break;
        case 6:
            WeaponID = 6; // MP5
            break;
        case 7:
            WeaponID = 7; // TAVOR
            break;
        case 8:
            WeaponID = 8; // AK47
            break;
        case 9:
            WeaponID = 9; // XM8
            break;
        case 10:
            WeaponID = 10; // M16
            break;
        case 11:
            WeaponID = 11; // AA12
            break;
        case 12:
            WeaponID = 12; // SPAS12
            break;
        case 13:
            WeaponID = 13; // M1881
            break;
        case 14:
            WeaponID = 14; // M14
            break;
        case 15:
            WeaponID = 15; // M93BA
            break;
        case 16:
            WeaponID = 16; // FLAMETHROWER
            break;
        case 17:
            WeaponID = 17; // RG6
            break;
        case 18:
            WeaponID = 18; // SMAW
            break;
        case 19:
            WeaponID = 19; // SAW GUN
            break;
        case 20:
            WeaponID = 20; // MINIGUN
            break;
        case 21:
            WeaponID = 21; // MACHETE
            break;
        case 22:
            WeaponID = 22; // FLAG BLUE
            break;
        case 23:
            WeaponID = 23; // FLAG ORANGE
            break;
        case 24:
            WeaponID = 24; // BOMB BLUE
            break;
        case 25:
            WeaponID = 25; // BOMB ORANGE
            break;
        case 26:
            WeaponID = 26; // PHASR
            break;
    }
    break;
    case 6:
          bullet_trake = boolean;
          dual_fire = boolean;
    break;
     case 10:
    isteleport = boolean;
          break;
            case 11:
    isseendpunc = boolean;
          break;
          case 19:
        
    // For noobies
    switch (value1) {
    case 1:
        isplayerspeed = 1.001f;
        break;
    case 2:
        isplayerspeed = 1.002f;
        break;
    case 3:
        isplayerspeed = 1.003f;
        break;
    case 4:
        isplayerspeed = 1.004f;
        break;
    case 5:
        isplayerspeed = 1.005f;
        break;
    case 6:
        isplayerspeed = 1.006f;
        break;
    case 7:
        isplayerspeed = 1.007f;
        break;
    case 8:
        isplayerspeed = 1.008f;
        break;
    case 9:
        isplayerspeed = 1.009f;
        break;
    case 10:
        isplayerspeed = 1.010f;
        break;
    case 11:
        isplayerspeed = 1.011f;
        break;
    case 12:
        isplayerspeed = 1.012f;
        break;
    case 13:
        isplayerspeed = 1.013f;
        break;
    case 14:
        isplayerspeed = 1.014f;
        break;
    case 15:
        isplayerspeed = 1.015f;
        break;
    case 16:
        isplayerspeed = 1.016f;
        break;
    case 17:
        isplayerspeed = 1.017f;
        break;
    case 18:
        isplayerspeed = 1.018f;
        break;
    case 19:
        isplayerspeed = 1.019f;
        break;
    case 20:
        isplayerspeed = 1.020f;
        break;
     case 21:
        isplayerspeed = 1.1f;
        break;
      case 22:
        isplayerspeed = 1.2f;
        break;

        }
       break;
       case 20:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN13WeaponFactory12isLaserSightE8ItemTypei", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break; 
    case 21:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon20getRandomFiringAngleEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
            case 22:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN3HUD16enableWeaponDropEb", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    case 23:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon11getZoomMaskEv", "00 F0 20 E3", boolean);
    
    break; 
    case 24:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN14NetworkManager16sendWeaponChangeEPN7cocos2d8CCObjectE", "1E FF 2F E1", boolean);
    
    break;
    case 25:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN10MapManager18addStaticBodyShapeEii", "1E FF 2F E1", boolean);
    
    break;
    case 26:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN10MapManager16getGravityFactorEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    case 27:
    Autolag = boolean;

    break;
   
case 29:
            switch (value1) {
        case 0:
            MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x6c2c8c")), OBFUSCATE("05 00 00 DA")).Modify();
            break;
            case 1:
            MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x6c2c8c")), OBFUSCATE("05 00 00 A0")).Modify();
            break;
            case 2:
            MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x6c2c8c")), OBFUSCATE("04 00 00 EA")).Modify();
            break;
            
        }
      break;
      case 30:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN20ApplicationInterface18showInterstitialAdEv", "01 00 A0 E3 1E FF 2F E1", boolean);
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN20ApplicationInterface12showAdBannerEv", "01 00 A0 E3 1E FF 2F E1", boolean);
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN20ApplicationInterface16showInterstitialEv", "01 00 A0 E3 1E FF 2F E1", boolean);
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN20ApplicationInterface14showRewardedAdEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    
    break;
    case 31:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN23SoldierRemoteController34setRemotePositionWithDeadReckoningE6cpVectS0_f", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    case 32:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN23SoldierRemoteController9setIsDeadEb", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    case 33:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN22SoldierLocalController10isSameTeamEi", "1E FF 2F E1", boolean);
    
    break;
    case 34:
      showenemyl = boolean;
    break;
    case 35:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x6baefc", "00 F0 20 E3", boolean);
    break;
    
    case 36:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x812174", "00 F0 20 E3", boolean);
    break;
    case 37:
    names = env->GetStringUTFChars(str, 0);
    break; 
    case 38:
    setnae = boolean;
    break;
   /* case 39:
    isdisappear = true;
    break;*/
    case 40:
    sendmasage = env->GetStringUTFChars(str, 0);
    break; 
    case 41:
    smap_SMS = boolean;
    break;
    case 42:
        if(value1 >= 1 && value1 <= 9){
        istimescal = value1 * 10.0f;
        }else if (value1 >= 10){
        istimescal = value1 - 9;
        }else if(value1 == 0){
        istimescal = value1;
        }
        break;
       /* case 43:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x7b2374", "04 0A B0 EE", boolean);
    break;*/
   /* case 44:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN9NagPrompt21onTokenSpendCompletedEPN7cocos2d8CCObjectE", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;*/
    case 47:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon13getReloadTimeEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    case 52:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon11isDualWieldEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    
    case 49:
    Isbulletrenhe = boolean;
    break;
    case 45:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN22SoldierLocalController9addDamageEfNSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEib", "01 00 A0 E3 1E FF 2F E1", boolean);
    PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN11ClientEntry9addDamageEfii", "01 00 A0 E3 1E FF 2F E1", boolean);
    break;
    case 46:
    isammos = boolean;
    
    break;
    case 48:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Tracer7onSparkE18cpSegmentQueryInfoP7cpShapeb", "1E FF 2F E1", boolean);
    
    break;
    case 50:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon9getDamageEv", "02 01 E0 E3 1E FF 2F E1", boolean);
    
    break;
      case 51:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Weapon14getMeleeDamageEv", "02 01 E0 E3 1E FF 2F E1", boolean);
    
    break;
    case 53:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN11AppDelegate36applicationDidEnterBackgroundAndroidEPN7cocos2d8CCObjectE", "1E FF 2F E1", boolean);
    
    break;
    case 54:
    IsRoundsPerFire = value1;
    break;
    case 55:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN14NetworkManager15sendPlayerPunchEPN7cocos2d8CCObjectE", "01 00 A0 E3 1E FF 2F E1", boolean);
     break;
    case 56:
    // Example: dynamic seekbar value handling
isbulletspeed = boolean;
break;
case 57:
    isteleportenemy = true;
    break;
    case 58:
    isteleportenemy2 = boolean;
    break;
    case 59:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN6Joypad4fireEv", "01 00 A0 E3 1E FF 2F E1", boolean);
    
    break;
    case 60:
    PATCH_LIB_SWITCH("libcocos2dcpp.so", "0x7ac4c0", "00 00 A0 E1", boolean);
    break;
    case 61:
    isbulletrenge = boolean;
    break;
    case 62:
        PATCH_LIB_SYM_SWITCH("libcocos2dcpp.so", "_ZN14NetworkManager16sendPositionDataEfb", "1E FF 2F E1", boolean);
    
    break;
    case 63:
    maxplauers = boolean;
    break;
    
 case 5000:
            const char *value = env->GetStringUTFChars(str, 0);
            std::string log = login(env, obj, value);
            if(*value == NULL){
                      Toast(env,obj,OBFUSCATE("Please Enter The Key"),ToastLength::LENGTH_LONG);
            };
            std::string tru = OBFUSCATE("true");
            ServerLogin = log == tru;
            break;
    
    
    }
}

__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("Info"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Info)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
            {OBFUSCATE("onGraphValueChanged"), OBFUSCATE("(FF)V"), reinterpret_cast<void *>(Java_com_android_support_Menu_onGraphValueChanged)},
                    {OBFUSCATE("Login"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(Login)},
    }; 

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
             {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IIIIZLjava/lang/String;JSD)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <string>
#include <map>
#include <cmath>  
#include <cfloat> 
#include <unordered_set>
#include <cstdlib>
#include <sstream>
#include <vector> 
#include <map>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "Unity/Vector2.h"
#include "Unity/Vector3.h"
#include "Unity/Rect.h"
#include "Unity/Color.h"
#include "Unity/Quaternion.h"
#include "Includes/MonoString.h"
#include "Includes/Strings.h"
#include "Includes/RainbowColor.h"
#include "Includes/Chams.h"
#include "AutoHook/AutoHook.h"
#include "Includes/Utils.h"
#include "Includes/enc.h"
#include "DrawESP/VirusModz.h"
#include <thread>  
#include <chrono>  
#include <atomic> 
#include <cmath>
#include <cfloat>



AadilDrawing aadildrawing;



//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"

const char *inputtxtchat;
const char *mynanes;
bool Isunlimitedcoins, Isunlockall, Isgodmod, Isspamchat, isammo, isgrenadesCounts, ismolotovGrenadesCount, issmokeGrenadesCount, ismedsCount, isteamemy, isgodemodV, isboosthake, IsThrowGrenade, isautojump, Isplaygavti, changec, iskickalls, isRespawn, isLeaveCar, isgodmodall, isBoosting, Isframes, isApplyDamage, isPushBullet, isoFlying, Aimbot, masskill, tellkill;

DWORD grenadesCounts, playerWeaponManager, smokeGrenadesCounts, molotovGrenadesCounts, medsCounts, gravity, currentSpeed, myPlayer, frames, isJetFlying, OurPlayer;

float IsSpeedhake, Ishighdamage;

int weaponid;

void *mycharacter = NULL;
void *enemycharacter = NULL;
void* camara = NULL;
void* nearestEnemy = nullptr;
float nearestDist = FLT_MAX;


Quaternion (*LookRotation)(Vector3 forward);

void (*unlimitedcoins)(int value);
void (*old_BaseScreen)(void *instance);
void BaseScreen(void *instance) {
    if (instance != NULL && Isunlimitedcoins) {
        unlimitedcoins(9999999);
    }
    return old_BaseScreen(instance);
}

void (*old_godmod)(void *instance, int dmd, int d);
void godmod(void *instance, int dmd, int d) {
    if (instance != NULL && Isgodmod) {
            return;
    }
   return old_godmod(instance, dmd, d);
}




bool (*old_unlockall)(void *instance);
bool unlockall(void *instance) {
    if (instance != NULL && Isunlockall) {
          return true;
    }
    return old_unlockall(instance);
}

void *(*get_transforms)(void* instance);

Vector3 (*get_position)(void *instance);

void (*set_position)(void *instance, Vector3 Pos);

void *(*get_camera)();

void (*set_rotation)(void *instance, Quaternion value);


void (*kickalls)();

void (*set_NickName)(monoString* value);
void (*Autojumps)(void *instance);
void (*SelectWeapons)(void *instance, int weaponID);
void (*Respawns)(void *instance);
void (*LeaveCars)(void *instance);
void (*godmodall)(void *instance, short dmg, int from);
void (*ApplyDamages)(void *instance, float dmg, int from);
void (*PushBullets)(void* instance);

void (*old_playerU)(void* instance);
void playerU(void* instance){
if (instance != NULL){
void *PlayerWeaponManager = *(void **)((uintptr_t)instance + playerWeaponManager);
  
     if (tellkill && mycharacter && enemycharacter) {
     Vector3 enemypos = get_position(get_transforms(enemycharacter));
    set_position(get_transforms(mycharacter), Vector3(enemypos.x + 3, enemypos.y + 2, enemypos.z + 3));
    }
    
    


if (Aimbot && camara != NULL && enemycharacter != NULL){
    Vector3 mypos = get_position(get_transforms(enemycharacter));
 

Vector3 iscamarapos = get_position(get_transforms(camara));

Vector3 direction = mypos - iscamarapos;


Quaternion look = LookRotation(direction);

Quaternion q;
    q.x = 0;
    q.y = 0;
    q.z = 0;
    q.w = 1; // identity

set_rotation(get_transforms(camara), q);

}

  

  
   if (mynanes) {
    set_NickName(CreateIl2cppString(mynanes));
    
	 }     
	 
        if (isgrenadesCounts && PlayerWeaponManager != NULL) { 
            *(int *)((uintptr_t)PlayerWeaponManager + grenadesCounts) = 99999; 
     }
        if (issmokeGrenadesCount && PlayerWeaponManager != NULL) { 
            *(int *)((uintptr_t)PlayerWeaponManager + smokeGrenadesCounts) = 99999; 
        }

        if (ismolotovGrenadesCount && PlayerWeaponManager!= NULL) { 
            *(int *)((uintptr_t)PlayerWeaponManager + molotovGrenadesCounts) = 99999; 
        }
          if (ismedsCount && PlayerWeaponManager != NULL) { 
            *(int *)((uintptr_t)PlayerWeaponManager + medsCounts) = 99999; 
        }
        if (isautojump) {
            Autojumps(instance);
        }
        if (Isplaygavti) {
            *(float *)((uintptr_t)instance + gravity) = 1.0f;
        }  else {
             *(float *)((uintptr_t)instance + gravity) = 20.0f;
        }
          if (IsSpeedhake > 0) {
            *(float *)((uintptr_t)instance + currentSpeed) = IsSpeedhake;
        } else {
              *(float *)((uintptr_t)instance + currentSpeed) = 6.0f;;
        }
         if (weaponid > 0 && changec && PlayerWeaponManager != NULL) {
            changec = false;
            SelectWeapons(PlayerWeaponManager, weaponid);
        }
        if (iskickalls){
        kickalls();
        }
        if (isRespawn){
        Respawns(instance);
        }
        if (isLeaveCar){
        LeaveCars(instance);
        }
           
    if (isApplyDamage){
        godmodall(instance, 999999, NULL);
        
        }
    
        if (isgodmodall){
        ApplyDamages(instance, 99999, NULL);
        }
        if (isPushBullet && mycharacter){
        PushBullets(mycharacter);
        }
            if (isoFlying) {
            *(bool *)((uintptr_t)instance + isJetFlying) = true;
        } else {
            *(bool *)((uintptr_t)instance + isJetFlying) = false;
        }





}
return old_playerU(instance);

}



void (*old_enemyU)(void* instance);
void enemyU(void* instance){
if (instance != NULL) return old_enemyU(instance);
 
    
    if (mycharacter){
    Vector3 enemypos = get_position(get_transforms(instance));
    Vector3 mypos = get_position(get_transforms(mycharacter));
    
    float dx = enemypos.x - mypos.x;
float dy = enemypos.y - mypos.y;
float dz = enemypos.z - mypos.z;

float dist = sqrtf(dx*dx + dy*dy + dz*dz);
  
  
  if (dist < nearestDist) {
        nearestDist = dist;
        enemycharacter = instance;
    }
    }


return old_enemyU(instance);

}




      
void (*spamchat)(void *instance, monoString* value);
void (*old_updatety)(void *instance);
void updatety(void *instance) {
    if (instance != NULL) {
        if (Isspamchat) {
            spamchat(instance, CreateIl2cppString(inputtxtchat));
        }
    }
    return old_updatety(instance);
}

 
 




 void (*set_ammo)(void *instance, int value);
 
 
 void (*old_amupdate)(void *instance);
 void amupdate(void *instance) {
    if (instance != NULL) {
    
        if (isammo) {
            set_ammo(instance, 99999999);
        }
         
    }
    return old_amupdate(instance);
}

bool (*old_TeamMate)(void *instance, int teame);
bool TeamMate(void *instance, int teame) {

if (instance != NULL) {

if (isteamemy){
     return true;
      }
    }
return old_TeamMate(instance, teame);

}




void (*old_ApplyDamageRPCs)(void *instance, int demage);
void ApplyDamageRPCs(void *instance, int demage) {
if (instance != NULL){
if (isgodemodV){

return;

}

}
return old_ApplyDamageRPCs(instance, demage);
}


void (*old_StopBoostRs)(void *instance);
void StopBoostRs(void *instance){
if (instance != NULL){
if (isboosthake){
return;

}

}
return old_StopBoostRs(instance);

}

void (*ThrowGrenades)(void *instanceint);

void(*old_garanad)(void *instance);
void garanad(void *instance){
    if(instance != NULL){
    
    camara = get_camera();
    
        if (IsThrowGrenade) {
            ThrowGrenades(instance);
        }     
  
	  
    }
    return old_garanad(instance);
}

void (*old_highdamage)(void *instance, float value);
void highdamage(void *instance, float value) {
    if (instance != NULL) {
        if (Ishighdamage > 0) {
            old_highdamage(instance, Ishighdamage);
            
        }
    }
    return old_highdamage(instance, value);
}



void (*StartBoostings)(void *instanceint);
void(*old_updatecar)(void *instance);
void updatecar(void *instance){
    if(instance != NULL){
        if (isBoosting) {
            StartBoostings(instance);
         
        }     
        
       
    }
     old_updatecar(instance);
}





void (*old_framess)(void *instance);
void framess(void *instance) {
    if (instance != NULL) {
        if (Isframes) {
            *(int *)((uint64_t)instance + frames) = 0;
  }
    }
    return old_framess(instance);
}
 


void (*old_gameUP)(void *instance);
void gameUP(void *instance) {
    if (instance != NULL) {
    mycharacter = *(void **)((uintptr_t)instance + OurPlayer);
    
    nearestDist = FLT_MAX;      // ✅ reset ONCE per frame
        enemycharacter = NULL;      // ✅ clear old target
   
  
       
    }
    return old_gameUP(instance);
}
 






























void DrawESP(AadilDrawing esp, int width, int height) {

//std::string any = std::to_string(git);

//esp.DrawText(Color(0, 100, 255, 255), "virusmodz", Vector2(width / 2, height / 3.7), 20);
   
}


/*
extern "C"
JNIEXPORT void JNICALL
Java_com_android_support_Menu_onGraphValueChanged(JNIEnv *env, jobject thiz, jfloat x, jfloat y) {
  teleportX = x;
   teleportY = y;
}
*/


 
 void Draw(JNIEnv *env, jobject cls, jobject espview, jobject cvs) {
    aadildrawing = AadilDrawing(env, espview, cvs);
    if (aadildrawing.isValid()) DrawESP(aadildrawing, aadildrawing.getWidth(), aadildrawing.getHeight());
}
// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    
    ProcMap il2cppMap;
 
    //Check if target lib is loaded
    do {
        sleep(10);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/
    
    // class BaseScreen
auto Playerunlimitedcoins = new LoadClass("", OBFUSCATE("BaseScreen"));

DWORD Getunlimitedcoins = Playerunlimitedcoins->GetMethodOffsetByName(OBFUSCATE("Update"), 0);
//---

// Initialize the class


// class LocalStore
auto Upunlimitedcoins = new LoadClass("", OBFUSCATE("LocalStore"));

DWORD GetUpunlimitedcoins = Upunlimitedcoins->GetMethodOffsetByName(OBFUSCATE("set_currencyBalance"), 1);

//==

// class PhotonNetwork
auto PhotonNetwork = new LoadClass(OBFUSCATE("Photon.Pun"), OBFUSCATE("PhotonNetwork"));


DWORD setplayername = PhotonNetwork->GetMethodOffsetByName(OBFUSCATE("set_NickName"), 1);
set_NickName = (void (*) (monoString*))(setplayername);

DWORD SendDestroyOfAll = PhotonNetwork->GetMethodOffsetByName(OBFUSCATE("SendDestroyOfAll"), 0);
kickalls = (void (*) ())(SendDestroyOfAll);

//====

//class CharacterMotor
auto CharacterMotor = new LoadClass("", OBFUSCATE("CharacterMotor"));

DWORD GetCharacterMotor = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("Update"), 0);
HOOK_AU(GetCharacterMotor, playerU, old_playerU);

DWORD GetenemyU = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("UpdateClonePosition"), 0);
HOOK_AU(GetenemyU, enemyU, old_enemyU);


DWORD Getgodmod = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("DamageRPC"), 2);
HOOK_AU(Getgodmod, godmod, old_godmod);

playerWeaponManager = CharacterMotor->GetFieldOffset(OBFUSCATE("playerWeaponManager"));

DWORD Jump = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("Jump"), 0);
Autojumps = (void (*) (void *))(Jump);

gravity = CharacterMotor->GetFieldOffset(OBFUSCATE("gravity"));
currentSpeed = CharacterMotor->GetFieldOffset(OBFUSCATE("currentSpeed"));
isJetFlying = CharacterMotor->GetFieldOffset(OBFUSCATE("isJetFlying"));

DWORD Respawn = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("Respawn"), 0);
Respawns = (void (*) (void *))(Respawn);

DWORD LeaveCar = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("LeaveCar"), 0);
LeaveCars = (void (*) (void *))(LeaveCar);

DWORD DamageRPC = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("DamageRPC"), 2);
godmodall = (void (*) (void *, short, int))(DamageRPC);

DWORD ApplyDamage = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("ApplyDamage"), 2);
ApplyDamages = (void (*) (void *, float, int))(ApplyDamage);

DWORD PushBullet = CharacterMotor->GetMethodOffsetByName(OBFUSCATE("PushBullet"), 0);
PushBullets = (void (*) (void *))(PushBullet);
//-------

// class BasePreviewPrefabItem
auto Playerunlockall = new LoadClass("", OBFUSCATE("BasePreviewPrefabItem"));

DWORD Getunlockall = Playerunlockall->GetMethodOffsetByName(OBFUSCATE("get_IsBought"), 0);
MSHookFunction((void *)Getunlockall, (void *)unlockall, (void **) &old_unlockall);


//=====

// class ChatController
auto ChatController = new LoadClass("", OBFUSCATE("ChatController"));

DWORD ChatControllerup = ChatController->GetMethodOffsetByName(OBFUSCATE("Update"), 0);
HOOK_AU(ChatControllerup, updatety, old_updatety);

DWORD seendmadage = ChatController->GetMethodOffsetByName(OBFUSCATE("AddMessageR"), 1);
spamchat = (void (*) (void*, monoString*))(seendmadage);




//=====

// class BaseWeaponScript
auto BaseWeaponScript = new LoadClass("", OBFUSCATE("BaseWeaponScript"));

DWORD BaseWeaponScriptUP = BaseWeaponScript->GetMethodOffsetByName(OBFUSCATE("UpdateAmmoUI"), 0);
HOOK_AU(BaseWeaponScriptUP, amupdate, old_amupdate);

DWORD set_ammos = BaseWeaponScript->GetMethodOffsetByName(OBFUSCATE("set_ammo"), 1);
set_ammo = (void (*) (void*, int))(set_ammos);
//=====

// class PlayerWeaponManager
auto PlayerWeaponManager = new LoadClass("", OBFUSCATE("PlayerWeaponManager"));

grenadesCounts = PlayerWeaponManager->GetFieldOffset(OBFUSCATE("grenadesCount"));
smokeGrenadesCounts = PlayerWeaponManager->GetFieldOffset(OBFUSCATE("smokeGrenadesCount"));
molotovGrenadesCounts = PlayerWeaponManager->GetFieldOffset(OBFUSCATE("molotovGrenadesCount"));
medsCounts = PlayerWeaponManager->GetFieldOffset(OBFUSCATE("medsCount"));
myPlayer = PlayerWeaponManager->GetFieldOffset(OBFUSCATE("myPlayer"));

std::vector<std::string> params;
params.push_back("System.Int32");  // 1st arg is int
DWORD SelectWeapon = PlayerWeaponManager->GetMethodOffset(OBFUSCATE("SelectWeapon"), params);
SelectWeapons = (void (*) (void *, int))(SelectWeapon);

/*
LoadClass *player = new LoadClass("Namespace", "PlayerClass");

// Define your parameter types in a list

std::vector<std::string> params;
params.push_back("System.Int32");  // 1st arg is int
params.push_back("System.Single"); // 2nd arg is float

// Get the offset
DWORD attackOffset = player->GetMethodOffsetWithType("Attack", 2, params);
*/
//=====

// class GameController
auto GameController = new LoadClass("", OBFUSCATE("GameController"));

DWORD IsTeamMate = GameController->GetMethodOffsetByName(OBFUSCATE("IsTeamMate"), 1);
HOOK_AU(IsTeamMate, TeamMate, old_TeamMate);

DWORD UpdateFPS = GameController->GetMethodOffsetByName(OBFUSCATE("UpdateFPS"), 0);
HOOK_AU(UpdateFPS, framess, old_framess);

DWORD gameUpdate = GameController->GetMethodOffsetByName(OBFUSCATE("Update"), 0);
HOOK_AU(gameUpdate, gameUP, old_gameUP);

frames = GameController->GetFieldOffset(OBFUSCATE("frames"));
OurPlayer = GameController->GetFieldOffset(OBFUSCATE("OurPlayer"));


//=====

// class Vehicle
auto Vehicle = new LoadClass("", OBFUSCATE("Vehicle"));

DWORD ApplyDamageRPC = Vehicle->GetMethodOffsetByName(OBFUSCATE("ApplyDamageRPC"), 1);
HOOK_AU(ApplyDamageRPC, ApplyDamageRPCs, old_ApplyDamageRPCs);



// ====

// class CharacterAnimation
auto CharacterAnimation = new LoadClass("", OBFUSCATE("CharacterAnimation"));

DWORD ThrowGrenade = CharacterAnimation->GetMethodOffsetByName(OBFUSCATE("ThrowGrenade"), 0);
ThrowGrenades = (void (*) (void *))(ThrowGrenade);

DWORD Update = CharacterAnimation->GetMethodOffsetByName(OBFUSCATE("Update"), 0);
HOOK_AU(Update, garanad, old_garanad);


//=====

// class CarController

auto CarController = new LoadClass("", OBFUSCATE("CarController"));

DWORD StopBoostR = CarController->GetMethodOffsetByName(OBFUSCATE("StopBoostR"), 0);
HOOK_AU(StopBoostR, StopBoostRs, old_StopBoostRs);

DWORD FixedUpdate = CarController->GetMethodOffsetByName(OBFUSCATE("FixedUpdate"), 0);
HOOK_AU(FixedUpdate, updatecar, old_updatecar);

DWORD StartBoosting = CarController->GetMethodOffsetByName(OBFUSCATE("StartBoosting"), 0);
StartBoostings = (void (*) (void *))(StartBoosting);

// ====

// class GunBullet
auto GunBullet = new LoadClass("", OBFUSCATE("GunBullet"));

DWORD SetDamage = GunBullet->GetMethodOffsetByName(OBFUSCATE("SetDamage"), 1);
HOOK_AU(SetDamage, highdamage, old_highdamage);



///*======

// class Component
auto Component = new LoadClass("UnityEngine", OBFUSCATE("Component"));

DWORD get_transform = Component->GetMethodOffsetByName(OBFUSCATE("get_transform"), 0);
get_transforms = (void* (*) (void *))(get_transform);


//======

//class Transform
auto Transform = new LoadClass("UnityEngine", OBFUSCATE("Transform"));

DWORD get_position_Injected = Transform->GetMethodOffsetByName(OBFUSCATE("get_position"), 0);
get_position = (Vector3 (*) (void *))(get_position_Injected);


DWORD set_position_Injected = Transform->GetMethodOffsetByName(OBFUSCATE("set_position"), 1);
set_position = (void (*) (void *, Vector3))(set_position_Injected);

DWORD isset_rotation = Transform->GetMethodOffsetByName(OBFUSCATE("set_rotation"), 1);
set_rotation = (void (*) (void *, Quaternion))(isset_rotation);

//====

// class Camera
auto Camera = new LoadClass("UnityEngine", OBFUSCATE("Camera"));

DWORD get_main = Camera->GetMethodOffsetByName(OBFUSCATE("get_main"), 0);

get_camera = (void* (*) ())(get_main);

//=======


auto getQuaternion = new LoadClass("UnityEngine", OBFUSCATE("Quaternion"));
DWORD getLookRotation = getQuaternion->GetMethodOffsetByName(OBFUSCATE("LookRotation"), 1);
LookRotation = (Quaternion (*) (Vector3))(getLookRotation);


//MSHookFunction((void *) Getunlimitedcoins, (void *) BaseScreen, (void **) &old_BaseScreen);

// hooks
HOOK_AU(Getunlimitedcoins, BaseScreen, old_BaseScreen);

// calls

unlimitedcoins = (void (*) (int))(GetUpunlimitedcoins);

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    


#else //To compile this code for armv7 lib only.




    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
  /*  if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;
        *p = 0;
    }*/
    
    

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
       OBFUSCATE("Collapse_Mods"),
		OBFUSCATE("1_CollapseAdd_Toggle_Unlimited Coins"),
		OBFUSCATE("2_CollapseAdd_Toggle_Unlock Everything"),
		OBFUSCATE("3_CollapseAdd_Toggle_God Mod"),
		OBFUSCATE("4_CollapseAdd_InputText_Change Name"),
		OBFUSCATE("5_CollapseAdd_InputText_Spam TXT"),
		OBFUSCATE("6_CollapseAdd_Toggle_Spam Chat"),
        OBFUSCATE("29_CollapseAdd_Toggle_Aimbot"),
		
		OBFUSCATE("Collapse_Advance mods"),
		OBFUSCATE("7_CollapseAdd_Toggle_Unlimited Ammo"),//9
		OBFUSCATE("8_CollapseAdd_Toggle_Unlimited Grenades"),//9
		OBFUSCATE("9_CollapseAdd_Toggle_Unlimited Meds"),//9
		OBFUSCATE("10_CollapseAdd_Toggle_Show Enemy name"),//9
		OBFUSCATE("11_CollapseAdd_Toggle_Good Mod Vehicle"),//9
		OBFUSCATE("12_CollapseAdd_Toggle_Boost Hake"),//9
		OBFUSCATE("13_CollapseAdd_Toggle_Throw Grenade"),//9
		OBFUSCATE("14_CollapseAdd_Toggle_Auto Jump"),//9
     
        OBFUSCATE("Collapse_VIP Mods"),
        OBFUSCATE("15_CollapseAdd_Toggle_No Gravity"),//9
        OBFUSCATE("16_CollapseAdd_SeekBar_Player Speed_0_100"),//9
        OBFUSCATE("17_CollapseAdd_SeekBar_high damage_0_9999"),//9
        OBFUSCATE("18_CollapseAdd_SeekBar_Gun Change_0_31"),//9
        OBFUSCATE("20_CollapseAdd_Toggle_Kick All"),//9
        OBFUSCATE("21_CollapseAdd_Toggle_Respawn"),//9 
        OBFUSCATE("22_CollapseAdd_Toggle_Leave Vehicle All Players"),//9
        OBFUSCATE("23_CollapseAdd_Toggle_GoodMod All Players"),//9
        OBFUSCATE("24_CollapseAdd_Toggle_Boosting All Cars"),//9
        OBFUSCATE("25_CollapseAdd_Toggle_High FPS"),//9
        OBFUSCATE("26_CollapseAdd_Toggle_Kill All Enemys"),
        OBFUSCATE("27_CollapseAdd_Toggle_Auto Fire"),//9
        OBFUSCATE("28_CollapseAdd_Toggle_Flying"),//9
        
        OBFUSCATE("Collapse_Teleport"),
        OBFUSCATE("30_CollapseAdd_Toggle_TellKill"),
        
        
        
        
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, 
                                        jint value1, jint value2, jint value3, jint value4,
                                        jboolean boolean, jstring str, jlong jng, jshort sht, jdouble dub) {
                                        
 /*void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) { */

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value1,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
          case 1:
            Isunlimitedcoins = boolean;
            break;
          case 2:
           Isunlockall = boolean;
           break;
          case 3:
           Isgodmod = boolean;
           break;
         case 4:
    mynanes = env->GetStringUTFChars(str, 0);
         break; 
         break;
    case 5:
    inputtxtchat = env->GetStringUTFChars(str, 0);
    break; 
    case 6:
    Isspamchat = boolean;
    break;
            case 7:
    isammo = boolean;
        break;
    case 8:
    isgrenadesCounts = boolean;
    ismolotovGrenadesCount = boolean;
    issmokeGrenadesCount = boolean;
    break;
    case 9:
    ismedsCount = boolean;
    break;
    case 10:
    isteamemy = boolean;
    break;
    case 11:
    isgodemodV = boolean;
    break;
    case 12:
    isboosthake = boolean;
    break;
    case 13:
    IsThrowGrenade = boolean;
    break;
     case 14:
    isautojump = boolean;
    break;
    case 15:
    Isplaygavti = boolean;
    break;
    case 16:
    IsSpeedhake = (float) value1;    
    break;
    case 17:
    Ishighdamage = value1;
    break;
    case 18:
    changec =value1>0;
    weaponid = value1;
    break;
    case 20:
    iskickalls = boolean;
    break;
    case 21:
    isRespawn = boolean;
    break;
    case 22:
    isLeaveCar = boolean;
    break;
    case 23:
    isgodmodall = boolean;
    break;
    case 24:
    isBoosting = boolean;
    break;
    case 25:
    Isframes = boolean;
    break;
    case 26:
    isApplyDamage = boolean;
    break;
    case 27:
    isPushBullet = boolean;
    break;
    case 28:
    isoFlying = boolean;
    break;
    case 29:
    Aimbot = boolean;
    break;
    case 30:
    tellkill = boolean;
    break;
       
    
          
            
         
    }
}

__attribute__((constructor))
void lib_main() {
    
    InitializeLogger();
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("Info"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Info)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
            {OBFUSCATE("Draw"),  OBFUSCATE("(Lcom/android/support/ESPView;Landroid/graphics/Canvas;)V"), reinterpret_cast<void *>(Draw)},
 
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
             {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IIIIZLjava/lang/String;JSD)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

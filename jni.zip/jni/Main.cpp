#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"

// --- Dependencies ---
#include "loginUtils/json.hpp"
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <sstream>
#include <iomanip>
#include <cctype>

using json = nlohmann::json;

// --- Constants & Config ---
// TODO: Replace with your actual Firebase Project URL
// IMPORTANT: Must end with a slash '/'
#define FIREBASE_DB_URL OBFUSCATE("https://key-system-4a6f9-default-rtdb.firebaseio.com/")

// Target lib
#define targetLibName OBFUSCATE("libil2cpp.so")

// Global State
bool ServerLogin = false;

/*--------- Utility: URL Encoding (Optimized) ---------------*/
std::string urlEncode(const std::string& value) {
    std::ostringstream encoded;
    encoded << std::hex << std::uppercase;
    for (char c : value) {
        if (std::isalnum(static_cast<unsigned char>(c)) ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            encoded << c;
        } else {
            encoded << '%' << std::setw(2) << std::setfill('0')
                    << static_cast<int>(static_cast<unsigned char>(c));
        }
    }
    return encoded.str();
}

/*--------- Network: Curl Callback ---------------*/
size_t writeCallback(char *contents, size_t size, size_t nmemb, std::string *userp) {
    size_t totalSize = size * nmemb;
    userp->append(contents, totalSize);
    return totalSize;
}

/*--------- Network: Perform GET Request ---------------*/
std::string performRequest(const std::string& url) {
    CURL *curl;
    CURLcode res;
    std::string responseBuffer;

    curl = curl_easy_init();
    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        
        // Optimizations for speed and reliability
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L); // 10 seconds timeout
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L); // Note: Set to 1L for production security
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBuffer);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "FirebaseMod/1.0");

        res = curl_easy_perform(curl);
        
        if (res != CURLE_OK) {
            LOGE("Curl Request Failed: %s", curl_easy_strerror(res));
            curl_easy_cleanup(curl);
            return ""; // Return empty on failure
        }
        curl_easy_cleanup(curl);
    }
    return responseBuffer;
}

/*--------- Logic: Firebase Login ---------------*/
// --- Configuration ---
// Define the name of the game this specific Mod Menu is built for
#define CURRENT_GAME_NAME OBFUSCATE("MinimilitiaClassic32bit") 

std::string login(JNIEnv *env, jobject obj, const char *inputKey) {
    std::string keyString(inputKey);
    
    if (keyString.empty()) {
        Toast(env, obj, OBFUSCATE("Key cannot be empty"), ToastLength::LENGTH_SHORT);
        return OBFUSCATE("false");
    }

    // Construct URL: https://PROJECT.firebaseio.com/Users/KEY.json
    std::string requestUrl = std::string(FIREBASE_DB_URL);
    requestUrl += "Users/"; 
    requestUrl += urlEncode(keyString);
    requestUrl += ".json";

    std::string response = performRequest(requestUrl);

    try {
        // 1. Check if key exists
        if (response.empty() || response == "null") {
            Toast(env, obj, OBFUSCATE("Key does not exist"), ToastLength::LENGTH_LONG);
            return OBFUSCATE("false");
        }

        json data = json::parse(response);

        if (!data.is_null()) {
            
            // 2. CHECK STATUS (Must be active)
            if (data.contains("status")) {
                std::string status = data["status"].get<std::string>();
                if (status != "active") {
                     Toast(env, obj, OBFUSCATE("Key is expired"), ToastLength::LENGTH_LONG);
                     return OBFUSCATE("false");
                }
            }

            // 3. CHECK GAME NAME (New Feature)
            // This prevents keys from other games being used here
            if (data.contains("game")) {
                std::string serverGameName = data["game"].get<std::string>();
                std::string localGameName = std::string(CURRENT_GAME_NAME);

                if (serverGameName != localGameName) {
                    Toast(env, obj, OBFUSCATE("Invalid Game: This key is for a different game"), ToastLength::LENGTH_LONG);
                    return OBFUSCATE("false");
                }
            } else {
                // Optional: Fail if the key has no game name attached
                // Toast(env, obj, OBFUSCATE("Security Error: Key has no game assigned"), ToastLength::LENGTH_LONG);
                // return OBFUSCATE("false");
            }

            // If we passed all checks:
            Toast(env, obj, OBFUSCATE("Login Successful!"), ToastLength::LENGTH_LONG);
            return OBFUSCATE("true");
        } 
        
    } catch (const std::exception &e) {
        LOGE("Error: %s", e.what());
        Toast(env, obj, OBFUSCATE("Connection Error"), ToastLength::LENGTH_LONG);
    }

    return OBFUSCATE("false");
}


// --- Threading ---
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    // Wait for target lib
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

    // Note: Add your hooks here
    
    return NULL;
}

// --- JNI Menu Implementation ---

jobjectArray Login(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
        OBFUSCATE("Category_Authentication"),
        OBFUSCATE("5000_InputText_Enter License Key"),
        OBFUSCATE("-999_Button_Login"),
        OBFUSCATE("RichTextView_Contact support if you lost your key."),
        OBFUSCATE("ButtonLink_Get Key_https://your-website.com/getkey"), 
    };

    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")), env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    // Menu shown AFTER login
    const char *loggedIn[] = {
            OBFUSCATE("Category_Main Menu"), 
            OBFUSCATE("Toggle_Wallhack"),
            OBFUSCATE("100_Toggle_True_Aimbot"), 
            OBFUSCATE("SeekBar_Speed_0_100"),
    };
    
    // Menu shown BEFORE login
    const char *notloggedIn[] = {
            OBFUSCATE("-9_Button_Back To Login"),
            OBFUSCATE("RichTextView_Authentication Failed. Please try again."),
	};

    const char **features = ServerLogin ? loggedIn : notloggedIn;
    int Total_Feature = ServerLogin ? (sizeof loggedIn / sizeof loggedIn[0]) : (sizeof notloggedIn / sizeof notloggedIn[0]);
   
    ret = (jobjectArray) env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")), env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    // Logging for debugging (Remove in production for security)
    // LOGD(OBFUSCATE("Feature: %d"), featNum);

    switch (featNum) {
        case 5000: { // Login Button Logic
            const char *inputChars = env->GetStringUTFChars(str, 0);
            
            // Perform Login
            std::string result = login(env, obj, inputChars);
            
            // Check result
            std::string successMarker = OBFUSCATE("true");
            ServerLogin = (result == successMarker);
            
            env->ReleaseStringUTFChars(str, inputChars);
            break;
        }
        case 100:
             // Example Feature Implementation
             break;
    }
}

// --- Standard JNI Registration (Unchanged) ---
__attribute__((constructor))
void lib_main() {
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
            {OBFUSCATE("Login"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(Login)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz) return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0) return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz) return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0) return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz) return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0) return JNI_ERR;
    return JNI_OK;
}

extern "C" JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0) return JNI_ERR;
    if (RegisterPreferences(env) != 0) return JNI_ERR;
    if (RegisterMain(env) != 0) return JNI_ERR;
    return JNI_VERSION_1_6;
}

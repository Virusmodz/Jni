#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "DrawESP/DrawingManager.h"

AadilDrawing aadildrawing;


void Draw(JNIEnv *env, jobject cls, jobject espview, jobject cvs) {
	aadildrawing = AadilDrawing(env, espview, cvs);
	if (aadildrawing.isValid()) DrawESP(aadildrawing, aadildrawing.getWidth(), aadildrawing.getHeight());
}

//Target lib here
#define targetLibName OBFUSCATE("libcocos2dcpp.so")

#include "Includes/Macros.h"

/*
void (*old_FunctionExample)(void *instance);
void FunctionExample(void *instance) {
    instanceBtn = instance;
    if (instance != NULL) {
        if (Health) {
            *(int *) ((uint64_t) instance + 0x48) = 999;
        }
    }
    return old_FunctionExample(instance);
}*/


























// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);
    LOGI("PTM approx = %f", git);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    
#else //To compile this code for armv7 lib only.

    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
 //   HOOK("str", FunctionExample, old_FunctionExample);
 //   HOOK_LIB("libFileB.so", "0x123456", FunctionExample, old_FunctionExample);
    
 //   AddMoneyExample = (void (*)(void *, int)) getAbsoluteAddress(targetLibName, 0x123456);
 
 HOOK_LIB("libcocos2dcpp.so", "0x7b2d48", EnemyU, old_EnemyU);
 GetPositionX = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c791); 
GetPositionY = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c79f); 
HOOK_LIB("libcocos2dcpp.so", "0x7bc15c", setPlayerName_hook, old_setPlayerName_hook);
getTeamId = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x4361e0); 
gethp = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1b8); 
isdead = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1f8);
getFireAngle = (float (*)(void *))getAbsoluteAddress(targetLibName, 0x79e390);  
getRotation = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c543);  
isDucked = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c543);  
sharedDirector_t = (void* (*)())getAbsoluteAddress(targetLibName, 0xaaa9c5); 
getThrustFactor = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79e408);  

getPeerID = (std::string (*)(void *))getAbsoluteAddress(targetLibName, 0x79ee24);  
// Inside hack_thread or lib_main
// Replace 0xXXXXXX with the real address from your dump file
convertToWorldSpace = (Vector2 (*)(void *, const Vector2&))getAbsoluteAddress(targetLibName, 0xa9e7a9);

getPlayerName = (std::string (*)(void *))getAbsoluteAddress(targetLibName, 0x7bc2ec);  

convertToUI_t = (Vector2 (*)(void *, const Vector2&))getAbsoluteAddress(targetLibName, 0xaabfb1); 

HOOK_LIB("libcocos2dcpp.so", "0x79e224", removebody, old_removebody);
HOOK_LIB("libcocos2dcpp.so", "0x4b4e2c", FRAGNADE, old_FRAGNADE);

//HOOK_LIB("libcocos2dcpp.so", "0x79ee74", addDamage, orig_addDamage);
addDamage = (void (*)(void *, float, std::string*, int, bool))getAbsoluteAddress(targetLibName, 0x79ee74);  


HOOK_LIB("libcocos2dcpp.so", "0x7a5170", SoldierLocalController, old_SoldierLocalController);


// Existing hooks...

// ADD THIS LINE:
g_pWorldLayer = (void**)getAbsoluteAddress(targetLibName, 0xfc4a8c);


//getBytesFunc = (unsigned char* (*)(void*))getAbsoluteAddress(targetLibName, 0x334668);

    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
    /*if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;
        *p = 0;
    }*/

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_The Category"), //Not counted
            OBFUSCATE("10_Toggle_Enable ESP"),
			OBFUSCATE("20_Toggle_Enable Line"),
			
			OBFUSCATE("30_Toggle_Enable Radar"),
			OBFUSCATE("40_Toggle_Players ID"),
			OBFUSCATE("50_Toggle_Players Aimsight"),
			OBFUSCATE("60_Toggle_Players Names"),
            
            
			
			
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        case 10:
		EnableESP = boolean;
          
        break;
		case 20:
		ESPLine = boolean;
          
        break;
        case 30:
    ESPRadar = boolean;
    break;
    case 40:
    plIDS = boolean;
     break;
     case 50:
     ESPLine = boolean;
     break;
    case 60:
     espname = boolean;
     break;
    
    }
}

__attribute__((constructor))
void lib_main() {
	InitializeLogger();
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
		    {OBFUSCATE("Draw"),  OBFUSCATE("(Lcom/android/support/ESPView;Landroid/graphics/Canvas;)V"), reinterpret_cast<void *>(Draw)},
 
		   };
    

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <string>
#include <map>
#include <cmath>  
#include <cfloat> 
#include <unordered_set>
#include <cstdlib>
#include <sstream>
#include <vector> 
#include <map>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include "Includes/enc.h"
#include "DrawESP/VirusModz.h"




AadilDrawing aadildrawing;



//Target lib here
#define targetLibName OBFUSCATE("libcocos2dcpp.so")

#include "Includes/Macros.h"

float destincence;
float isboost = 0;
float distence;
bool isteleport, autothrowg, tpnadeto, isfring, isteleport2;
double isFps;
int Esize, switc;

float positionsX, positionsY, getfirdsingde, issetAccuracyMod, issetRate;

bool isAimbot, automille, isadrasss, isadrasssEP, copyid, bullet_trake;

constexpr float PI_F = 3.14159265358979323846f;
constexpr float RAD2DEG = 180.0f / PI_F;

int (*getTeamId)(void* instance); // get players team id like 1 to 7, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead

bool (*iscrousg)(void* instance);


using namespace std;

unordered_set<void *> playerslist;


void* enemyPlayers = NULL;
void* localPlayer = NULL;
void* currentTarget = NULL;   
void* bestCandidate = NULL;    
float closestDistSq = FLT_MAX; 


int cachedLocalTeam = -1;
float cachedLocalX = 0.0f;
float cachedLocalY = 0.0f;
float isplayerspeed, istimescal, issetSpeedMod, teleportX, teleportY;

void* (*sharedDirector)();

void (*setAnimationInterval)(void* instance, double fps);

float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);

void (*SetPosition)(void* instance, float x, float y);

void (*SettPositionX)(void* instance, float X);
void (*SettPositionY)(void* instance, float Y);




//#include <string>
void (*old_CCScheduler)(void *instance, float timespeed);
void CCScheduler(void *instance, float timespeed){

float gettis = timespeed * istimescal;

if(instance != NULL){
if (istimescal > 0){
old_CCScheduler(instance, gettis);

}

 void* up = sharedDirector();
  if(isFps > 0){
      
    setAnimationInterval(up, isFps);
      
  }

}
return old_CCScheduler(instance, timespeed);

}

bool (*FRAGNADEinit)(void* instance);

void (*Old_fragnade)(void* instance ,float dt);
    void fragnade(void *instance, float dt){
    if (instance != NULL && currentTarget != NULL) {
       
    float y = GetPositionY(currentTarget);
    float x =  GetPositionX(currentTarget);
       
       if (tpnadeto && FRAGNADEinit(instance)){
       SettPositionX(instance, x);
       SettPositionY(instance, y);
       }
       
    
        
    }
    return Old_fragnade(instance, dt);
} 

void (*setRate)(void *instance, float ret);
void (*setAccuracyMod)(void *instance, float ret);
void (*setSpeedMod)(void *instance, float ret);

float (*getRate)(void* instance);


std::map<void*, float> originalRateStorage;




void (*old_Weapon)(void *instance, float dt);

void Weapon(void *instance, float dt) {
    if (instance != NULL) {
        
        
        
        if (issetSpeedMod > 0){
            
            setSpeedMod(instance, issetSpeedMod);
        } else {
            setSpeedMod(instance, 1);
            
        }
        
 
        if (originalRateStorage.find(instance) == originalRateStorage.end()) {
       
            float realOriginal = getRate(instance);
            originalRateStorage[instance] = realOriginal;
        }
        if (originalRateStorage.count(instance) > 0) {
    
        float baseRate = originalRateStorage[instance];
        if (issetRate > 0) {       
            float modifiedRate = baseRate * (1.0f - issetRate);
            setRate(instance, modifiedRate);
        } else {      
            setRate(instance, baseRate);
            originalRateStorage.erase(instance);
        }
      } 
    }
    return old_Weapon(instance, dt);
}

void (*Old_gasnade)(void* instance ,float dt);
    void gasnade(void *instance, float dt){
    if (instance != NULL && currentTarget != NULL) {
       
    float y = GetPositionY(currentTarget);
    float x =  GetPositionX(currentTarget);
       
       if (tpnadeto){
       SettPositionX(instance, x);
       SettPositionY(instance, y);
       }
       
    
        
    }
    return Old_gasnade(instance, dt);
} 

void (*old_proxynade)(void* instance ,float dt);
    void proxynade(void *instance, float dt){
    if (instance != NULL && currentTarget != NULL) {
       
    float y = GetPositionY(currentTarget);
    float x =  GetPositionX(currentTarget);
       
       if (tpnadeto){
       SettPositionX(instance, x);
       SettPositionY(instance, y);
       }
       
    
        
    }
    return old_proxynade(instance, dt);
} 

void (*old_empnade)(void* instance ,float dt);
    void empnade(void *instance, float dt){
    if (instance != NULL && currentTarget != NULL) {
       
    float y = GetPositionY(currentTarget);
    float x =  GetPositionX(currentTarget);
       
       if (tpnadeto){
       SettPositionX(instance, x);
       SettPositionY(instance, y);
       }
       
    
        
    }
    return old_empnade(instance, dt);
} 




float (*old_playerspeed)(void *instance);
float playerspeed(void *instance){
if (instance != NULL) {
if(isplayerspeed > 0){

return (float) isplayerspeed;
}
}
return old_playerspeed(instance);
}

bool (*old_isfire)(void* instance);
bool isfire(void* instance){
if(instance != NULL){

isfring = old_isfire(instance);

} 
return old_isfire(instance);

} 



void teleporting(){
	
		
		if (playerslist.empty() || !isteleport) {
          return; 
          }
		size_t size = playerslist.size();
		int random_steps = rand() % size; 

        
          auto it = playerslist.begin();
       
        std::advance(it, random_steps); 
        
          void* randomTarget = *it;
          
          void* rnd = NULL;

		  if (getTeamId(localPlayer) > 1 && getTeamId(randomTarget) != getTeamId(localPlayer)) {
       
       
        rnd = randomTarget;
            } else if (getTeamId(localPlayer) == 1) {
       rnd = randomTarget;
 
    } else {
        playerslist.erase(randomTarget);
        
    }
	
    
		if (!isdead(randomTarget) || gethp(randomTarget) > 0){
            
            
          
		if (rnd ){
			void* targetBody = *(void **)((char *)rnd + 0x148);
           if (targetBody != NULL){
           float targetX = *(float *)((char *)targetBody + 0x2c);
		   float targetY = *(float *)((char *)targetBody + 0x34);
		   void *body = *(void **)((char *)localPlayer + 0x148);
     if (body != NULL) {

        float *posX = (float *)((char *)body + 0x2c);
        float *posY = (float *)((char *)body + 0x34);
           
          *posX = targetX;
          *posY = targetY;
          
                 isteleport = false;
                        
               }
               }
			
		}
		}
		
	}
    
    

void (*old_SoldierLocalController)(void* instance ,float dt);
void SoldierLocalController(void *instance, float dt){
    if (instance != NULL) {
        
       
        localPlayer = instance;
      
        void *body = *(void **)((char *)instance + 0x148);
    if (body != NULL) {
        
        float *posX = (float *)((char *)body + 0x2c);
            float *posY = (float *)((char *)body + 0x34);

            if (isteleport2) {
                *posX = (float) teleportX;
                *posY = (float) teleportY;
                
                isteleport2 = false;
            }

            float *getBodyVelocityX = (float *)((char *)body + 0x38);
            float *getBodyVelocityY = (float *)((char *)body + 0x3c);
            
        //   getVelocityX = *getBodyVelocityX;
         //  getVelocityY = *getBodyVelocityY;
    } 
    
       
        
       
        currentTarget = bestCandidate;

     
        closestDistSq = FLT_MAX; 
        bestCandidate = NULL;

        
        if (getTeamId) cachedLocalTeam = getTeamId(instance);
        if (GetPositionX) cachedLocalX = GetPositionX(instance);
        if (GetPositionY) cachedLocalY = GetPositionY(instance);
    } else {
        localPlayer = NULL; 
    }
    

    
    return old_SoldierLocalController(instance, dt);
} 



void (*old_removebody)(void* instance);
void removebody(void* instance){
if (instance != NULL){
playerslist.erase(instance);

} 
return old_removebody(instance);
} 


void (*old_SoldierRemoteController)(void* instance, float dt);
void SoldierRemoteController(void* instance, float dt){
    
    if (instance != NULL) {
    
  Esize = playerslist.size();
        
     
    
   enemyPlayers = instance;
	
    if (getTeamId(localPlayer) > 1 && getTeamId(instance) != getTeamId(localPlayer) && !isdead(instance) || gethp(instance) > 0) {
       
    playerslist.insert(instance);
    } else if (!isdead(instance) || gethp(instance) > 0 && getTeamId(localPlayer) == 1) {
    playerslist.insert(instance);
 
    } else {
        playerslist.erase(instance);
        
    }
	
    	if(isteleport){
		teleporting();
		
	}
	
    
    
    
    
    if (localPlayer != NULL) {
        
       
        int remoteTeam = getTeamId(instance);
        
       
        if (cachedLocalTeam > 1 && cachedLocalTeam == remoteTeam) {
            return old_SoldierRemoteController(instance, dt);
        }

       
        float enX = GetPositionX(instance);
        float enY = GetPositionY(instance);

       
        float dx = cachedLocalX - enX;
        float dy = cachedLocalY - enY;

        
        float distSq = (dx * dx) + (dy * dy);

      
        if (distSq < closestDistSq) {
           
                closestDistSq = distSq;
                bestCandidate = instance;
               
            
        }
    } 
 }

    return old_SoldierRemoteController(instance, dt);
} 


float (*old_FireAngle)(void* instance);
float FireAngle(void* instance) {
    if (instance != NULL && localPlayer != NULL && currentTarget != NULL) {
        
       
        if (!isdead(currentTarget) || gethp(currentTarget) > 0) {
            
            
           
            float px = GetPositionX(localPlayer);
            float py = GetPositionY(localPlayer);
            
            float ex = GetPositionX(currentTarget);
            float ey = GetPositionY(currentTarget);

            float dx = ex - px;
            float dy = py - ey;
            
            
            float angleRad = atan2f(dy, dx);
            float angleDeg = angleRad * RAD2DEG; 
            
            
            if (angleDeg < 0) angleDeg += 360.0f;

            getfirdsingde = angleDeg;
           
        
        if (isAimbot && switc == 0) {
               
                return angleDeg;
            }
            
            if (isAimbot && switc == 1 && isfring) {
            
                return angleDeg;
            }
            
            if (isAimbot && switc == 2 && iscrousg(localPlayer)) {
            
                return angleDeg;
            }
            
           }
    }
    
    return old_FireAngle(instance);
}

float (*old_bullat)(void* instance);
float bullat(void* instance){
    if (instance != NULL){
        if(bullet_trake){
            return getfirdsingde;
        }
    }
    return old_bullat(instance);
}



float (*old_Dualfire)(void* instance);
float Dualfire(void* instance){
    if (instance != NULL){
        if(bullet_trake){
            return getfirdsingde;
        }
    }
    return old_Dualfire(instance);
}





void (*punch)(void* instance);
void (*onPressGrenade)(void* instance);



void (*old_hud)(void* instance, float dt);
void hud(void* instance, float dt) {
     
     if (instance != NULL){
        if (automille && currentTarget != NULL){
            if (!isdead(currentTarget) || gethp(currentTarget) > 0) {
           
             float mypy = GetPositionY(localPlayer);
             float mypx = GetPositionX(localPlayer);
       
             float enpy = GetPositionY(currentTarget);
             float enpx = GetPositionX(currentTarget);
       
             float dy = enpy - mypy;
             float dx = enpx - mypx;
       
             float distSq = (dx * dx) + (dy * dy);
             destincence = distSq;
             if (distSq < 4000){
              punch(instance);
          
             }
           }
        }
        if (autothrowg){
            onPressGrenade(instance);
        }
     }
 return old_hud(instance, dt);
}



void DrawESP(AadilDrawing esp, int width, int height) {

   // std::string any1 = std::to_string(baseRate);
    //std::string any2 = std::to_string(newRate);
//esp.DrawText(Color(0, 100, 255, 255), any.c_str(), Vector2(width / 2, height / 3.7), 20);



}

extern "C"
JNIEXPORT void JNICALL
Java_com_android_support_Menu_onGraphValueChanged(JNIEnv *env, jobject thiz, jfloat x, jfloat y) {
  teleportX = x;
   teleportY = y;
}
















































 
 void Draw(JNIEnv *env, jobject cls, jobject espview, jobject cvs) {
    aadildrawing = AadilDrawing(env, espview, cvs);
    if (aadildrawing.isValid()) DrawESP(aadildrawing, aadildrawing.getWidth(), aadildrawing.getHeight());
}
// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    
    ProcMap il2cppMap;
 
    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    


#else //To compile this code for armv7 lib only.

HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Weapon15getWeightFactorEv", playerspeed, old_playerspeed);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN23SoldierRemoteController10updateStepEf", SoldierRemoteController, old_SoldierRemoteController);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN22SoldierLocalController15updateModifiersEf", SoldierLocalController, old_SoldierLocalController);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN17SoldierController15removeBodyShapeEv", removebody, old_removebody);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Joypad12getFireAngleEv", FireAngle, old_FireAngle);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN3HUD10updateStepEf", hud, old_hud);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN8FRAGNADE14updateItemStepEf", fragnade, Old_fragnade);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN7cocos2d11CCScheduler6updateEf", CCScheduler, old_CCScheduler);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Joypad4fireEv", isfire, old_isfire);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN22SoldierLocalController16getDualFireAngleEv", Dualfire, old_Dualfire);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN22SoldierLocalController12getFireAngleEv", bullat, old_bullat);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN7GASNADE14updateItemStepEf", gasnade, Old_gasnade);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN9PROXYNADE14updateItemStepEf", proxynade, old_proxynade);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN7EMPNADE14updateItemStepEf", empnade, old_empnade);
HOOKSYM_LIB("libcocos2dcpp.so", "_ZN6Weapon14updateItemStepEf", Weapon, old_Weapon);






FRAGNADEinit = (bool(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN8FRAGNADE4initEv"));
setAnimationInterval = (void (*)(void*, double))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN7cocos2d21CCDisplayLinkDirector20setAnimationIntervalEd"));
sharedDirector = (void* (*)())dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN7cocos2d10CCDirector14sharedDirectorEv"));
setSpeedMod = (void(*)(void *, float))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN6Weapon11setSpeedModEf"));
getRate = (float(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN6Weapon7getRateEv"));
setAccuracyMod = (void(*)(void *, float))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN6Weapon14setAccuracyModEf"));
setRate = (void(*)(void *, float))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN6Weapon7setRateEf"));
iscrousg = (bool(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN17SoldierController8isDuckedEv"));
punch = (void(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN3HUD18onPressMeleeButtonEPN7cocos2d8CCObjectE"));
onPressGrenade = (void(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN3HUD20onPressGrenadeButtonEPN7cocos2d8CCObjectE"));
getTeamId = (int(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN15CollisionObject9getTeamIdEv"));
gethp = (int(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN17SoldierController5getHPEv"));
isdead = (bool(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN17SoldierController6isDeadEv"));
SettPositionY = (void(*)(void *, float))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN7cocos2d6CCNode12setPositionYEf"));
SettPositionX = (void(*)(void *, float))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN7cocos2d6CCNode12setPositionXEf"));
GetPositionX = (float(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN7cocos2d6CCNode12getPositionXEv"));
GetPositionY = (float(*)(void *))dlsym(dlopen(targetLibName, 4), OBFUSCATE("_ZN7cocos2d6CCNode12getPositionYEv"));


    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
  /*  if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;
        *p = 0;
    }*/
    
    

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
    
       OBFUSCATE("Collapse_AimBot"),
       OBFUSCATE("3_CollapseAdd_Toggle_Free Aim"),
       OBFUSCATE("1_CollapseAdd_Toggle_AIMBOT"),
       OBFUSCATE("2_CollapseAdd_RadioButton_Aimbot Mod_Normal Aim,Fire Aim,Crouch Aim"),         
       
       OBFUSCATE("Collapse_Teleoprt"),
       OBFUSCATE("4_CollapseAdd_Button_Teleport/R"),
       OBFUSCATE("8_CollapseAdd_Toggle_Tell Nade_teleport any grenade to enemy"),
       OBFUSCATE("11_CollapseAdd_Graph_Teleport_3_6_2_6"),
       OBFUSCATE("12_CollapseAdd_Button_Teleport"),
       
       OBFUSCATE("Collapse_Players Mods"),
       OBFUSCATE("5_CollapseAdd_Toggle_Auto Punch_For Pro players"),
       OBFUSCATE("6_CollapseAdd_SeekBarDec_Speed_0.0000_3.0000"),
       
       OBFUSCATE("Collapse_Weapons Mods"),
       OBFUSCATE("10_CollapseAdd_SeekBarDec_FireRate [BETA]_0.0000_1.0000"),
       OBFUSCATE("9_CollapseAdd_SeekBarDec_Bullet Speed_0.0000_10.0000"),
       
       
       OBFUSCATE("Collapse_Game Manager"),
       OBFUSCATE("7_CollapseAdd_SeekBarDec_Game Speed_0.0000_10.0000"),
       OBFUSCATE("13_CollapseAdd_SeekBarDec_Game FPS_0.0000_10.0000"),
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj, jint featNum, jstring featName, 
                                        jint value1, jint value2, jint value3, jint value4,
                                        jboolean boolean, jstring str, jlong jng, jshort sht, jdouble dub) {
                                        
 /*void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) { */

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value1,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
          
        case 1:
            isAimbot = boolean;
        break;
        case 2:
            switch (value1) {
               
              case 1:
                    switc = 0;
                    break;
              case 2:
                    switc = 1;
                    break;
              case 3:
                    switc = 2;
              break;
            }
            
          break;
          case 3:
          bullet_trake = boolean;

          break;
          case 4:
          isteleport = true;
          break;
          case 5:
          automille = boolean;
          break;
          case 6:
          isplayerspeed = dub;
          break;
          case 7:
          istimescal = dub;
          break;
          case 8:
          tpnadeto = boolean;
          break;
          case 9:
           issetSpeedMod = dub;
          break;
          case 10:
          issetRate = dub;
          break;
          case 12:
          isteleport2 = true;
          break;
          case 13:
          isFps = dub;
          break;
            
         
    }
}

__attribute__((constructor))
void lib_main() {
    
    InitializeLogger();
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("Info"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Info)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
            {OBFUSCATE("Draw"),  OBFUSCATE("(Lcom/android/support/ESPView;Landroid/graphics/Canvas;)V"), reinterpret_cast<void *>(Draw)},
 
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
             {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IIIIZLjava/lang/String;JSD)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

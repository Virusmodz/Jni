#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <thread>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include <string>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu/Setup.h"
#include <cmath>  
#include <cfloat> 
#include <unordered_set>
#include <cstdlib>
#include <sstream>
#include <vector> 
#include "points.h"
#include "Includes/enc.h"


//Target lib here
#define targetLibName OBFUSCATE("libcocos2dcpp.so")

#include "Includes/Macros.h"

void* VoidOdj = NULL;
std::ostringstream oss;

struct Variables {

    bool VoidHook = false;
    const char *offsetToHookVoid;
    std::string adrassas = "";

    

} VM;





static float hpvalue = 0.0f;  

float destincence;
float isboost = 0;
float distence;
bool isteleport, autothrowg;

int Esize;

float positionsX, positionsY;

bool isAimbot, automille, isadrasss, isadrasssEP, copyid;

constexpr float PI_F = 3.14159265358979323846f;
constexpr float RAD2DEG = 180.0f / PI_F;

int (*getTeamId)(void* instance); // get players team id like 1 to 7, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead


using namespace std;

unordered_set<void *> playerslist;


void* enemyPlayers = NULL;
void* localPlayer = NULL;
void* currentTarget = NULL;   
void* bestCandidate = NULL;    
float closestDistSq = FLT_MAX; 
float (*old_boost)(void *instance);

int cachedLocalTeam = -1;
float cachedLocalX = 0.0f;
float cachedLocalY = 0.0f;



float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);

//#include <string>



std::string GetAndroidID(JNIEnv *env, jobject context) {
    if (!context) return "";

    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, OBFUSCATE("getContentResolver"), OBFUSCATE("()Landroid/content/ContentResolver;"));
    
    jclass settingSecureClass = env->FindClass(OBFUSCATE("android/provider/Settings$Secure"));
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, OBFUSCATE("getString"), OBFUSCATE("(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));

    jobject contentResolver = env->CallObjectMethod(context, getContentResolverMethod);
    if (!contentResolver) return "";

    jstring androidIdKey = env->NewStringUTF(OBFUSCATE("android_id"));
    jstring str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, contentResolver, androidIdKey);
    env->DeleteLocalRef(androidIdKey);

    if (!str) return "";

    const char *chars = env->GetStringUTFChars(str, 0);
    std::string ret(chars); // Copy to std::string
    env->ReleaseStringUTFChars(str, chars); // Clean up memory
    
    return ret;
}


void teleporting(){
	
		
		if (playerslist.empty() || !isteleport) {
          return; 
          }
		size_t size = playerslist.size();
		int random_steps = rand() % size; 

        
          auto it = playerslist.begin();
       
        std::advance(it, random_steps); 

		
       
        void* randomTarget = *it;
		if (!isdead(randomTarget) || gethp(randomTarget) > 0){
		if (randomTarget ){
			void* targetBody = *(void **)((char *)randomTarget + 0x148);
           if (targetBody != NULL){
           float targetX = *(float *)((char *)targetBody + 0x2c);
		   float targetY = *(float *)((char *)targetBody + 0x34);
		   void *body = *(void **)((char *)localPlayer + 0x148);
     if (body != NULL) {

        float *posX = (float *)((char *)body + 0x2c);
        float *posY = (float *)((char *)body + 0x34);
           
          *posX = targetX;
          *posY = targetY;
          
                 isteleport = false;
                        
               }
               
			}
		}
		}
		
	}
    
    
	void (*old_VoidHook)(void* instance ,float dt);
    void VoidHook(void *instance, float dt){
    if (instance != NULL) {
        
       if (VM.VoidHook){
       
       positionsX = GetPositionX(instance);
       positionsY = GetPositionX(instance);
       
       VoidOdj = instance;
       
      //VM.adrassas = std::to_string(positionsX);
      
        std::ostringstream addressStream;
        addressStream << "0x" << std::hex << (uintptr_t)instance;
        VM.adrassas = addressStream.str(); 
       }
        
    }
    return old_VoidHook(instance, dt);
} 

void (*old_SoldierLocalController)(void* instance ,float dt);
void SoldierLocalController(void *instance, float dt){
    if (instance != NULL) {
        void *enemyp = *(void **)((char *)instance + 0x150);
        
        if(enemyp != NULL){
        void *remoteP = *(void **)((char *)enemyp + 0x2d0);
        
        if (remoteP != NULL){
        
        }
        
        }
        if (isadrasss) {
        
        LOGI("InstanceMyP : %p", instance);
        isadrasss = false;
        }
        localPlayer = instance;
      
void *body = *(void **)((char *)instance + 0x148);
    if (body != NULL) {

            float *getBodyVelocityX = (float *)((char *)body + 0x38);
            float *getBodyVelocityY = (float *)((char *)body + 0x3c);
            
        //   getVelocityX = *getBodyVelocityX;
         //  getVelocityY = *getBodyVelocityY;
    } 
        
       
        currentTarget = bestCandidate;

     
        closestDistSq = FLT_MAX; 
        bestCandidate = NULL;

        
        if (getTeamId) cachedLocalTeam = getTeamId(instance);
        if (GetPositionX) cachedLocalX = GetPositionX(instance);
        if (GetPositionY) cachedLocalY = GetPositionY(instance);
    } else {
        localPlayer = NULL; 
    }
    return old_SoldierLocalController(instance, dt);
} 



void (*old_removebody)(void* instance);
void removebody(void* instance){
if (instance != NULL){
playerslist.erase(instance);

} 
return old_removebody(instance);
} 


void (*old_SoldierRemoteController)(void* instance, float dt);
void SoldierRemoteController(void* instance, float dt){
    
    if (instance != NULL) {
    
  Esize = playerslist.size();
        
        if (isadrasssEP){
        
        LOGI("InstanceEnP : %p", instance);
        isadrasssEP = false;
        }
    
   enemyPlayers = instance;
	
    if (getTeamId(localPlayer) > 1 && getTeamId(localPlayer) != getTeamId(instance) && !isdead(instance) || gethp(instance) > 0) {
       
    playerslist.insert(instance);
    } else if (!isdead(instance) || gethp(instance) > 0 && getTeamId(localPlayer) == 1) {
    playerslist.insert(instance);
 
    } else {
        playerslist.erase(instance);
        
    }
	
    	if(isteleport){
		teleporting();
		
	}
	
    
    
    
    
    if (localPlayer != NULL && isAimbot) {
        
       
        int remoteTeam = getTeamId(instance);
        
       
        if (cachedLocalTeam > 1 && cachedLocalTeam == remoteTeam) {
            return old_SoldierRemoteController(instance, dt);
        }

       
        float enX = GetPositionX(instance);
        float enY = GetPositionY(instance);

       
        float dx = cachedLocalX - enX;
        float dy = cachedLocalY - enY;

        
        float distSq = (dx * dx) + (dy * dy);

      
        if (distSq < closestDistSq) {
           
                closestDistSq = distSq;
                bestCandidate = instance;
               
            
        }
    } 
 }

    return old_SoldierRemoteController(instance, dt);
} 


float (*old_FireAngle)(void* instance);
float FireAngle(void* instance) {
    if (isAimbot && instance != NULL && localPlayer != NULL && currentTarget != NULL) {
        
       
        if (!isdead(currentTarget) || gethp(currentTarget) > 0) {
            
            
           
            float px = GetPositionX(localPlayer);
            float py = GetPositionY(localPlayer);
            
            float ex = GetPositionX(currentTarget);
            float ey = GetPositionY(currentTarget);

            float dx = ex - px;
            float dy = py - ey;
            
            
            float angleRad = atan2f(dy, dx);
            float angleDeg = angleRad * RAD2DEG; 
            
            
            if (angleDeg < 0) angleDeg += 360.0f;

            return angleDeg;
        }
    }
    
    return old_FireAngle(instance);
}

void (*punch)(void* instance);
void (*onPressGrenade)(void* instance);


void (*old_hud)(void* instance, float dt);
void hud(void* instance, float dt) {
     
     if (instance != NULL){
        if (automille && currentTarget != NULL){
            if (!isdead(currentTarget) || gethp(currentTarget) > 0) {
           
             float mypy = GetPositionY(localPlayer);
             float mypx = GetPositionX(localPlayer);
       
             float enpy = GetPositionY(currentTarget);
             float enpx = GetPositionX(currentTarget);
       
             float dy = enpy - mypy;
             float dx = enpx - mypx;
       
             float distSq = (dx * dx) + (dy * dy);
             destincence = distSq;
             if (distSq < 4000){
              punch(instance);
          
             }
           }
        }
        if (autothrowg && hpvalue < 1){
            onPressGrenade(instance);
        }
     }
 return old_hud(instance, dt);
}



float (*old_halte)(void *instance);  

float halte(void *instance) {
    if (instance != NULL) {
      
       hpvalue = old_halte(instance);
        
    }
    
    return old_halte(instance);
}



float Boost(void *instance){
    if (instance != NULL){
        
        isboost = old_boost(instance);
        
        
    }
    return old_boost(instance);
}


std::string (*old_pacage)(void* instance);
std::string pacage(void* instance){
  if (instance != NULL){
  
  
  }
 return old_pacage(instance);
}


      

extern "C" JNIEXPORT jobjectArray JNICALL
Java_com_android_support_Menu_GetTextList(JNIEnv *env, jobject context) {
    
 //   if (copyid){
    std::string getid = GetAndroidID(env, context);
  //  copyid = false;
    
    std::vector<std::string> values;

    
    values.push_back(std::to_string((int)hpvalue)); //0
    values.push_back(std::to_string((int)isboost)); //1
    values.push_back(std::to_string(destincence)); //2
    values.push_back(std::to_string(positionsX)); //3
    values.push_back(std::to_string(positionsY)); //4
    values.push_back(VM.adrassas.c_str()); //5
    values.push_back(Scanner.resultText.c_str()); //6 
    values.push_back(std::to_string(Esize)); //7
    values.push_back(getid); //8

          

          


   
    jclass stringClass = env->FindClass("java/lang/String");
    jobjectArray ret = env->NewObjectArray(values.size(), stringClass, env->NewStringUTF(""));
    for (size_t i = 0; i < values.size(); i++) {
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(values[i].c_str()));
    }

    return ret;
}




















// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) //To compile this code for arm64 lib only. Do not worry about greyed out highlighting code, it still works
    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    

    

#else //To compile this code for armv7 lib only.
MSHookFunction((void *) getAbsoluteAddress(targetLibName, 0x7ad9cc), (void *) halte, (void **) &old_halte);
PATCH_SYM("_ZN14NetworkManager18requestSpendTokensENSt6__ndk112basic_stringIcNS0_11char_traitsIcEENS0_9allocatorIcEEEEi", "01 00 A0 E3 1E FF 2F E1");
HOOK_LIB("libcocos2dcpp.so", "0x7a4108", Boost, old_boost);

HOOK_LIB("libcocos2dcpp.so", "0x7a5170", SoldierLocalController, old_SoldierLocalController);
HOOK_LIB("libcocos2dcpp.so", "0x7b2d48", SoldierRemoteController, old_SoldierRemoteController);

HOOK_LIB("libcocos2dcpp.so", "0x5156b8", FireAngle, old_FireAngle);

getTeamId = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x4361e0); 
gethp = (int (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1b8); 
isdead = (bool (*)(void *))getAbsoluteAddress(targetLibName, 0x79f1f8); 
HOOK_LIB("libcocos2dcpp.so", "0x79e224", removebody, old_removebody);
HOOK_LIB("libcocos2dcpp.so", "0x8767d4", pacage, old_pacage);

GetPositionX = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c791); 
GetPositionY = (float (*)(void *))getAbsoluteAddress(targetLibName, 0xa9c79f); 

HOOK_LIB("libcocos2dcpp.so", "0x4fa4b4", hud, old_hud);

punch = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x4f50c4); 
onPressGrenade = (void (*)(void *))getAbsoluteAddress(targetLibName, 0x4f4fbc); 


    // Hook example. Comment out if you don't use hook
    // Strings in macros are automatically obfuscated. No need to obfuscate!
    

    LOGI(OBFUSCATE("Done"));
#endif

    //Anti-leech
    /*if (!iconValid || !initValid || !settingsValid) {
        //Bad function to make it crash
        sleep(5);
        int *p = 0;Boostview
        *p = 0;
    }*/

    return NULL;
}

// Do not change or translate the first text unless you know what you are doing
// Assigning feature numbers is optional. Without it, it will automatically count for you, starting from 0
// Assigned feature numbers can be like any numbers 1,3,200,10... instead in order 0,1,2,3,4,5...
// ButtonLink, Category, RichTextView and RichWebView is not counted. They can't have feature number assigned
// Toggle, ButtonOnOff and Checkbox can be switched on by default, if you add True_. Example: CheckBox_True_The Check Box
// To learn HTML, go to this page: https://www.w3schools.com/

jobjectArray GetFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    const char *features[] = {
            OBFUSCATE("Category_Player info"),
            OBFUSCATE("TextListValue_Device ID_8"),
            OBFUSCATE("TextListValue_Health_0"), 
            OBFUSCATE("TextListValue_Boost_1"), 
            OBFUSCATE("TextListValue_Dist_2"), 
            OBFUSCATE("TextListValue_Enemys.._7"), 
            OBFUSCATE("TextListValue_Address_5"), 
            OBFUSCATE("TextListValue_PositionsX_3"), 
            OBFUSCATE("TextListValue_PositionsY_4"), 
            OBFUSCATE("TextListValue_ScanResult_6"), // <--- NEW: Show Scan Result (Index 6)
   
            
            OBFUSCATE("Category_Aimbot"), //Not counted
            ENC_RT("1_Toggle_AIMBOT").get(),
            OBFUSCATE("2_Button_Teleport"),
            OBFUSCATE("12_Button_Get Adrasss"),
            OBFUSCATE("13_Button_COPY ID"),
            
            OBFUSCATE("3_Toggle_Auto Punch"),
            OBFUSCATE("5_Toggle_Auto Nade"),
            OBFUSCATE("4_InputValue_Enter dis"),
            OBFUSCATE("Toggle_Testing7"),
            
            OBFUSCATE("Collapse_Hook"),
            OBFUSCATE("6_CollapseAdd_InputText_Input Offset"),
            OBFUSCATE("7_CollapseAdd_Toggle_Hook"),
            
            OBFUSCATE("CollapseAdd_Category_Pointer Scanner"),     
            OBFUSCATE("8_CollapseAdd_InputText_Start Addr (Hex)"),
            OBFUSCATE("9_CollapseAdd_InputText_Target Addr (Hex)"),
            OBFUSCATE("10_CollapseAdd_InputValue_Max Range (Hex)"), 
            OBFUSCATE("11_CollapseAdd_Toggle_Start Scan"), // Changed to Toggle so you can 
            
    };

    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    return (ret);
}

void Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
       case 1:
    isAimbot = boolean;
          break;
    case 2:
    isteleport = true;
    break;
    case 3:
    automille = boolean;
    break;
    case 4:
    distence = value;
    break;
    case 5:
    autothrowg = boolean;
    break;
    case 6:
    VM.offsetToHookVoid = env->GetStringUTFChars(str, 0);
    break;
    case 7:
    VM.VoidHook = boolean;
    if (VM.offsetToHookVoid == NULL){
   
    } else if(VM.VoidHook){
   VirusmodzHook("libcocos2dcpp.so", VM.offsetToHookVoid, VoidHook, old_VoidHook);
    }
   // PatchVoidLong = (void (*)(void *, long))getAbsoluteAddress(NM.libname, string2Offset(NM.offsetToHookVoidLong));
    break;
    
    case 8: 
            Scanner.startAddress = HexToAddr(env->GetStringUTFChars(str, 0));
            break;
            
       case 9: 
            Scanner.targetAddress = HexToAddr(env->GetStringUTFChars(str, 0));
            break;
            
       case 10: 
            Scanner.maxRange = value; 
            break;
            
       case 11: 
            if (boolean) {
                StartScanAsync();
            } else {
                StopScan();
            }
            break;
       case 12:
           isadrasss = true;
           isadrasssEP = true;
           break;
    }
}

__attribute__((constructor))
void lib_main() {
InitializeLogger();
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

int RegisterMenu(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Icon"), OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(Icon)},
            {OBFUSCATE("IconWebViewData"),  OBFUSCATE("()Ljava/lang/String;"), reinterpret_cast<void *>(IconWebViewData)},
            {OBFUSCATE("IsGameLibLoaded"),  OBFUSCATE("()Z"), reinterpret_cast<void *>(isGameLibLoaded)},
            {OBFUSCATE("Init"),  OBFUSCATE("(Landroid/content/Context;Landroid/widget/TextView;Landroid/widget/TextView;)V"), reinterpret_cast<void *>(Init)},
            {OBFUSCATE("SettingsList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(SettingsList)},
            {OBFUSCATE("GetFeatureList"),  OBFUSCATE("()[Ljava/lang/String;"), reinterpret_cast<void *>(GetFeatureList)},
    };

    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Menu"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterPreferences(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("Changes"), OBFUSCATE("(Landroid/content/Context;ILjava/lang/String;IZLjava/lang/String;)V"), reinterpret_cast<void *>(Changes)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Preferences"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;
    return JNI_OK;
}

int RegisterMain(JNIEnv *env) {
    JNINativeMethod methods[] = {
            {OBFUSCATE("CheckOverlayPermission"), OBFUSCATE("(Landroid/content/Context;)V"), reinterpret_cast<void *>(CheckOverlayPermission)},
    };
    jclass clazz = env->FindClass(OBFUSCATE("com/android/support/Main"));
    if (!clazz)
        return JNI_ERR;
    if (env->RegisterNatives(clazz, methods, sizeof(methods) / sizeof(methods[0])) != 0)
        return JNI_ERR;

    return JNI_OK;
}

extern "C"
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *env;
    vm->GetEnv((void **) &env, JNI_VERSION_1_6);
    if (RegisterMenu(env) != 0)
        return JNI_ERR;
    if (RegisterPreferences(env) != 0)
        return JNI_ERR;
    if (RegisterMain(env) != 0)
        return JNI_ERR;
    return JNI_VERSION_1_6;
}

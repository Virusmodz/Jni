#include "loginUtils/json.hpp"
#include <curl/curl.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <sstream>
#include <iomanip>
#include <cctype>
#include "Includes/enc.h"
#include "protect.h"
#include <ctime>
#include <sstream>

std::string UnixToDate(long long timestamp) {
    time_t t = (time_t)timestamp;
    tm *lt = localtime(&t);

    std::ostringstream oss;
    oss << lt->tm_mday << "-"
        << (lt->tm_mon + 1) << "-"
        << (lt->tm_year + 1900);

    return oss.str(); // e.g. 19-4-2026
}

using json = nlohmann::json;

SafeValue<bool> SafeServerLogin(false);
SafeValue<bool> SafeVipUser(false);

bool ServerLogin = false;
std::string vipuser = ENC_RT("notvip");
/*--------- Utility: URL Encoding (Optimized) ---------------*/
std::string urlEncode(const std::string& value) {
    std::ostringstream encoded;
    encoded << std::hex << std::uppercase;
    for (char c : value) {
        if (std::isalnum(static_cast<unsigned char>(c)) ||
            c == '-' || c == '_' || c == '.' || c == '~') {
            encoded << c;
        } else {
            encoded << '%' << std::setw(2) << std::setfill('0')
                    << static_cast<int>(static_cast<unsigned char>(c));
        }
    }
    return encoded.str();
}


size_t writeCallback(char *contents, size_t size, size_t nmemb, std::string *userp) {
    size_t totalSize = size * nmemb;
    userp->append(contents, totalSize);
    return totalSize;
}


std::string performRequest(const std::string& url) {
    CURL *curl;
    CURLcode res;
    std::string responseBuffer;

    curl = curl_easy_init();
    if (curl) {
    
    
    ENC_RT_GUARD(pinnedKey, "sha256//851V+srg+3VrHfqc5vhcpTI/VLPzUBfY8f42kBX2VlA=");
      
        
        // Optimizations for speed and reliability
        curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1L);
     //   curl_easy_setopt(curl, CURLOPT_TIMEOUT, 10L); // 10 seconds timeout
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0L); // Note: Set to 1L for 
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 0L);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, writeCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, &responseBuffer);
        curl_easy_setopt(curl, CURLOPT_USERAGENT, "FirebaseMod/1.0");
        curl_easy_setopt(curl, CURLOPT_PINNEDPUBLICKEY, pinnedKey.get());
        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        //curl_easy_setopt(curl, CURLOPT_PINNEDPUBLICKEY, permanentPins.c_str());
        curl_easy_setopt(curl, CURLOPT_ACCEPT_ENCODING, "gzip, deflate"); 
        curl_easy_setopt(curl, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4); 
        curl_easy_setopt(curl, CURLOPT_CONNECTTIMEOUT_MS, 15000L);
        curl_easy_setopt(curl, CURLOPT_TIMEOUT_MS, 20000L);
        
        curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1L);


        res = curl_easy_perform(curl);
        
        if (res != CURLE_OK) {
            LOGE("Curl Request Failed: %s", curl_easy_strerror(res));
            curl_easy_cleanup(curl);
            return "error"; // Return empty on failure
        }
        curl_easy_cleanup(curl);
    }
    return responseBuffer;
}

std::string GetAndroidID(JNIEnv *env, jobject context) {
    if (!context) return "";

    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass, OBFUSCATE("getContentResolver"), OBFUSCATE("()Landroid/content/ContentResolver;"));
    
    jclass settingSecureClass = env->FindClass(OBFUSCATE("android/provider/Settings$Secure"));
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, OBFUSCATE("getString"), OBFUSCATE("(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));

    jobject contentResolver = env->CallObjectMethod(context, getContentResolverMethod);
    if (!contentResolver) return "";

    jstring androidIdKey = env->NewStringUTF(OBFUSCATE("android_id"));
    jstring str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, contentResolver, androidIdKey);
    env->DeleteLocalRef(androidIdKey);

    if (!str) return "";

    const char *chars = env->GetStringUTFChars(str, 0);
    std::string ret(chars); // Copy to std::string
    env->ReleaseStringUTFChars(str, chars); // Clean up memory
    
    return ret;
}

// Ensure this matches your JSON key exactly
#define CURRENT_GAME_NAME ENC_RT("MinimilitiaClassic32bitv2") 

std::string login(JNIEnv *env, jobject obj, const char *inputKey) {
    std::string keyString(inputKey);
    std::string expiryInfo = "";
    if (keyString.empty()) {
        Toast(env, obj, ENC_RT("Key cannot be empty"), ToastLength::LENGTH_SHORT);
        return ENC_RT("false");
        SafeServerLogin.set(false);
    }

    // 1. Get the current User's Device ID
    std::string currentDeviceID = GetAndroidID(env, obj);
    ENC_RT_GUARD(FIREBASE_DB_URL, "https://keymanager-71c7b-default-rtdb.firebaseio.com/");
    // Construct URL: https://URL/Users/GAME_NAME/KEY.json
    std::string requestUrl = std::string(FIREBASE_DB_URL.get());
    requestUrl += "Users/";
    requestUrl += std::string(CURRENT_GAME_NAME);
    requestUrl += "/"; 
    requestUrl += urlEncode(keyString);
    requestUrl += ".json";

    std::string response = performRequest(requestUrl);

    try {
    
     
        if (response.empty() || response == "null") {
            Toast(env, obj, ENC_RT("Your key is invalid or expired"), ToastLength::LENGTH_LONG);
            
            SafeServerLogin.set(false);
            return ENC_RT("false");
        } else if (response == "error"){
     Toast(env, obj, ENC_RT("Connection Failed"), ToastLength::LENGTH_LONG);
     
     SafeServerLogin.set(false);
     return ENC_RT("false");
     }

        json data = json::parse(response);

        if (!data.is_null()) {
            
            // Check Status
            if (data.contains("status")) {
                std::string status = data.value("status", "");
                       if (hashStr(status.c_str()) != hashStr("active")) {
                     Toast(env, obj, ENC_RT("Key Expired"), ToastLength::LENGTH_LONG);
                     
                     SafeServerLogin.set(false);
                     return ENC_RT("false");
                }
            }

            // --- HWID LOGIC STARTS HERE ---
           // --- HWID LOGIC STARTS HERE ---
if (data.contains("hwid")) {
    std::string serverHwid = data["hwid"].get<std::string>();

    if (!serverHwid.empty()) {

        if (serverHwid == currentDeviceID) {

            

            if (data.contains("expiry")) {
                std::string expiryStr = data["expiry"].get<std::string>();
                long long expiryTimestamp = atoll(expiryStr.c_str());

                std::string expiryDate = UnixToDate(expiryTimestamp);
                expiryInfo = "\nExpiry: " + expiryDate;
            }

            std::string msg = "VIP Login Successful" + expiryInfo;

            Toast(env, obj, msg.c_str(), ToastLength::LENGTH_LONG);

            SafeVipUser.set(true);
            SafeServerLogin.set(true);
            return ENC_RT("true");
        }

        if (serverHwid != currentDeviceID) {
            Toast(env, obj,
                  ENC_RT("Login Failed: Key locked to another device"),
                  ToastLength::LENGTH_LONG);

            SafeServerLogin.set(false);
            return ENC_RT("false");
        }
    }
}
// --- HWID LOGIC ENDS HERE ---
            
       
            // --- HWID LOGIC ENDS HERE ---

            
               
    
    
Toast(env, obj, ENC_RT("Login Successful!" + expiryInfo), ToastLength::LENGTH_LONG);
            
    
    SafeServerLogin.set(true);
            return ENC_RT("true");

            
            
        } 
        
    } catch (const std::exception &e) {
     
        Toast(env, obj, ENC_RT("Connection Error"), ToastLength::LENGTH_LONG);
    }
SafeServerLogin.set(false);
    return ENC_RT("false");
    
}

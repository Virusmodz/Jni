#include <unistd.h>
#include <setjmp.h>
#include <signal.h>
#include <atomic>
#include <sstream>
#include <thread>
#include <string>
#include <vector>

// --- Crash Recovery Variables ---
// We use these to "jump back" if a crash happens during a read
static jmp_buf jumpBuffer;
static struct sigaction old_sa, new_sa;
static std::atomic<bool> isSafeReadMode{false};

// --- Signal Handler ---
// If a crash (SIGSEGV) happens, this function runs instead of killing the app
void segv_handler(int sig) {
    if (isSafeReadMode) {
        longjmp(jumpBuffer, 1); // Jump back to the safe point
    }
    // If we are NOT in safe mode, let the app crash normally (so we know if other things break)
    // You might want to restore the old handler here if needed, but for AIDE this is usually enough.
    signal(sig, SIG_DFL);
    raise(sig);
}

// --- Safe Read Function ---
// Tries to read memory. Returns true if successful, false if it would have crashed.
bool safeRead(uintptr_t address, uintptr_t& outValue) {
    // 1. Basic sanity checks (alignment and null)
    if (address < 0x100000 || address % 4 != 0) return false;

    // 2. Setup Crash Handling
    // Save the current signal handler
    sigaction(SIGSEGV, NULL, &old_sa); 
    
    // Set our new handler
    memset(&new_sa, 0, sizeof(new_sa));
    new_sa.sa_handler = segv_handler;
    new_sa.sa_flags = SA_NODEFER; // Important: Allow catching multiple signals
    sigaction(SIGSEGV, &new_sa, NULL);

    isSafeReadMode = true;

    // 3. The "Try" Block
    if (setjmp(jumpBuffer) == 0) {
        // This is the dangerous line. If it crashes, segv_handler runs longjmp, 
        // and we go to the 'else' block below.
        outValue = *(uintptr_t*)address;
        
        // Success! Restore settings
        isSafeReadMode = false;
        sigaction(SIGSEGV, &old_sa, NULL);
        return true;
    } else {
        // 4. The "Catch" Block
        // We arrived here because of a crash/longjmp.
        isSafeReadMode = false;
        sigaction(SIGSEGV, &old_sa, NULL); // Restore original handler
        return false; // Reading failed
    }
}

struct ScannerState {
    uintptr_t startAddress = 0;
    uintptr_t targetAddress = 0;
    int maxRange = 1024;
    
    std::atomic<bool> isScanning{false};
    std::atomic<bool> stopRequest{false};
    std::string resultText = "Status: Ready";
} Scanner;

// --- HELPER: Convert Hex String ---
uintptr_t HexToAddr(const char* str) {
    uintptr_t x;
    std::stringstream ss;
    ss << std::hex << str;
    ss >> x;
    return x;
}

// --- WORKER THREAD ---
void ScanWorker() {
    Scanner.isScanning = true;
    Scanner.stopRequest = false;
    Scanner.resultText = "Scanning...";
    
    uintptr_t start = Scanner.startAddress;
    uintptr_t target = Scanner.targetAddress;
    int range = Scanner.maxRange;
    
    std::stringstream resultSS;
    bool found = false;
    uintptr_t val = 0;

    // --- LEVEL 1: Direct Offset ---
    for (int i = 0; i <= range; i += 4) {
        if (Scanner.stopRequest) break;

        // Use safeRead instead of direct access
        if (safeRead(start + i, val)) {
            if (val == target) {
                resultSS << "[L1] 0x" << std::hex << i << "\n";
                found = true;
            }
        }
    }

    // --- LEVEL 2: Pointer -> Offset ---
    if (!found) {
        for (int i = 0; i <= range; i += 4) {
            if (Scanner.stopRequest) {
                Scanner.resultText = "Stopped.";
                Scanner.isScanning = false;
                return;
            }

            if (i % 200 == 0) {
                 int pct = (i * 100) / range;
                 Scanner.resultText = "Scan: " + std::to_string(pct) + "%";
            }

            // 1. Read first level safely
            uintptr_t firstLevelPtr = 0;
            if (!safeRead(start + i, firstLevelPtr)) continue;

            // 2. Check if the value inside is a valid pointer candidate
            // (Must be > 1MB and aligned)
            if (firstLevelPtr < 0x100000 || firstLevelPtr % 4 != 0) continue;

            // 3. Scan second level
            for (int j = 0; j <= range; j += 4) {
                uintptr_t finalVal = 0;
                
                // Read the final destination safely
                if (safeRead(firstLevelPtr + j, finalVal)) {
                    if (finalVal == target) {
                        resultSS << "[L2] 0x" << std::hex << i << " -> 0x" << j << "\n";
                        found = true;
                        Scanner.stopRequest = true; 
                        break; 
                    }
                }
            }
            if(found) break;
        }
    }

    if (found) {
        Scanner.resultText = "Found:\n" + resultSS.str();
    } else {
        Scanner.resultText = "Not Found";
    }
    
    Scanner.isScanning = false;
}

// --- START / STOP ---
void StartScanAsync() {
    if (Scanner.isScanning) return;
    std::thread(ScanWorker).detach();
}

void StopScan() {
    if (Scanner.isScanning) Scanner.stopRequest = true;
}

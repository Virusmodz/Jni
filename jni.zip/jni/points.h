#include <unistd.h>
#include <sys/mman.h>
#include <atomic>
#include <sstream>
#include <thread>
#include <string>
#include <vector>

// Get system page size
size_t pageSize = sysconf(_SC_PAGESIZE);

struct ScannerState {
    uintptr_t startAddress = 0;
    uintptr_t targetAddress = 0;
    int maxRange = 1024;
    
    std::atomic<bool> isScanning{false};
    std::atomic<bool> stopRequest{false};
    std::string resultText = "Status: Ready";
} Scanner;

// --- SAFETY: The Crash Fix ---
// 1. Checks if address is too small (garbage)
// 2. Checks if address is aligned (pointers must divide by 4)
// 3. Checks if memory is actually mapped using mincore()
bool isSafeToRead(uintptr_t addr) {
    // Basic Filters
    if (addr < 0x100000) return false;      // Filter out small numbers
    if (addr > 0xFFFFFFFF) return false;    // Filter out crazy high numbers (if 32bit)
    if (addr % 4 != 0) return false;        // Pointers are ALWAYS 4-byte aligned!

    // Advanced: Check if page exists
    void* pageStart = (void*)(addr & ~(pageSize - 1));
    unsigned char vec = 0;
    
    // mincore returns -1 if the memory is NOT mapped.
    if (mincore(pageStart, pageSize, &vec) == -1) {
        return false; // This memory does not exist! Do not touch.
    }
    return true; // Safe to read
}

// --- HELPER: Convert Hex String ---
uintptr_t HexToAddr(const char* str) {
    uintptr_t x;
    std::stringstream ss;
    ss << std::hex << str;
    ss >> x;
    return x;
}

// --- WORKER THREAD ---
void ScanWorker() {
    Scanner.isScanning = true;
    Scanner.stopRequest = false;
    Scanner.resultText = "Scanning...";
    
    uintptr_t start = Scanner.startAddress;
    uintptr_t target = Scanner.targetAddress;
    int range = Scanner.maxRange;
    
    std::stringstream resultSS;
    bool found = false;

    // Validate Start Address
    if (!isSafeToRead(start)) {
        Scanner.resultText = "Error: Bad Start Addr";
        Scanner.isScanning = false;
        return;
    }

    // --- LEVEL 1: Direct Offset ---
    for (int i = 0; i <= range; i += 4) {
        if (Scanner.stopRequest) break;

        uintptr_t currentAddr = start + i;
        
        // Safety Check
        if (!isSafeToRead(currentAddr)) continue;

        uintptr_t val = *(uintptr_t*)currentAddr;
        if (val == target) {
            resultSS << "[L1] 0x" << std::hex << i << "\n";
            found = true;
        }
    }

    // --- LEVEL 2: Pointer -> Offset ---
    if (!found) {
        for (int i = 0; i <= range; i += 4) {
            if (Scanner.stopRequest) {
                Scanner.resultText = "Stopped.";
                Scanner.isScanning = false;
                return;
            }

            // Progress Update
            if (i % 500 == 0) {
                 int pct = (i * 100) / range;
                 Scanner.resultText = "Deep Scan: " + std::to_string(pct) + "%";
            }

            uintptr_t ptrAddr = start + i;
            
            // 1. Is the address at 'start + i' readable?
            if (!isSafeToRead(ptrAddr)) continue;

            uintptr_t firstLevelPtr = *(uintptr_t*)ptrAddr;
            
            // 2. CRITICAL: Is the VALUE we found actually a safe pointer?
            if (isSafeToRead(firstLevelPtr)) {
                
                for (int j = 0; j <= range; j += 4) {
                    uintptr_t finalAddr = firstLevelPtr + j;

                    // 3. Is the final destination readable?
                    if (!isSafeToRead(finalAddr)) continue;

                    uintptr_t finalVal = *(uintptr_t*)finalAddr;
                    
                    if (finalVal == target) {
                        resultSS << "[L2] 0x" << std::hex << i << " -> 0x" << j << "\n";
                        found = true;
                        // Optional: Stop after first find to prevent lag
                        Scanner.stopRequest = true; 
                        break; 
                    }
                }
            }
            if(found) break;
        }
    }

    if (found) {
        Scanner.resultText = "Found:\n" + resultSS.str();
    } else {
        Scanner.resultText = "Not Found";
    }
    
    Scanner.isScanning = false;
}

// --- START / STOP ---
void StartScanAsync() {
    if (Scanner.isScanning) return;
    std::thread(ScanWorker).detach();
}

void StopScan() {
    if (Scanner.isScanning) Scanner.stopRequest = true;
}

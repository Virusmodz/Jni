#include <unistd.h>
#include <sys/mman.h>
#include <atomic>
#include <sstream>
#include <thread>
#include <string>

//
// Helper to get system page size (usually 4096 bytes)
size_t pageSize = sysconf(_SC_PAGESIZE);

struct ScannerState {
    uintptr_t startAddress = 0;
    uintptr_t targetAddress = 0;
    int maxRange = 1024;
    
    std::atomic<bool> isScanning{false};
    std::atomic<bool> stopRequest{false};
    std::string resultText = "Status: Ready";
} Scanner;

// --- SAFETY HELPER: REAL Memory Validation ---
// This prevents the SIGSEGV crash by checking if the page is mapped.
bool isMemoryReadable(uintptr_t addr) {
    if (addr < 0x100000) return false; 

    // We must align the address to the page size for msync to work
    void* pageAddr = (void*)(addr & ~(pageSize - 1));
    
    // msync returns -1 if the memory is not mapped (invalid)
    // We use MS_ASYNC so it doesn't actually wait for disk operations
    if (msync(pageAddr, pageSize, MS_ASYNC) == 0) {
        return true; // Memory is safe
    }
    return false; // Memory is invalid/unmapped
}

// --- HELPER: Convert Hex String to Address ---
uintptr_t HexToAddr(const char* str) {
    uintptr_t x;
    std::stringstream ss;
    ss << std::hex << str;
    ss >> x;
    return x;
}

// --- WORKER THREAD ---
void ScanWorker() {
    Scanner.isScanning = true;
    Scanner.stopRequest = false;
    Scanner.resultText = "Scanning...";
    
    uintptr_t start = Scanner.startAddress;
    uintptr_t target = Scanner.targetAddress;
    int range = Scanner.maxRange;
    
    std::stringstream resultSS;
    bool found = false;

    // Basic range check
    if (!isMemoryReadable(start)) {
         Scanner.resultText = "Error: Start Address Invalid";
         Scanner.isScanning = false;
         return;
    }

    // --- LEVEL 1: Direct Offset ---
    for (int i = 0; i <= range; i += 4) {
        if (Scanner.stopRequest) break;

        // Verify address before reading!
        if (!isMemoryReadable(start + i)) continue;

        uintptr_t val = *(uintptr_t*)(start + i);
        if (val == target) {
            resultSS << "[L1] 0x" << std::hex << i << "\n";
            found = true;
        }
    }

    // --- LEVEL 2: Pointer -> Offset ---
    if (!found) {
        for (int i = 0; i <= range; i += 4) {
            if (Scanner.stopRequest) {
                Scanner.resultText = "Stopped.";
                Scanner.isScanning = false;
                return;
            }

            if (i % 200 == 0) {
                 int pct = (i * 100) / range;
                 Scanner.resultText = "Scan: " + std::to_string(pct) + "%";
            }

            uintptr_t ptrAddr = start + i;
            
            // 1. Safe Check
            if (!isMemoryReadable(ptrAddr)) continue;

            uintptr_t firstLevelPtr = *(uintptr_t*)ptrAddr;
            
            // 2. Safe Check the POINTER inside
            if (isMemoryReadable(firstLevelPtr)) {
                
                for (int j = 0; j <= range; j += 4) {
                    uintptr_t finalAddr = firstLevelPtr + j;

                    // 3. Safe Check the FINAL address
                    if (!isMemoryReadable(finalAddr)) continue;

                    uintptr_t finalVal = *(uintptr_t*)finalAddr;
                    if (finalVal == target) {
                        resultSS << "[L2] 0x" << std::hex << i << " -> 0x" << j << "\n";
                        found = true;
                        Scanner.stopRequest = true; 
                        break; 
                    }
                }
            }
            if(found) break;
        }
    }

    if (found) {
        Scanner.resultText = "Found:\n" + resultSS.str();
    } else {
        Scanner.resultText = "Not Found.";
    }
    
    Scanner.isScanning = false;
}

// --- START FUNCTION ---
void StartScanAsync() {
    if (Scanner.isScanning) {
        return;
    }
    std::thread(ScanWorker).detach();
}

void StopScan() {
    if (Scanner.isScanning) {
        Scanner.stopRequest = true;
    }
}

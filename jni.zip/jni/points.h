




struct ScannerState {
    uintptr_t startAddress = 0;
    uintptr_t targetAddress = 0;
    int maxRange = 1024;
    
    std::atomic<bool> isScanning{false};
    std::atomic<bool> stopRequest{false};
    std::string resultText = "Status: Ready";
} Scanner;

// --- SAFETY HELPER: Check if address is valid ---
bool isValidPtr(uintptr_t addr) {
    if (addr < 0x100000) return false; // Basic check for invalid low memory
    return true;
}

// --- HELPER: Convert Hex String to Address ---
uintptr_t HexToAddr(const char* str) {
    uintptr_t x;
    std::stringstream ss;
    ss << std::hex << str;
    ss >> x;
    return x;
}

// --- WORKER THREAD: The Heavy Lifting ---
void ScanWorker() {
    Scanner.isScanning = true;
    Scanner.stopRequest = false;
    Scanner.resultText = "Scanning...";
    
    uintptr_t start = Scanner.startAddress;
    uintptr_t target = Scanner.targetAddress;
    int range = Scanner.maxRange;
    
    std::stringstream resultSS;
    bool found = false;

    // Safety Check before starting
    if (start < 0x10000 || target < 0x10000) {
        Scanner.resultText = "Error: Invalid Addr";
        Scanner.isScanning = false;
        return;
    }

    // --- LEVEL 1: Direct Offset ---
    for (int i = 0; i <= range; i += 4) {
        if (Scanner.stopRequest) break;
        if (!isValidPtr(start + i)) continue;

        uintptr_t val = *(uintptr_t*)(start + i);
        if (val == target) {
            resultSS << "[L1] 0x" << std::hex << i << "\n";
            found = true;
        }
    }

    // --- LEVEL 2: Pointer -> Offset ---
    if (!found) {
        for (int i = 0; i <= range; i += 4) {
            if (Scanner.stopRequest) {
                Scanner.resultText = "Stopped by User";
                Scanner.isScanning = false;
                return;
            }

            // Show progress every 200 steps
            if (i % 200 == 0) {
                 int pct = (i * 100) / range;
                 Scanner.resultText = "Scan: " + std::to_string(pct) + "%";
            }

            uintptr_t ptrAddr = start + i;
            if (!isValidPtr(ptrAddr)) continue;

            uintptr_t firstLevelPtr = *(uintptr_t*)ptrAddr;
            
            if (isValidPtr(firstLevelPtr)) {
                for (int j = 0; j <= range; j += 4) {
                    uintptr_t finalAddr = firstLevelPtr + j;
                    if (!isValidPtr(finalAddr)) continue;

                    uintptr_t finalVal = *(uintptr_t*)finalAddr;
                    if (finalVal == target) {
                        resultSS << "[L2] 0x" << std::hex << i << " -> 0x" << j << "\n";
                        found = true;
                        Scanner.stopRequest = true; // Stop on first find? Remove if you want all.
                        break; 
                    }
                }
            }
            if(found) break;
        }
    }

    if (found) {
        Scanner.resultText = "Found:\n" + resultSS.str();
    } else {
        Scanner.resultText = "Not Found.";
    }
    
    Scanner.isScanning = false;
}

// --- START FUNCTION ---
void StartScanAsync() {
    if (Scanner.isScanning) {
        Scanner.resultText = "Busy...";
        return;
    }
    std::thread(ScanWorker).detach();
}

void StopScan() {
    if (Scanner.isScanning) {
        Scanner.stopRequest = true;
        Scanner.resultText = "Stopping...";
    }
}

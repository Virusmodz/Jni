#pragma once
#include <unistd.h>
#include <setjmp.h>
#include <signal.h>
#include <atomic>
#include <sstream>
#include <thread>
#include <string>
#include <vector>
#include <unordered_set>
#include <iomanip> // For std::hex formatting

// ==========================================
// PART 1: SAFETY SYSTEM (CRASH PROTECTION)
// ==========================================

static jmp_buf jumpBuffer;
static struct sigaction old_sa, new_sa;
static std::atomic<bool> isSafeReadMode{false};

// Handles crashes (SIGSEGV) so the app doesn't close
void segv_handler(int sig) {
    if (isSafeReadMode) {
        longjmp(jumpBuffer, 1);
    }
    signal(sig, SIG_DFL);
    raise(sig);
}

// Tries to read memory safely. Returns true if successful.
bool safeRead(uintptr_t address, uintptr_t& outValue) {
    if (address < 0x10000 || address % 4 != 0) return false; // Basic alignment check

    sigaction(SIGSEGV, NULL, &old_sa);
    memset(&new_sa, 0, sizeof(new_sa));
    new_sa.sa_handler = segv_handler;
    new_sa.sa_flags = SA_NODEFER;
    sigaction(SIGSEGV, &new_sa, NULL);

    isSafeReadMode = true;

    if (setjmp(jumpBuffer) == 0) {
        outValue = *(uintptr_t*)address;
        isSafeReadMode = false;
        sigaction(SIGSEGV, &old_sa, NULL);
        return true;
    } else {
        isSafeReadMode = false;
        sigaction(SIGSEGV, &old_sa, NULL);
        return false;
    }
}

// ==========================================
// PART 2: GLOBAL SCANNER STATE
// ==========================================

struct ScannerState {
    // Inputs from Menu
    uintptr_t startAddress = 0;
    uintptr_t targetAddress = 0;
    int maxRange = 0x500; // This will be used as "Max Offset"
    int maxDepth = 4;     // How many levels deep to scan (default 4)

    // Status
    std::atomic<bool> isScanning{false};
    std::atomic<bool> stopRequest{false};
    std::string resultText = "Status: Ready";
} Scanner;

// Helper: Convert Hex String to Number
uintptr_t HexToAddr(const char* str) {
    uintptr_t x;
    std::stringstream ss;
    ss << std::hex << str;
    ss >> x;
    return x;
}

// ==========================================
// PART 3: NEW RECURSIVE LOGIC
// ==========================================

namespace PointerScan {

    // Helper to check if a pointer looks valid (Not null, aligned)
    inline bool IsValidPtr(uintptr_t p) {
        // Must be greater than simple null area and 4-byte aligned
        return (p > 0x100000) && ((p & 3) == 0);
    }

    // This function calls itself (Recursive) to find paths
    inline bool Walk(
        uintptr_t base,
        uintptr_t target,
        int maxDepth,
        uintptr_t maxOffset,
        int currentDepth,
        std::unordered_set<uintptr_t>& visited,
        std::vector<uintptr_t>& path
    ) {
        // Stop if user clicked Stop
        if (Scanner.stopRequest) return false;

        // Stop if we went too deep
        if (currentDepth >= maxDepth) return false;

        // Stop if we already checked this address (optimization)
        if (visited.count(base)) return false;
        visited.insert(base);

        // Scan offsets
        for (uintptr_t off = 0; off <= maxOffset; off += 4) {
            
            // USE SAFE READ HERE!
            uintptr_t nextVal = 0;
            if (!safeRead(base + off, nextVal)) continue;

            path.push_back(off);

            // Did we find the target?
            if (nextVal == target) {
                return true; 
            }

            // If the value looks like a pointer, dig deeper
            if (IsValidPtr(nextVal)) {
                if (Walk(nextVal, target, maxDepth, maxOffset, currentDepth + 1, visited, path)) {
                    return true;
                }
            }

            path.pop_back();
        }
        return false;
    }
}

// ==========================================
// PART 4: WORKER THREAD
// ==========================================

void ScanWorker() {
    Scanner.isScanning = true;
    Scanner.stopRequest = false;
    Scanner.resultText = "Scanning...";

    // Prepare variables
    std::unordered_set<uintptr_t> visited;
    std::vector<uintptr_t> path;
    
    // Start the recursive walk
    bool found = PointerScan::Walk(
        Scanner.startAddress,
        Scanner.targetAddress,
        Scanner.maxDepth,
        Scanner.maxRange, // Using maxRange from menu as Max Offset
        0,
        visited,
        path
    );

    if (found) {
        std::ostringstream ss;
        ss << "Found Path (" << path.size() << " offsets):\n\n";
        
        // Generate C++ code string
        for (size_t i = 0; i < path.size(); i++) {
            if (i == 0) {
                ss << "uintptr_t addr = *(uintptr_t*)(start + 0x" 
                   << std::hex << path[i] << ");\n";
            } else {
                ss << "addr = *(uintptr_t*)(addr + 0x" 
                   << std::hex << path[i] << ");\n";
            }
        }
        Scanner.resultText = ss.str();
    } else {
        Scanner.resultText = "Scan finished. Path not found.";
    }

    Scanner.isScanning = false;
}

// Start the thread
void StartScanAsync() {
    if (Scanner.isScanning) return;
    std::thread(ScanWorker).detach();
}

// Stop the thread
void StopScan() {
    if (Scanner.isScanning) Scanner.stopRequest = true;
}

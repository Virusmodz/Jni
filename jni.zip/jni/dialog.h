#pragma once
#include <jni.h>

static bool iShow = false;

static void ShowDialog(JNIEnv* env, jobject activity) {
    jclass builderCls = env->FindClass("android/app/AlertDialog$Builder");
    jmethodID ctor = env->GetMethodID(builderCls, "<init>","(Landroid/content/Context;)V");
    jobject builder = env->NewObject(builderCls, ctor, activity);
    jmethodID setTitle = env->GetMethodID(builderCls, "setTitle","(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;");
    jmethodID setMsg = env->GetMethodID(builderCls, "setMessage","(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;");
    jmethodID setBtn = env->GetMethodID(builderCls, "setPositiveButton","(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)""Landroid/app/AlertDialog$Builder;");
    jmethodID setCancelable = env->GetMethodID(builderCls, "setCancelable","(Z)Landroid/app/AlertDialog$Builder;");
    jmethodID show = env->GetMethodID(builderCls, "show","()Landroid/app/AlertDialog;");
    env->CallObjectMethod(builder, setTitle, env->NewStringUTF("ImJava C++"));
    env->CallObjectMethod(builder, setMsg, env->NewStringUTF("Hi Bro i'm Full C++ xJava : imJava"));
    env->CallObjectMethod(builder, setBtn, env->NewStringUTF("OK"), 0);
    env->CallObjectMethod(builder, setCancelable, JNI_FALSE);
    jobject dialog = env->CallObjectMethod(builder, show);
    jclass dialogCls = env->FindClass("android/app/AlertDialog");
    jmethodID outside = env->GetMethodID(dialogCls, "setCanceledOnTouchOutside","(Z)V");
    env->CallVoidMethod(dialog, outside, JNI_FALSE);
}

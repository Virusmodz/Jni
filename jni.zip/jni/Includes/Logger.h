#pragma once

#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
#include <vector>
#include <mutex>
#include <thread>
#include <queue>
#include <atomic>
#include <condition_variable>
#include <sys/stat.h>
#include <unistd.h>
#include <android/log.h>
#include <exception>
#include <csignal>
#include <cstring>
#include <cstdarg>
#include <iomanip>
#include <cstdint>
#include <cstdlib>
#include <jni.h>

#include <unwind.h>
#include <dlfcn.h>
#include <cxxabi.h>

#define LOG_TAG "ModMenu_Core"

// -------------------- Configuration --------------------
static const size_t MAX_LOG_QUEUE_SIZE = 1000;
static const size_t MAX_DEBUG_TEXT_SIZE = 12000;

static bool enableDebugLogs = true;
static int logLevelFilter = 0; // 0 = VERBOSE

enum LogLevel {
    LOG_VERBOSE = 0,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL
};

static const char* levelTags[] = { "V", "D", "I", "W", "E", "F" };

// -------------------- Shared Debug Text for BoxView --------------------
static std::mutex gDebugMutex;
static std::string gDebugText;

static void AppendDebugText(const std::string& line) {
    std::lock_guard<std::mutex> lock(gDebugMutex);
    gDebugText += line + "\n";

    if (gDebugText.size() > MAX_DEBUG_TEXT_SIZE) {
        gDebugText.erase(0, gDebugText.size() - MAX_DEBUG_TEXT_SIZE);
    }
}

static std::string GetDebugTextSnapshot() {
    std::lock_guard<std::mutex> lock(gDebugMutex);
    return gDebugText.empty() ? std::string("No debug logs yet") : gDebugText;
}

// JNI bridge for BoxView.java

// -------------------- Helper Utilities --------------------
namespace Utils {

    inline std::string GetPackageName() {
        char appId[256] = {0};
        FILE* fp = fopen("/proc/self/cmdline", "r");
        if (fp) {
            fread(appId, sizeof(char), sizeof(appId) - 1, fp);
            fclose(fp);
        }

        std::string id(appId);
        size_t last = id.find_last_not_of(" \n\r\t");
        if (last != std::string::npos) {
            id = id.substr(0, last + 1);
        }
        return id.empty() ? "unknown_package" : id;
    }

    inline std::string GetTimestamp(const char* format) {
        std::time_t now = std::time(nullptr);
        std::tm tm_buf{};
        localtime_r(&now, &tm_buf);

        char buffer[64];
        std::strftime(buffer, sizeof(buffer), format, &tm_buf);
        return std::string(buffer);
    }

    inline void EnsureDirExists(const std::string& path) {
        struct stat info;
        if (stat(path.c_str(), &info) == 0) return;

        std::string currentPath;
        std::stringstream ss(path);
        std::string segment;

        while (std::getline(ss, segment, '/')) {
            if (segment.empty()) continue;
            currentPath += "/" + segment;
            if (stat(currentPath.c_str(), &info) != 0) {
                mkdir(currentPath.c_str(), 0771);
            }
        }
    }
}

// -------------------- Async Log Worker --------------------
class LogWorker {
public:
    static LogWorker& Instance() {
        static LogWorker instance;
        return instance;
    }

    void Initialize() {
        if (running) return;

        std::string basePath = "/storage/emulated/0/Android/data/" +
                               Utils::GetPackageName() + "/files/Logs/";
        Utils::EnsureDirExists(basePath);

        logFilePath = basePath + "crash_cpp_log_" +
                      Utils::GetTimestamp("%Y%m%d_%H%M%S") + ".txt";

        running = true;
        workerThread = std::thread(&LogWorker::ProcessQueue, this);
    }

    void Push(const std::string& message) {
        if (!running) return;

        {
            std::lock_guard<std::mutex> lock(queueMutex);
            if (msgQueue.size() >= MAX_LOG_QUEUE_SIZE) {
                msgQueue.pop();
            }
            msgQueue.push(message);
        }
        cv.notify_one();
    }

    void FlushSynchronous(const std::string& message) {
        if (logFilePath.empty()) return;

        std::ofstream file(logFilePath, std::ios::app);
        if (file.is_open()) {
            file << message << std::endl;
        }
    }

    ~LogWorker() {
        running = false;
        cv.notify_all();
        if (workerThread.joinable()) {
            workerThread.join();
        }
    }

private:
    LogWorker() : running(false) {}

    void ProcessQueue() {
        while (running) {
            std::unique_lock<std::mutex> lock(queueMutex);
            cv.wait(lock, [this] { return !msgQueue.empty() || !running; });

            while (!msgQueue.empty()) {
                std::string msg = msgQueue.front();
                msgQueue.pop();
                lock.unlock();

                std::ofstream file(logFilePath, std::ios::app);
                if (file.is_open()) {
                    file << msg << std::endl;
                }

                lock.lock();
            }
        }
    }

    std::string logFilePath;
    std::atomic<bool> running;
    std::thread workerThread;
    std::queue<std::string> msgQueue;
    std::mutex queueMutex;
    std::condition_variable cv;
};

// -------------------- Stack Trace Logic --------------------
struct BacktraceState {
    void** current;
    void** end;
};

inline _Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg) {
    BacktraceState* state = static_cast<BacktraceState*>(arg);
    uintptr_t pc = _Unwind_GetIP(context);

    if (pc) {
        if (state->current < state->end) {
            *state->current++ = reinterpret_cast<void*>(pc);
        } else {
            return _URC_END_OF_STACK;
        }
    }
    return _URC_NO_REASON;
}

inline void DumpStackTrace() {
    const size_t MAX_FRAMES = 32;
    void* buffer[MAX_FRAMES];

    BacktraceState state = { buffer, buffer + MAX_FRAMES };
    _Unwind_Backtrace(unwindCallback, &state);
    size_t count = static_cast<size_t>(state.current - buffer);

    std::stringstream ss;
    ss << "\n--- STACK TRACE ---\n";

    for (size_t i = 0; i < count; ++i) {
        const void* addr = buffer[i];
        const char* symbol = "(unknown)";
        const char* fname = "(unknown)";

        Dl_info info;
        if (dladdr(addr, &info) && info.dli_sname) {
            int status = 0;
            char* demangled = abi::__cxa_demangle(info.dli_sname, nullptr, nullptr, &status);

            symbol = (status == 0 && demangled) ? demangled : info.dli_sname;
            fname = info.dli_fname ? info.dli_fname : fname;

            uintptr_t offset = (uintptr_t)addr - (uintptr_t)info.dli_fbase;

            ss << "#" << std::setw(2) << i << " pc "
               << std::hex << offset << "  " << fname
               << " (" << symbol << ")\n";

            if (demangled) {
                std::free(demangled);
            }
        } else {
            ss << "#" << std::setw(2) << i << " pc " << addr << "\n";
        }
    }

    ss << "--- END TRACE ---\n";

    std::string trace = ss.str();
    AppendDebugText(trace);
    LogWorker::Instance().FlushSynchronous(trace);
    __android_log_print(ANDROID_LOG_FATAL, LOG_TAG, "%s", trace.c_str());
}

// -------------------- Main Logging Function --------------------
inline void LogInternal(LogLevel level, const char* tag, const char* fmt, ...) {
    if (!enableDebugLogs || level < logLevelFilter) return;

    char buffer[2048];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    int androidLevel = ANDROID_LOG_DEFAULT;
    switch (level) {
        case LOG_VERBOSE: androidLevel = ANDROID_LOG_VERBOSE; break;
        case LOG_DEBUG:   androidLevel = ANDROID_LOG_DEBUG;   break;
        case LOG_INFO:    androidLevel = ANDROID_LOG_INFO;    break;
        case LOG_WARN:    androidLevel = ANDROID_LOG_WARN;    break;
        case LOG_ERROR:   androidLevel = ANDROID_LOG_ERROR;   break;
        case LOG_FATAL:   androidLevel = ANDROID_LOG_FATAL;   break;
    }

    __android_log_print(androidLevel, tag, "%s", buffer);

    std::string timestamp = Utils::GetTimestamp("%Y-%m-%d %H:%M:%S");
    std::stringstream ss;
    ss << "[" << timestamp << "] [" << levelTags[level] << "/" << tag << "] " << buffer;

    std::string line = ss.str();
    AppendDebugText(line);

    if (level == LOG_FATAL) {
        LogWorker::Instance().FlushSynchronous(line);
    } else {
        LogWorker::Instance().Push(line);
    }
}

// -------------------- Crash Handlers --------------------
inline void CrashHandler(int sig) {
    const char* sigName = "UNKNOWN";
    switch (sig) {
        case SIGSEGV: sigName = "SIGSEGV"; break;
        case SIGABRT: sigName = "SIGABRT"; break;
        case SIGBUS:  sigName = "SIGBUS";  break;
        case SIGFPE:  sigName = "SIGFPE";  break;
        case SIGILL:  sigName = "SIGILL";  break;
    }

    LogInternal(LOG_FATAL, "CRASH", "Caught signal %d (%s)", sig, sigName);
    DumpStackTrace();

    signal(sig, SIG_DFL);
    raise(sig);
}

inline void InitializeLogger() {
    LogWorker::Instance().Initialize();

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = CrashHandler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;

    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
    sigaction(SIGBUS,  &sa, nullptr);
    sigaction(SIGFPE,  &sa, nullptr);
    sigaction(SIGILL,  &sa, nullptr);
}

// -------------------- Macros --------------------
#define LOGD(...) LogInternal(LOG_DEBUG, "ModMenu", __VA_ARGS__)
#define LOGE(...) LogInternal(LOG_ERROR, "ModMenu", __VA_ARGS__)
#define LOGI(...) LogInternal(LOG_INFO,  "ModMenu", __VA_ARGS__)
#define LOGW(...) LogInternal(LOG_WARN,  "ModMenu", __VA_ARGS__)
#define LOGV(...) LogInternal(LOG_VERBOSE, "ModMenu", __VA_ARGS__)
#define LOG_INIT() InitializeLogger()
#pragma once

#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
#include <vector>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h> // For open/write
#include <android/log.h>
#include <exception>
#include <csignal>
#include <cstring>
#include <cstdarg>
#include <iomanip>

// Stack Trace Includes
#include <unwind.h>
#include <dlfcn.h>
#include <cxxabi.h>

#define LOG_TAG "ModMenu_Core"

// --- Configuration ---
static bool enableDebugLogs = true;
static int logLevelFilter = 0; // 0 = VERBOSE

enum LogLevel {
    LOG_VERBOSE = 0,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL
};

static const char* levelTags[] = { "V", "D", "I", "W", "E", "F" };

// Global file descriptor for low-level writing
static int g_logFd = -1; 

namespace Utils {
    inline std::string GetPackageName() {
        char appId[256] = {0};
        FILE* fp = fopen("/proc/self/cmdline", "r");
        if (fp) {
            fread(appId, sizeof(char), sizeof(appId) - 1, fp);
            fclose(fp);
        }
        std::string id(appId);
        // Trim whitespace
        size_t last = id.find_last_not_of(" \n\r\t");
        if (last != std::string::npos) id = id.substr(0, last + 1);
        
        // FIX: Remove colons (:) which are illegal in filenames but common in process names
        for (char & c : id) {
            if (c == ':') c = '_';
        }

        return id.empty() ? "unknown_package" : id;
    }

    inline std::string GetTimestamp(const char* format) {
        std::time_t now = std::time(nullptr);
        std::tm tm_buf{};
        localtime_r(&now, &tm_buf);
        char buffer[64];
        std::strftime(buffer, sizeof(buffer), format, &tm_buf);
        return {buffer};
    }

    inline void EnsureDirExists(const std::string& path) {
        struct stat info;
        if (stat(path.c_str(), &info) != 0) {
            std::string currentPath;
            std::stringstream ss(path);
            std::string segment;
            while (std::getline(ss, segment, '/')) {
                if (segment.empty()) continue;
                currentPath += "/" + segment;
                if (stat(currentPath.c_str(), &info) != 0) {
                    mkdir(currentPath.c_str(), 0777);
                }
            }
        }
    }
}

// --- Stack Trace Logic ---
struct BacktraceState {
    void** current;
    void** end;
};

inline _Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg) {
    BacktraceState* state = static_cast<BacktraceState*>(arg);
    uintptr_t pc = _Unwind_GetIP(context);
    if (pc) {
        if (state->current < state->end) {
            *state->current++ = reinterpret_cast<void*>(pc);
        } else {
            return _URC_END_OF_STACK;
        }
    }
    return _URC_NO_REASON;
}

// Helper to write raw strings to file descriptor safely
inline void SafeWrite(int fd, const char* str) {
    if (fd >= 0 && str) {
        write(fd, str, strlen(str));
    }
}

inline void DumpStackTrace() {
    const size_t MAX_FRAMES = 32;
    void* buffer[MAX_FRAMES];
    BacktraceState state = {buffer, buffer + MAX_FRAMES};
    _Unwind_Backtrace(unwindCallback, &state);
    size_t count = state.current - buffer;

    // Use a fixed buffer to avoid malloc during crash
    char crashBuf[512]; 

    SafeWrite(g_logFd, "\n--- STACK TRACE ---\n");
    __android_log_print(ANDROID_LOG_FATAL, LOG_TAG, "--- STACK TRACE ---");

    for (size_t i = 0; i < count; ++i) {
        const void* addr = buffer[i];
        const char* symbol = "(unknown)";
        const char* fname = "(unknown)";
        
        Dl_info info;
        if (dladdr(addr, &info) && info.dli_sname) {
            int status;
            char* demangled = abi::__cxa_demangle(info.dli_sname, nullptr, nullptr, &status);
            symbol = (status == 0) ? demangled : info.dli_sname;
            fname = info.dli_fname ? info.dli_fname : fname;

            uintptr_t offset = (uintptr_t)addr - (uintptr_t)info.dli_fbase;
            
            snprintf(crashBuf, sizeof(crashBuf), "#%02zu pc %p %s (%s)\n", i, (void*)offset, fname, symbol);

            if (status == 0) free(demangled);
        } else {
            snprintf(crashBuf, sizeof(crashBuf), "#%02zu pc %p\n", i, addr);
        }
        
        SafeWrite(g_logFd, crashBuf);
        __android_log_print(ANDROID_LOG_FATAL, LOG_TAG, "%s", crashBuf);
    }
    SafeWrite(g_logFd, "--- END TRACE ---\n");
    
    // Force commit to disk
    if (g_logFd >= 0) fsync(g_logFd); 
}

// --- Main Logging Function ---
inline void LogInternal(LogLevel level, const char* tag, const char* fmt, ...) {
    if (!enableDebugLogs || level < logLevelFilter) return;

    // 1. Format Message
    char buffer[4096];
    va_list args;
    va_start(args, fmt);
    vsnprintf(buffer, sizeof(buffer), fmt, args);
    va_end(args);

    // 2. Android Logcat
    int androidLevel = ANDROID_LOG_DEFAULT;
    switch(level) {
        case LOG_VERBOSE: androidLevel = ANDROID_LOG_VERBOSE; break;
        case LOG_DEBUG:   androidLevel = ANDROID_LOG_DEBUG; break;
        case LOG_INFO:    androidLevel = ANDROID_LOG_INFO; break;
        case LOG_WARN:    androidLevel = ANDROID_LOG_WARN; break;
        case LOG_ERROR:   androidLevel = ANDROID_LOG_ERROR; break;
        case LOG_FATAL:   androidLevel = ANDROID_LOG_FATAL; break;
    }
    __android_log_print(androidLevel, tag, "%s", buffer);

    // 3. File Logging (Direct Write)
    if (g_logFd >= 0) {
        std::string timestamp = Utils::GetTimestamp("%Y-%m-%d %H:%M:%S");
        // Construct line: [Time] [Level/Tag] Message\n
        // We use dprintf or write. dprintf is easier.
        dprintf(g_logFd, "[%s] [%s/%s] %s\n", timestamp.c_str(), levelTags[level], tag, buffer);
        
        // CRITICAL: Flush immediately. 
        // This makes it slower, but guarantees logs exist if a crash happens 1ms later.
        // If performance is an issue, comment out fsync, but keep it for debugging.
        // fsync(g_logFd); 
    }
}

// --- Crash Handlers ---
inline void CrashHandler(int sig) {
    const char* sigName = "UNKNOWN";
    switch(sig) {
        case SIGSEGV: sigName = "SIGSEGV"; break;
        case SIGABRT: sigName = "SIGABRT"; break;
        case SIGBUS:  sigName = "SIGBUS"; break;
        case SIGFPE:  sigName = "SIGFPE"; break;
        case SIGILL:  sigName = "SIGILL"; break;
    }

    // Write directly using raw IO (Async-Signal-Safe)
    if (g_logFd >= 0) {
        char buf[128];
        snprintf(buf, sizeof(buf), "\n\n!!! CRASH CAUGHT: SIGNAL %d (%s) !!!\n", sig, sigName);
        write(g_logFd, buf, strlen(buf));
    }

    __android_log_print(ANDROID_LOG_FATAL, LOG_TAG, "!!! CRASH CAUGHT: SIGNAL %d (%s) !!!", sig, sigName);
    
    DumpStackTrace();
    
    // Restore default handler and re-raise
    signal(sig, SIG_DFL);
    raise(sig);
}

inline void InitializeLogger() {
    // Setup Log Path
    std::string pkgName = Utils::GetPackageName();
    std::string basePath = "/data/data/" + pkgName + "/files/Logs/";
    
    // Attempt to create directory
    Utils::EnsureDirExists(basePath);

    std::string filePath = basePath + "crash_log_" + Utils::GetTimestamp("%Y%m%d_%H%M%S") + ".txt";
    
    // Open using Low-Level File Descriptor
    // O_SYNC ensures data is physically written to disk immediately
    g_logFd = open(filePath.c_str(), O_WRONLY | O_CREAT | O_APPEND | O_CLOEXEC, 0666);
    
    if (g_logFd < 0) {
        __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, "FAILED TO OPEN LOG FILE: %s (errno: %d)", filePath.c_str(), errno);
    } else {
        __android_log_print(ANDROID_LOG_INFO, LOG_TAG, "Logger Initialized. Writing to: %s", filePath.c_str());
        dprintf(g_logFd, "--- Logger Initialized ---\nPackage: %s\n", pkgName.c_str());
    }

    // Register Handlers
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = CrashHandler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART;

    sigaction(SIGSEGV, &sa, nullptr);
    sigaction(SIGABRT, &sa, nullptr);
    sigaction(SIGBUS, &sa, nullptr);
    sigaction(SIGFPE, &sa, nullptr);
    sigaction(SIGILL, &sa, nullptr);
}

// --- Macros ---
#define LOGD(...) LogInternal(LOG_DEBUG, "ModMenu", __VA_ARGS__)
#define LOGE(...) LogInternal(LOG_ERROR, "ModMenu", __VA_ARGS__)
#define LOGI(...) LogInternal(LOG_INFO,  "ModMenu", __VA_ARGS__)
#define LOGW(...) LogInternal(LOG_WARN,  "ModMenu", __VA_ARGS__)
#define LOG_INIT() InitializeLogger()
#pragma once

#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cstdarg>
#include <sys/stat.h>
#include <unistd.h>
#include <android/log.h> 
#include <exception>     
#include <csignal>       
#include <cstring>       


#define LOG_TAG "ModMenu_Crash"


static std::string currentSessionLogFileName; 



static const size_t LOG_ROTATE_SIZE = 300 * 1024 * 1024; 
static bool useUTC = false;
static int logLevelFilter = 0;
static bool enableDebugLogs = true;

enum LogLevel {
    LOG_VERBOSE = 0,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL
};

static const char* levelTags[] = { "V", "D", "I", "W", "E", "F" }; 

inline bool getDebugMode() { return enableDebugLogs; }
inline void SetDebugMode(bool enabled) { enableDebugLogs = enabled; }

inline void createDirectoryIfNotExists(const std::string& path) {
    std::istringstream stream(path);
    std::string partialPath;
    std::string segment;
    while (std::getline(stream, segment, '/')) {
        if (segment.empty()) continue;
        partialPath += "/" + segment;
        struct stat info;
        if (stat(partialPath.c_str(), &info) != 0) {
            mkdir(partialPath.c_str(), 0771);
        }
    }
}

inline std::string getPackageName() {
    char appId[256] = {0};
    FILE* fp = fopen("/proc/self/cmdline", "r");
    if (fp) {
        fread(appId, sizeof(char), sizeof(appId) - 1, fp);
        fclose(fp);
    }
    std::string id(appId);
    size_t last = id.find_last_not_of(" \n\r\t");
    if (last != std::string::npos) id = id.substr(0, last + 1);
    return id.empty() ? "unknown.package" : id;
}

inline std::string getLogDirectory() {
    std::string basePath;
    char* env = getenv("EXTERNAL_STORAGE");
    basePath = (env != nullptr) ? std::string(env) : "/storage/emulated/0";
    std::string path = basePath + "/Android/data/" + getPackageName() + "/files/Logger/";
    createDirectoryIfNotExists(path);
    return path;
}




inline void saveLogAdvanced(LogLevel level, const char* tag, const char* format, ...) {
    if (!getDebugMode() || level < logLevelFilter) return;

   
    if (currentSessionLogFileName.empty()) {
        std::time_t now = std::time(nullptr);
        std::tm* timeinfo = useUTC ? std::gmtime(&now) : std::localtime(&now);
        char timeBuffer[80];
        
      
        std::strftime(timeBuffer, sizeof(timeBuffer), "%Y_%m_%d-%H_%M_%S", timeinfo);
        
       
        currentSessionLogFileName = "mod_menu_log_" + std::string(timeBuffer) + ".txt";
    }

   
    char msgBuffer[2048]; 
    va_list args;
    va_start(args, format);
    vsnprintf(msgBuffer, sizeof(msgBuffer), format, args);
    va_end(args);

    
    int androidLevel;
    switch(level) {
        case LOG_VERBOSE: androidLevel = ANDROID_LOG_VERBOSE; break;
        case LOG_DEBUG:   androidLevel = ANDROID_LOG_DEBUG; break;
        case LOG_INFO:    androidLevel = ANDROID_LOG_INFO; break;
        case LOG_WARN:    androidLevel = ANDROID_LOG_WARN; break;
        case LOG_ERROR:   androidLevel = ANDROID_LOG_ERROR; break;
        case LOG_FATAL:   androidLevel = ANDROID_LOG_FATAL; break;
        default:          androidLevel = ANDROID_LOG_DEFAULT; break;
    }
    __android_log_print(androidLevel, (tag ? tag : LOG_TAG), "%s", msgBuffer);

    
    std::string filePath = getLogDirectory() + currentSessionLogFileName; 

   
    std::time_t now = std::time(nullptr);
    std::tm* timeinfo = useUTC ? std::gmtime(&now) : std::localtime(&now);
    char timeBuffer[80];
    std::strftime(timeBuffer, sizeof(timeBuffer), "%Y-%m-%d %H:%M:%S", timeinfo);

    std::ofstream file(filePath, std::ios::app);
    if (file.is_open()) {
        file << "[" << timeBuffer << "] [" << (tag ? tag : "App") << "-" << levelTags[level] << "] " << msgBuffer << "\n";
        file.close();
    }
}



inline void raw_crash_dump(const char* msg) {
    __android_log_print(ANDROID_LOG_FATAL, "CRASH_HANDLER", "%s", msg);
}

inline void crashSignalHandler(int signal) {
   
    raw_crash_dump("!!! CRASH SIGNAL RECEIVED !!!");
    
    
    saveLogAdvanced(LOG_FATAL, "CRASH", "Signal detected: %d. Possible cause: Memory violation or Null pointer.", signal);
    
    exit(signal);
}


inline void terminateHandler() {
    raw_crash_dump("!!! UNCAUGHT C++ EXCEPTION DETECTED !!!");
    
    std::exception_ptr exptr = std::current_exception();
    if (exptr) {
        try {
            std::rethrow_exception(exptr);
        } catch (const std::exception& e) {
            saveLogAdvanced(LOG_FATAL, "CRASH", "Uncaught Exception: %s", e.what());
        } catch (...) {
            saveLogAdvanced(LOG_FATAL, "CRASH", "Unknown C++ Exception occurred.");
        }
    } else {
        saveLogAdvanced(LOG_FATAL, "CRASH", "Terminate called without active exception (likely pure virtual call or std::abort).");
    }
    
    
    abort();
}

inline void initCrashHandler() {
    
    signal(SIGSEGV, crashSignalHandler); // Segmentation Fault
    signal(SIGABRT, crashSignalHandler); // Abort
    signal(SIGFPE,  crashSignalHandler); // Floating Point Exception
    signal(SIGILL,  crashSignalHandler); // Illegal Instruction
    signal(SIGBUS,  crashSignalHandler); // Bus Error

    
    std::set_terminate(terminateHandler);
}

// Macros
#define LOGV_IMPL(tag, ...) saveLogAdvanced(LOG_VERBOSE, tag, ##__VA_ARGS__)
#define LOGD_IMPL(tag, ...) saveLogAdvanced(LOG_DEBUG,   tag, ##__VA_ARGS__)
#define LOGI_IMPL(tag, ...) saveLogAdvanced(LOG_INFO,    tag, ##__VA_ARGS__)
#define LOGW_IMPL(tag, ...) saveLogAdvanced(LOG_WARN,    tag, ##__VA_ARGS__)
#define LOGE_IMPL(tag, ...) saveLogAdvanced(LOG_ERROR,   tag, ##__VA_ARGS__)

#define LOGV(...)    LOGV_IMPL("Log", ##__VA_ARGS__)
#define LOGD(...)    LOGD_IMPL("Log", ##__VA_ARGS__)
#define LOGI(...)    LOGI_IMPL("Log", ##__VA_ARGS__)
#define LOGW(...)    LOGW_IMPL("Log", ##__VA_ARGS__)
#define LOGE(...)    LOGE_IMPL("Log", ##__VA_ARGS__)

#define SLOGV(...)   LOGV_IMPL("SLog", ##__VA_ARGS__)
#define SLOGD(...)   SLOGD_IMPL("SLog", ##__VA_ARGS__)
#define SLOGI(...)   SLOGI_IMPL("SLog", ##__VA_ARGS__)
#define SLOGW(...)   SLOGW_IMPL("SLog", ##__VA_ARGS__)
#define SLOGE(...)   SLOGE_IMPL("SLog", ##__VA_ARGS__)

#define LOGV0(...)   LOGV_IMPL("App", ##__VA_ARGS__)
#define LOGD0(...)   LOGD_IMPL("App", ##__VA_ARGS__)
#define LOGI0(...)   LOGI_IMPL("App", ##__VA_ARGS__)
#define LOGW0(...)   LOGW_IMPL("App", ##__VA_ARGS__)
#define LOGE0(...)   LOGE_IMPL("App", ##__VA_ARGS__)

#define INIT_LOGGER() initCrashHandler()

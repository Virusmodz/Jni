#pragma once

#include <string>
#include <fstream>
#include <sstream>
#include <ctime>
#include <cstdarg>
#include <sys/stat.h>
#include <unistd.h>
#include <android/log.h> 
#include <exception>     
#include <csignal>       
#include <cstring>       
#include <unwind.h> // Added for Stack Trace
#include <dlfcn.h>  // Added for Symbol Names
#include <vector>

#define LOG_TAG "ModMenu_Crash"

static std::string currentSessionLogFileName; 

static const size_t LOG_ROTATE_SIZE = 300 * 1024 * 1024; 
static bool useUTC = false;
static int logLevelFilter = 0;
static bool enableDebugLogs = true;

enum LogLevel {
    LOG_VERBOSE = 0,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARN,
    LOG_ERROR,
    LOG_FATAL
};

static const char* levelTags[] = { "V", "D", "I", "W", "E", "F" }; 

inline bool getDebugMode() { return enableDebugLogs; }
inline void SetDebugMode(bool enabled) { enableDebugLogs = enabled; }

// --- Directory Helper ---
inline void createDirectoryIfNotExists(const std::string& path) {
    std::istringstream stream(path);
    std::string partialPath;
    std::string segment;
    while (std::getline(stream, segment, '/')) {
        if (segment.empty()) continue;
        partialPath += "/" + segment;
        struct stat info;
        if (stat(partialPath.c_str(), &info) != 0) {
            mkdir(partialPath.c_str(), 0771);
        }
    }
}

inline std::string getPackageName() {
    char appId[256] = {0};
    FILE* fp = fopen("/proc/self/cmdline", "r");
    if (fp) {
        fread(appId, sizeof(char), sizeof(appId) - 1, fp);
        fclose(fp);
    }
    std::string id(appId);
    size_t last = id.find_last_not_of(" \n\r\t");
    if (last != std::string::npos) id = id.substr(0, last + 1);
    return id.empty() ? "unknown.package" : id;
}

inline std::string getLogDirectory() {
    std::string basePath;
    char* env = getenv("EXTERNAL_STORAGE");
    basePath = (env != nullptr) ? std::string(env) : "/storage/emulated/0";
    std::string path = basePath + "/Android/data/" + getPackageName() + "/files/Logger/";
    createDirectoryIfNotExists(path);
    return path;
}

// --- Main Logging Function ---
inline void saveLogAdvanced(LogLevel level, const char* tag, const char* format, ...) {
    if (!getDebugMode() || level < logLevelFilter) return;

    if (currentSessionLogFileName.empty()) {
        std::time_t now = std::time(nullptr);
        std::tm* timeinfo = useUTC ? std::gmtime(&now) : std::localtime(&now);
        char timeBuffer[80];
        std::strftime(timeBuffer, sizeof(timeBuffer), "%Y_%m_%d-%H_%M_%S", timeinfo);
        currentSessionLogFileName = "mod_menu_log_" + std::string(timeBuffer) + ".txt";
    }

    char msgBuffer[2048]; 
    va_list args;
    va_start(args, format);
    vsnprintf(msgBuffer, sizeof(msgBuffer), format, args);
    va_end(args);

    int androidLevel;
    switch(level) {
        case LOG_VERBOSE: androidLevel = ANDROID_LOG_VERBOSE; break;
        case LOG_DEBUG:   androidLevel = ANDROID_LOG_DEBUG; break;
        case LOG_INFO:    androidLevel = ANDROID_LOG_INFO; break;
        case LOG_WARN:    androidLevel = ANDROID_LOG_WARN; break;
        case LOG_ERROR:   androidLevel = ANDROID_LOG_ERROR; break;
        case LOG_FATAL:   androidLevel = ANDROID_LOG_FATAL; break;
        default:          androidLevel = ANDROID_LOG_DEFAULT; break;
    }
    __android_log_print(androidLevel, (tag ? tag : LOG_TAG), "%s", msgBuffer);

    std::string filePath = getLogDirectory() + currentSessionLogFileName; 

    std::time_t now = std::time(nullptr);
    std::tm* timeinfo = useUTC ? std::gmtime(&now) : std::localtime(&now);
    char timeBuffer[80];
    std::strftime(timeBuffer, sizeof(timeBuffer), "%Y-%m-%d %H:%M:%S", timeinfo);

    std::ofstream file(filePath, std::ios::app);
    if (file.is_open()) {
        file << "[" << timeBuffer << "] [" << (tag ? tag : "App") << "-" << levelTags[level] << "] " << msgBuffer << "\n";
        file.close();
    }
}

// --- STACK TRACE LOGIC ---
struct BacktraceState {
    void** current;
    void** end;
};

static _Unwind_Reason_Code unwindCallback(struct _Unwind_Context* context, void* arg) {
    BacktraceState* state = static_cast<BacktraceState*>(arg);
    uintptr_t pc = _Unwind_GetIP(context);
    if (pc) {
        if (state->current == state->end) return _URC_END_OF_STACK;
        else *state->current++ = reinterpret_cast<void*>(pc);
    }
    return _URC_NO_REASON;
}

inline std::string getStackTrace() {
    const size_t max_frames = 30;
    void* buffer[max_frames];
    BacktraceState state = {buffer, buffer + max_frames};
    _Unwind_Backtrace(unwindCallback, &state); // Capture stack

    size_t count = state.current - buffer;
    std::ostringstream oss;
    oss << "\n--- STACK TRACE ---\n";
    for (size_t i = 0; i < count; ++i) {
        Dl_info info;
        if (dladdr(buffer[i], &info) && info.dli_sname) { // Get function name
            oss << "#" << i << " " << info.dli_fname << " -> " << info.dli_sname << " + " 
                << (size_t)buffer[i] - (size_t)info.dli_saddr << "\n";
        } else {
            oss << "#" << i << " unknown at " << buffer[i] << "\n";
        }
    }
    return oss.str();
}

// --- UPDATED CRASH HANDLER ---
inline void raw_crash_dump(const char* msg) {
    __android_log_print(ANDROID_LOG_FATAL, "CRASH_HANDLER", "%s", msg);
}

inline void detailedCrashHandler(int sig, siginfo_t *info, void *unused) {
    std::string trace = getStackTrace();
    char crashMsg[2048];
    
    snprintf(crashMsg, sizeof(crashMsg), 
        "!!! CRASH DETECTED !!!\nSignal: %d\nFault Address: %p\n%s", 
        sig, info->si_addr, trace.c_str());

    raw_crash_dump(crashMsg);
    saveLogAdvanced(LOG_FATAL, "CRASH", "%s", crashMsg);
    
    _exit(sig);
}

inline void terminateHandler() {
    raw_crash_dump("!!! UNCAUGHT C++ EXCEPTION !!!");
    std::string trace = getStackTrace();
    saveLogAdvanced(LOG_FATAL, "CRASH", "Exception trace: %s", trace.c_str());
    abort();
}

inline void initCrashHandler() {
    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_sigaction = detailedCrashHandler;
    sa.sa_flags = SA_SIGINFO; // Use extended info

    sigaction(SIGSEGV, &sa, NULL);
    sigaction(SIGABRT, &sa, NULL);
    sigaction(SIGFPE,  &sa, NULL);
    sigaction(SIGILL,  &sa, NULL);
    sigaction(SIGBUS,  &sa, NULL);

    std::set_terminate(terminateHandler);
}

// Macros
#define LOGV_IMPL(tag, ...) saveLogAdvanced(LOG_VERBOSE, tag, ##__VA_ARGS__)
#define LOGD_IMPL(tag, ...) saveLogAdvanced(LOG_DEBUG,   tag, ##__VA_ARGS__)
#define LOGI_IMPL(tag, ...) saveLogAdvanced(LOG_INFO,    tag, ##__VA_ARGS__)
#define LOGW_IMPL(tag, ...) saveLogAdvanced(LOG_WARN,    tag, ##__VA_ARGS__)
#define LOGE_IMPL(tag, ...) saveLogAdvanced(LOG_ERROR,   tag, ##__VA_ARGS__)

#define LOGV(...)    LOGV_IMPL("Log", ##__VA_ARGS__)
#define LOGD(...)    LOGD_IMPL("Log", ##__VA_ARGS__)
#define LOGI(...)    LOGI_IMPL("Log", ##__VA_ARGS__)
#define LOGW(...)    LOGW_IMPL("Log", ##__VA_ARGS__)
#define LOGE(...)    LOGE_IMPL("Log", ##__VA_ARGS__)

#define INIT_LOGGER() initCrashHandler()
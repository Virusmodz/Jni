#pragma once
#include <cstdint>
#include <cstddef>

namespace virus {

// ---------- tiny helpers ----------

[[nodiscard]] constexpr uint8_t rotl8(uint8_t x, unsigned r) noexcept {
    return static_cast<uint8_t>((x << (r & 7)) | (x >> ((8 - r) & 7)));
}

// Improved RNG for stronger seeds
[[nodiscard]] constexpr uint32_t seed32(uint32_t a, uint32_t b, uint32_t c) noexcept {
    uint32_t s = a ^ (b * 0x9E3779B9u) ^ (c * 0x85EBCA6Bu);
    s ^= s >> 16; s *= 0x7FEB352Du; s ^= s >> 15; s *= 0x846CA68Bu; s ^= s >> 16;
    return s ? s : 0xA5A5A5A5u;
}

[[nodiscard]] constexpr uint8_t ks(uint32_t S, size_t i) noexcept {
    uint32_t x = S ^ static_cast<uint32_t>(i * 1315423911u);
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    uint8_t b = static_cast<uint8_t>(x ^ (x >> 8) ^ (x >> 16) ^ (x >> 24));
    return rotl8(static_cast<uint8_t>(b ^ (S & 0xFFu)), (S >> 27) + static_cast<unsigned>(i));
}

// ---------- main container ----------

// Template ID added for POLYMORPHISM. 
// Every string generates a unique class type, breaking IDA decompilers.
template <size_t N, uint32_t ID>
class EncryptedAtRuntime {
    uint8_t enc_[N];       // encrypted bytes (compile-time)
    mutable char buf_[N];  // decrypted buffer (runtime)
    
    // Key Chain: We do not store the seed directly. 
    // real_seed = k1_ ^ k2_
    uint32_t k1_;          
    uint32_t k2_;          
    
    mutable bool ready_;   // buf_ is currently decrypted

    [[nodiscard]] constexpr uint8_t enc_byte(char c, size_t i, uint32_t s) const noexcept {
        return static_cast<uint8_t>(static_cast<uint8_t>(c) ^ ks(s, i));
    }

public:
    // Constructor: Splits the seed and encrypts
    constexpr EncryptedAtRuntime(const char (&s)[N], uint32_t seed) noexcept
        : enc_{}, buf_{}, k1_(seed ^ 0xDEADBEEF), k2_(0xDEADBEEF), ready_(false) {
        // We split seed into k1 and k2. 
        // k1_ = seed ^ magic
        // k2_ = magic
        // So k1_ ^ k2_ = seed.
        for (size_t i = 0; i < N; ++i) {
            enc_[i] = enc_byte(s[i], i, seed);
        }
    }

    // Decrypt & cache
    inline const char* get() const noexcept {
        if (!ready_) {
            decrypt_now();
        }
        return buf_;
    }

    // Decrypt freshly with JUNK CODE and ANTI-DUMP
    inline const char* decrypt_now() const noexcept {
        // 1. Recover the seed at runtime (Key Chain)
        volatile uint32_t v_k1 = k1_;
        volatile uint32_t v_k2 = k2_;
        uint32_t s = v_k1 ^ v_k2;

        // 2. Junk Code / Control Flow Flattening
        // This loop does nothing useful but confuses the decompiler graph.
        volatile int fake_flow = (ID % 3) + 1;
        switch (fake_flow) {
            case 1: s ^= 0; break;
            case 2: s = (s + 1) - 1; break;
            default: break;
        }

        // 3. Actual Decryption
        for (size_t i = 0; i < N; ++i) {
            buf_[i] = static_cast<char>(enc_[i] ^ ks(s, i));
        }
        buf_[N - 1] = '\0'; // Safety null-terminator
        ready_ = true;
        return buf_;
    }

    // Wipe plaintext from RAM (Anti-Dump)
    inline void clear() const noexcept {
        volatile char* v_buf = buf_; 
        for (size_t i = 0; i < N; ++i) {
            v_buf[i] = '\0';
        }
        ready_ = false;
    }

    friend class ScopedPlainBase;
};

// ---------- RAII guard that auto-wipes ----------
class ScopedPlainBase {
protected:
    const char* p_ = nullptr;
public:
    inline const char* get() const noexcept { return p_; }
    inline operator const char*() const noexcept { return p_; }
};

// Template so we know buffer length to wipe
template <size_t N, uint32_t ID>
class ScopedPlain : public ScopedPlainBase {
    const EncryptedAtRuntime<N, ID>* obj_;
public:
    explicit ScopedPlain(const EncryptedAtRuntime<N, ID>& o) : obj_(&o) {
        p_ = obj_->decrypt_now();
    }
    ~ScopedPlain() {
        // Secure wipe immediately after use
        obj_->clear();
    }
};

// ---------- macros ----------

// Helper to generate unique IDs based on line number
#define VIRUS_RT_SEED() (::virus::seed32( \
    static_cast<uint32_t>(__LINE__), \
    static_cast<uint32_t>(__COUNTER__), \
    static_cast<uint32_t>(0x6C796769u)))

// Usage: auto s = ENC_RT("text");
// The __COUNTER__ here ensures every string creates a unique Template Class (Polymorphism)
#define ENC_RT(str) ([]() -> const char* { \
    static constexpr uint32_t _seed = VIRUS_RT_SEED(); \
    static constexpr uint32_t _id = __COUNTER__; \
    static const ::virus::EncryptedAtRuntime<sizeof(str), _id> _obj(str, _seed); \
    return _obj.get(); \
}())

// Usage: ENC_RT_GUARD(msg, "text"); 
// This is the safest method. It decrypts -> uses -> wipes immediately.
#define ENC_RT_GUARD(var, str) \
    static constexpr uint32_t var##_seed = VIRUS_RT_SEED(); \
    static constexpr uint32_t var##_id = __COUNTER__; \
    static const ::virus::EncryptedAtRuntime<sizeof(str), var##_id> var##_obj(str, var##_seed); \
    ::virus::ScopedPlain<sizeof(str), var##_id> var(var##_obj)

} // namespace virus

#pragma once
#include <cstdint>
#include <cstddef>
#include <utility> // for std::index_sequence

// Force inline macros for MSVC, Clang, GCC
#if defined(_MSC_VER)
    #define VIRUS_FORCE_INLINE __forceinline
#else
    #define VIRUS_FORCE_INLINE __attribute__((always_inline)) inline
#endif

namespace virus {

namespace detail {
    // -------------------------------------------------------------------------
    // Compile-Time Math Helpers (The "Key Generator")
    // -------------------------------------------------------------------------

    [[nodiscard]] constexpr uint8_t ror8(uint8_t x, unsigned r) noexcept {
        return static_cast<uint8_t>((x >> (r & 7)) | (x << ((8 - r) & 7)));
    }

    // A chaotic Linear Congruential Generator for compile-time constants
    [[nodiscard]] constexpr uint32_t seed_generator(uint32_t a, uint32_t b, uint32_t c) noexcept {
        uint32_t s = a ^ (b * 0x9E3779B9u) ^ (c * 0x85EBCA6Bu);
        s ^= s >> 16; s *= 0x7FEB352Du; s ^= s >> 15; s *= 0x846CA68Bu; s ^= s >> 16;
        return s;
    }

    // Generates a pseudo-random byte based on seed and index
    [[nodiscard]] constexpr uint8_t key_byte(uint32_t seed, size_t index) noexcept {
        uint32_t x = seed ^ static_cast<uint32_t>(index * 0x5BD1E995);
        x ^= x >> 15; x *= 0x5BD1E995; x ^= x >> 13;
        return static_cast<uint8_t>(x);
    }
}

// -------------------------------------------------------------------------
// Polymorphic Encryption Algorithms
// -------------------------------------------------------------------------
// Depending on the ID (mod 4), we use a different mathematical operation.
// This prevents the decompiler from seeing the same "XOR" pattern everywhere.

template <uint32_t ID>
struct Algo {
    static constexpr uint8_t encrypt(uint8_t c, uint32_t seed, size_t i) {
        uint8_t k = detail::key_byte(seed, i);
        if constexpr ((ID % 4) == 0) return (c ^ k) + static_cast<uint8_t>(i);
        else if constexpr ((ID % 4) == 1) return (c + k) ^ 0x55;
        else if constexpr ((ID % 4) == 2) return detail::ror8(c ^ k, i);
        else return (c ^ k);
    }

    // The inverse operation for runtime decryption
    VIRUS_FORCE_INLINE static void decrypt(char* c, uint8_t e, uint32_t seed, size_t i) {
        volatile uint8_t k = detail::key_byte(seed, i); // volatile to stop pre-calc
        if constexpr ((ID % 4) == 0) *c = static_cast<char>((e - static_cast<uint8_t>(i)) ^ k);
        else if constexpr ((ID % 4) == 1) *c = static_cast<char>((e ^ 0x55) - k);
        else if constexpr ((ID % 4) == 2) *c = static_cast<char>(detail::ror8(e, 8 - (i & 7)) ^ k);
        else *c = static_cast<char>(e ^ k);
    }
};

// -------------------------------------------------------------------------
// The Container
// -------------------------------------------------------------------------

template <size_t N, uint32_t ID>
class EncryptedString {
private:
    // The encrypted data lives here (likely .rdata section in binary)
    uint8_t data_[N];
    uint32_t seed_;

    // Helper to encrypt all bytes at compile time
    template <size_t... Is>
    constexpr EncryptedString(const char (&str)[N], uint32_t seed, std::index_sequence<Is...>)
        : data_{ Algo<ID>::encrypt(str[Is], seed, Is)... }, seed_(seed) {}

public:
    // Public Constructor
    constexpr EncryptedString(const char (&str)[N], uint32_t seed)
        : EncryptedString(str, seed, std::make_index_sequence<N>{}) {}

    // ---------------------------------------------------------------------
    // Decryptor
    // ---------------------------------------------------------------------
    // We use a template to UNROLL the loop. This generates a massive block 
    // of straight-line assembly instructions instead of a "call" or "loop".
    
    template <size_t... Is>
    VIRUS_FORCE_INLINE void decrypt_to_buffer(char* buffer, std::index_sequence<Is...>) const {
        // Obfuscation: Local volatile copies to force reads
        volatile uint32_t local_seed = seed_;
        
        // This expands to: Algo::decrypt(&buffer[0], data_[0]...); Algo::decrypt(&buffer[1]...);
        (Algo<ID>::decrypt(&buffer[Is], data_[Is], local_seed, Is), ...);
        
        buffer[N - 1] = '\0'; // Ensure null termination
    }

    VIRUS_FORCE_INLINE void decrypt(char* buffer) const {
        decrypt_to_buffer(buffer, std::make_index_sequence<N>{});
    }
};

// -------------------------------------------------------------------------
// RAII Wrapper (Stack-based)
// -------------------------------------------------------------------------
// This ensures the plain text exists ONLY on the stack and ONLY for the scope.

template <size_t N, uint32_t ID>
class ScopedString {
private:
    char buffer_[N]; // The plain text buffer is ON THE STACK
public:
    VIRUS_FORCE_INLINE explicit ScopedString(const EncryptedString<N, ID>& enc) {
        // Decrypt immediately upon creation
        enc.decrypt(buffer_);
    }

    VIRUS_FORCE_INLINE ~ScopedString() {
        // Secure Zero Memory to prevent RAM dumps
        volatile char* p = buffer_;
        for (size_t i = 0; i < N; ++i) p[i] = 0;
        // Optimization Barrier
        __asm__ __volatile__("" : : "r"(p) : "memory"); 
    }

    // Accessors
    VIRUS_FORCE_INLINE const char* get() const { return buffer_; }
    VIRUS_FORCE_INLINE operator const char*() const { return buffer_; }
};

} // namespace virus

// -------------------------------------------------------------------------
// Macros
// -------------------------------------------------------------------------

// Generates a unique seed based on line number and time
#define VIRUS_SEED() (::virus::detail::seed_generator( \
    static_cast<uint32_t>(__LINE__), \
    static_cast<uint32_t>(__COUNTER__), \
    static_cast<uint32_t>(0xDEADBEEF)))

// 1. Create the encrypted static object (compile-time)
// 2. Create the stack wrapper (runtime)
#define ENC_RT(str) ([]() { \
    constexpr size_t n = sizeof(str); \
    constexpr uint32_t id = __COUNTER__; \
    constexpr uint32_t seed = VIRUS_SEED(); \
    /* This object sits in global read-only memory, fully encrypted */ \
    static constexpr auto _enc_obj = ::virus::EncryptedString<n, id>(str, seed); \
    /* This object sits on the stack, holds plaintext, auto-wipes on scope exit */ \
    return ::virus::ScopedString<n, id>(_enc_obj); \
}())
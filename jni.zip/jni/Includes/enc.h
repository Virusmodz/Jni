#pragma once

#include <cstddef>

//Coded By VirusModz 10/5/2025
namespace virus {

// 16-byte strong key
constexpr unsigned char strongKey[16] = {
    0x7A, 0x23, 0x5F, 0xD8, 0x19, 0xA2, 0x47, 0x6C,
    0x90, 0x33, 0xEA, 0x11, 0xAC, 0xDE, 0xF0, 0xB4
};

constexpr char crypt(char c, size_t i) {
    // Triple-key mixing with bitwise operations
    uint8_t k1 = strongKey[i % 16];
    uint8_t k2 = strongKey[(i + 5) % 16];  // Different offset 1
    uint8_t k3 = strongKey[(i + 11) % 16]; // Different offset 2
    uint8_t mixed = (k1 ^ k2) + k3;
    mixed ^= static_cast<uint8_t>(i);        // Incorporate full index
    mixed = (mixed << 3) | (mixed >> 5);     // Rotate left by 3 bits
    
    return c ^ static_cast<char>(mixed);
}

template <size_t N>
class EncryptedString {
    mutable char data[N];
    mutable bool decrypted = false;

public:
    constexpr EncryptedString(const char (&str)[N])
        : data{} {
        for (size_t i = 0; i < N; ++i) {
            data[i] = crypt(str[i], i);
        }
    }

    const char* get() const {
        decrypt();
        return data;
    }

private:
    void decrypt() const {
        if (!decrypted) {
            for (size_t i = 0; i < N; ++i) {
                data[i] = crypt(data[i], i);
            }
            decrypted = true;
        }
    }
};

#define enc(str) virus::EncryptedString<sizeof(str)>(str).get()

} 
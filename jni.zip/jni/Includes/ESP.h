#ifndef KingEsp_H
#define KingEsp_H

#include <jni.h>
class KingEsp {
private:
    JNIEnv *_env;
    jobject _cvsView;
    jobject _cvs;

public:
    KingEsp() {
        _env = nullptr;
        _cvsView = nullptr;
        _cvs = nullptr;
    }

    KingEsp(JNIEnv *env, jobject cvsView, jobject cvs) {
        this->_env = env;
        this->_cvsView = cvsView;
        this->_cvs = cvs;
    }

    bool isValid() const {
        return (_env != nullptr && _cvsView != nullptr && _cvs != nullptr);
    }

    int getWidth() const {
        if (isValid()) {
            jclass canvas = _env->GetObjectClass(_cvs);
            jmethodID width = _env->GetMethodID(canvas, "getWidth", "()I");
            return _env->CallIntMethod(_cvs, width);
        }
        return 0;
    }

    int getHeight() const {
        if (isValid()) {
            jclass canvas = _env->GetObjectClass(_cvs);
            jmethodID width = _env->GetMethodID(canvas, "getHeight", "()I");
            return _env->CallIntMethod(_cvs, width);
        }
        return 0;
    }

    void DrawLine(Color color, float thickness, Vector2 start, Vector2 end) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawline = _env->GetMethodID(canvasView, "DrawLine",
                                                   "(Landroid/graphics/Canvas;IIIIFFFFF)V");
            _env->CallVoidMethod(_cvsView, drawline, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 thickness,
                                 start.X, start.Y, end.X, end.Y);
        }
    }

	void DrawText(Color color, const char *txt, Vector2 pos, float size) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawtext = _env->GetMethodID(canvasView, "DrawText",
                                                   "(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V");
            _env->CallVoidMethod(_cvsView, drawtext, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 _env->NewStringUTF(txt), pos.X, pos.Y, size);
        }
    }

    void DrawFilledCircle(Color color, Vector2 pos, float radius) {
        if (isValid()) {
            jclass canvasView = _env->GetObjectClass(_cvsView);
            jmethodID drawfilledcircle = _env->GetMethodID(canvasView, "DrawFilledCircle",
                                                           "(Landroid/graphics/Canvas;IIIIFFF)V");
            _env->CallVoidMethod(_cvsView, drawfilledcircle, _cvs, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b, pos.X, pos.Y, radius);
        }
    }
    
    Vector3 add(Vector3 a, Vector3 b) {
    Vector3 c;
    c.x= a.x + b.x;
    c.y = a.y + b.y;
    c.z = a.z + b.z;
    return c;
}


void Draw3dBox(KingEsp esp, float thickness, Color espColor, Vector3 Transform,void * camera,int glHeight,int glWidth) {
    Vector3 position2 = add(Transform, Vector3(0.6, 1.6, 0.8)); 
    Vector3 position3 = add(Transform, Vector3(0.6, 0, 0.8));
    Vector3 position4 = add(Transform, Vector3(-0.5, 0, 0.8)); 
    Vector3 position5 = add(Transform, Vector3(-0.5, 1.6, 0.8));
    Vector3 position6 = add(add(Transform, Vector3(0.6, 1.6, 0)), Vector3(0, 0, -0.6));
    Vector3 position7 = add(add(Transform, Vector3(0.6, 0, 0)), Vector3(0, 0, -0.6));
    Vector3 position8 = add(add(Transform, Vector3(-0.5, 0, 0)), Vector3(0, 0, -0.6)); 
    Vector3 position9 = add(add(Transform, Vector3(-0.5, 1.6, 0)), Vector3(0, 0, -0.6));

    Vector3 vector = WorldToScreenPoint(camera, position2);
    Vector3 vector2 = WorldToScreenPoint(camera, position3);
    Vector3 vector3 = WorldToScreenPoint(camera, position4);
    Vector3 vector4 = WorldToScreenPoint(camera, position5);
    Vector3 vector5 = WorldToScreenPoint(camera, position6);
    Vector3 vector6 = WorldToScreenPoint(camera, position7);
    Vector3 vector7 = WorldToScreenPoint(camera, position8);
    Vector3 vector8 = WorldToScreenPoint(camera, position9);

    if (vector.z > 0 && vector2.z > 0 && vector3.z > 0 && vector4.z > 0 && vector5.z > 0 && vector6.z > 0 && vector7.z > 0 && vector8.z > 0 ) {
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector.x)), (glHeight - vector.y)), Vector2((glWidth - (glWidth - vector2.x)), (glHeight - vector2.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector3.x)), (glHeight - vector3.y)), Vector2((glWidth - (glWidth - vector2.x)), (glHeight - vector2.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector.x)), (glHeight - vector.y)), Vector2((glWidth - (glWidth - vector4.x)), (glHeight - vector4.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector4.x)), (glHeight - vector4.y)), Vector2((glWidth - (glWidth - vector3.x)), (glHeight - vector3.y)));
        
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector5.x)), (glHeight - vector5.y)), Vector2((glWidth - (glWidth - vector6.x)), (glHeight - vector6.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector7.x)), (glHeight - vector7.y)), Vector2((glWidth - (glWidth - vector6.x)), (glHeight - vector6.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector5.x)), (glHeight - vector5.y)), Vector2((glWidth - (glWidth - vector8.x)), (glHeight - vector8.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector8.x)), (glHeight - vector8.y)), Vector2((glWidth - (glWidth - vector7.x)), (glHeight - vector7.y)));
 
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector.x)), (glHeight - vector.y)), Vector2((glWidth - (glWidth - vector5.x)), (glHeight - vector5.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector2.x)), (glHeight - vector2.y)), Vector2((glWidth - (glWidth - vector6.x)), (glHeight - vector6.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector3.x)), (glHeight - vector3.y)), Vector2((glWidth - (glWidth - vector7.x)), (glHeight - vector7.y)));
        esp.DrawLine(espColor, thickness, Vector2((glWidth -(glWidth -vector4.x)), (glHeight - vector4.y)), Vector2((glWidth - (glWidth - vector8.x)), (glHeight - vector8.y)));    
    }
}

    void DrawBox(Color color, float stroke, Rect rect) {
        Vector2 v1 = Vector2(rect.x, rect.y);
        Vector2 v2 = Vector2(rect.x + rect.w, rect.y);
        Vector2 v3 = Vector2(rect.x + rect.w, rect.y + rect.h);
        Vector2 v4 = Vector2(rect.x, rect.y + rect.h);

        DrawLine(color, stroke, v1, v2); // LINE UP
        DrawLine(color, stroke, v2, v3); // LINE RIGHT
        DrawLine(color, stroke, v3, v4); // LINE DOWN
        DrawLine(color, stroke, v4, v1); // LINE LEFT
    }
    
    void DrawBox4Line(int x, int y, int w, int h, Color color, float thickness) {
     int iw = w / 4;
     int ih = h / 4;

     DrawLine(color,thickness,Vector2(x, y),Vector2(x + iw, y));
     DrawLine(color,thickness,Vector2(x + w - iw, y),Vector2(x + w, y));
     DrawLine(color,thickness,Vector2(x, y),Vector2(x, y + ih));
     DrawLine(color,thickness,Vector2(x + w - 1, y),Vector2(x + w - 1, y + ih));

     DrawLine(color,thickness,Vector2(x, y + h),Vector2(x + iw, y + h));
     DrawLine(color,thickness,Vector2(x + w - iw, y + h),Vector2(x + w, y + h));
     DrawLine(color,thickness,Vector2(x, y + h - ih), Vector2(x, y + h));
     DrawLine(color,thickness,Vector2(x + w - 1, y + h - ih), Vector2(x + w - 1, y + h));
   }

    void DrawHorizontalHealthBar(Vector2 screenPos, float width, float maxHealth, float currentHealth) {
        screenPos -= Vector2(0.0f, 8.0f);
        DrawBox(Color(0, 0, 0, 255), 3, Rect(screenPos.X - (width / 2) , screenPos.Y, width + 2, 5.0f));
        screenPos += Vector2(1.0f, 1.0f);
        Color clr = Color(0, 255, 0, 255);
        float hpWidth = (currentHealth * width) / maxHealth;
        if (currentHealth <= (maxHealth * 0.6)) {
            clr = Color(255, 255, 0, 255);
        }
        if (currentHealth < (maxHealth * 0.3)) {
            clr = Color(255, 0, 0, 255);
        }
        DrawBox(clr, 3, Rect(screenPos.X - (width / 2), screenPos.Y, hpWidth, 3.0f));
    }

    void DrawCrosshair(Color clr, Vector2 center, float size = 20) {
        float x = center.X - (size / 2.0f);
        float y = center.Y - (size / 2.0f);
        DrawLine(clr, 3, Vector2(x, center.Y), Vector2(x + size, center.Y));
        DrawLine(clr, 3, Vector2(center.X, y), Vector2(center.X, y + size));
    }
};

#endif


#include <jni.h>

JNIEnv* env;
jobject g_activity;

extern "C"
JNIEXPORT void JNICALL
Java_com_example_MainActivity_initNative(JNIEnv* e, jobject thiz) {
    env = e;
    g_activity = thiz;

    // LinearLayout
    jclass layoutCls = env->FindClass("android/widget/LinearLayout");
    jmethodID layoutCtor = env->GetMethodID(layoutCls, "<init>", "(Landroid/content/Context;)V");
    jobject layout = env->NewObject(layoutCls, layoutCtor, thiz);

    // Button
    jclass btnCls = env->FindClass("android/widget/Button");
    jmethodID btnCtor = env->GetMethodID(btnCls, "<init>", "(Landroid/content/Context;)V");
    jobject button = env->NewObject(btnCls, btnCtor, thiz);

    // setText
    jmethodID setText = env->GetMethodID(btnCls, "setText", "(Ljava/lang/CharSequence;)V");
    env->CallVoidMethod(button, setText, env->NewStringUTF("Click Me"));

    // addView
    jmethodID addView = env->GetMethodID(layoutCls, "addView", "(Landroid/view/View;)V");
    env->CallVoidMethod(layout, addView, button);

    // setContentView
    jclass actCls = env->GetObjectClass(thiz);
    jmethodID setContentView = env->GetMethodID(actCls, "setContentView", "(Landroid/view/View;)V");
    env->CallVoidMethod(thiz, setContentView, layout);
}

#include <jni.h>

extern "C"
JNIEXPORT void JNICALL
Java_com_example_MainActivity_initNative(JNIEnv* env, jobject activity) {

    // Toast test (to confirm JNI is working)
    jclass toastCls = env->FindClass("android/widget/Toast");
    jmethodID makeText = env->GetStaticMethodID(toastCls, "makeText",
        "(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;");
    jobject toast = env->CallStaticObjectMethod(toastCls, makeText,
        activity, env->NewStringUTF("JNI WORKING"), 1);

    jmethodID show = env->GetMethodID(toastCls, "show", "()V");
    env->CallVoidMethod(toast, show);

    // LinearLayout
    jclass layoutCls = env->FindClass("android/widget/LinearLayout");
    jmethodID layoutCtor = env->GetMethodID(layoutCls, "<init>", "(Landroid/content/Context;)V");
    jobject layout = env->NewObject(layoutCls, layoutCtor, activity);

    jmethodID setOri = env->GetMethodID(layoutCls, "setOrientation", "(I)V");
    env->CallVoidMethod(layout, setOri, 1);

    // Button
    jclass btnCls = env->FindClass("android/widget/Button");
    jmethodID btnCtor = env->GetMethodID(btnCls, "<init>", "(Landroid/content/Context;)V");
    jobject button = env->NewObject(btnCls, btnCtor, activity);

    jmethodID setText = env->GetMethodID(btnCls, "setText", "(Ljava/lang/CharSequence;)V");
    env->CallVoidMethod(button, setText, env->NewStringUTF("JNI BUTTON"));

    // LayoutParams
    jclass lpCls = env->FindClass("android/widget/LinearLayout$LayoutParams");
    jmethodID lpCtor = env->GetMethodID(lpCls, "<init>", "(II)V");
    jobject lp = env->NewObject(lpCls, lpCtor, -1, -2);

    jmethodID addView = env->GetMethodID(layoutCls, "addView",
        "(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V");
    env->CallVoidMethod(layout, addView, button, lp);

    // setContentView
    jclass actCls = env->GetObjectClass(activity);
    jmethodID setContent = env->GetMethodID(actCls, "setContentView",
        "(Landroid/view/View;)V");
    env->CallVoidMethod(activity, setContent, layout);
}

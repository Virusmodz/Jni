#include <jni.h>

extern "C"
JNIEXPORT void JNICALL
Java_com_example_MainActivity_initNative(JNIEnv* env, jobject activity) {

    // LinearLayout
    jclass layoutCls = env->FindClass("android/widget/LinearLayout");
    jmethodID layoutCtor = env->GetMethodID(layoutCls, "<init>", "(Landroid/content/Context;)V");
    jobject layout = env->NewObject(layoutCls, layoutCtor, activity);

    // setOrientation(VERTICAL)
    jmethodID setOri = env->GetMethodID(layoutCls, "setOrientation", "(I)V");
    env->CallVoidMethod(layout, setOri, 1); // 1 = VERTICAL

    // Button
    jclass btnCls = env->FindClass("android/widget/Button");
    jmethodID btnCtor = env->GetMethodID(btnCls, "<init>", "(Landroid/content/Context;)V");
    jobject button = env->NewObject(btnCls, btnCtor, activity);

    // setText
    jmethodID setText = env->GetMethodID(btnCls, "setText", "(Ljava/lang/CharSequence;)V");
    env->CallVoidMethod(button, setText, env->NewStringUTF("JNI Button"));

    // LayoutParams
    jclass lpCls = env->FindClass("android/widget/LinearLayout$LayoutParams");
    jmethodID lpCtor = env->GetMethodID(lpCls, "<init>", "(II)V");
    jobject lp = env->NewObject(lpCls, lpCtor, -1, -2); 
    // -1 = MATCH_PARENT, -2 = WRAP_CONTENT

    // addView(button, lp)
    jmethodID addView = env->GetMethodID(layoutCls, "addView",
        "(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V");
    env->CallVoidMethod(layout, addView, button, lp);

    // setContentView
    jclass actCls = env->GetObjectClass(activity);
    jmethodID setContent = env->GetMethodID(actCls, "setContentView",
        "(Landroid/view/View;)V");
    env->CallVoidMethod(activity, setContent, layout);
}

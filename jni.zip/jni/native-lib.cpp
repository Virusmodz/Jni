#include <jni.h>
#include <string>
#include <vector>
#include <sstream>
#include <iomanip>
#include <fstream>
#include <capstone/capstone.h>

// Helper to reverse bytes for "Word" display (Little Endian -> Big Endian visual)
// e.g., Memory: 00 48 2d e9 -> Display: e92d4800
uint32_t bytesToWord(const uint8_t* bytes) {
    return (bytes[3] << 24) | (bytes[2] << 16) | (bytes[1] << 8) | bytes[0];
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_virusmodz_dumper_MainActivity_dumpMethod(
        JNIEnv* env,
        jobject /* this */,
        jstring filePath,
        jlong offset,
        jlong size) {

    const char *path = env->GetStringUTFChars(filePath, 0);
    
    // 1. Open and Read File
    std::ifstream file(path, std::ios::binary);
    if (!file.is_open()) {
        env->ReleaseStringUTFChars(filePath, path);
        return env->NewStringUTF("Error: Could not open file.");
    }

    file.seekg(offset, std::ios::beg);
    if (!file.good()) {
        env->ReleaseStringUTFChars(filePath, path);
        return env->NewStringUTF("Error: Invalid offset.");
    }

    std::vector<uint8_t> code(size);
    file.read((char*)code.data(), size);
    file.close();

    // 2. Initialize Capstone
    csh handle;
    cs_insn *insn;
    size_t count;
    std::stringstream ss;

    // Use ARM mode (32-bit). Change to CS_MODE_THUMB if target is Thumb.
    if (cs_open(CS_ARCH_ARM, CS_MODE_ARM, &handle) != CS_ERR_OK) {
        return env->NewStringUTF("Error: Failed to init Capstone engine.");
    }
    
    // Enable details for better formatting
    cs_option(handle, CS_OPT_DETAIL, CS_OPT_ON);

    // 3. Disassemble
    // code.data() = buffer, size = length, offset = starting address label
    count = cs_disasm(handle, code.data(), size, offset, 0, &insn);

    if (count > 0) {
        // Print Function Header
        ss << std::hex << offset << " <Code_Chunk_at_" << offset << ">:\n\n";

        for (size_t i = 0; i < count; i++) {
            // Address (e.g., 4b5dc4:)
            ss << "  " << std::hex << insn[i].address << ":\t";

            // Bytes (e.g., e92d4800)
            // ARM is typically 4 bytes. 
            if (insn[i].size == 4) {
                // Display as 32-bit word like objdump
                ss << std::setw(8) << std::setfill('0') << bytesToWord(insn[i].bytes);
            } else {
                // Fallback for Thumb/variable size
                for (int j = 0; j < insn[i].size; j++) {
                     ss << std::setw(2) << std::setfill('0') << (int)insn[i].bytes[j];
                }
            }

            // Mnemonic & Op Str (e.g., push {r11, lr})
            ss << "\t" << insn[i].mnemonic << "\t" << insn[i].op_str << "\n";
        }
        cs_free(insn, count);
    } else {
        ss << "Failed to disassemble (Check Offset/Mode).\n";
    }

    cs_close(&handle);
    env->ReleaseStringUTFChars(filePath, path);

    return env->NewStringUTF(ss.str().c_str());
}

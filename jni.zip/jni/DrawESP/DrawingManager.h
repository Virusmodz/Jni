#include "VirusModz.h"
#include <unordered_set>

using namespace std;

unordered_set<void *> playerslist;

bool EnableESP, ESPLine, ESPtext;
int Startpos, Endpos;

float dts;
void* localPlayer = NULL;
 void** g_pWorldLayer; 

std::string namess;



/*
struct CCPoint {
    float x;
    float y;
};
*/


void* (*sharedDirector_t)();
Vector2 (*convertToUI_t)(void* director, const Vector2& input);




int (*getTeamId)(void* instance); // get players team like 1 to 8, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead

unsigned char* (*getBytesFunc)(void*);


float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);




// class SoldierView and i have SoldierView class update offset 
void (*old_setPlayerName_hook)(void* self, std::string name);
void setPlayerName_hook(void* self, std::string name) {
if (self != NULL){

namess = name;
}
return old_setPlayerName_hook(self, name);
}


// class SoldierRemoteController 
void (*old_EnemyU)(void *instance, float dt); // enemy player update offset 
void EnemyU(void *instance, float dt) {


    if (instance != NULL && gethp(instance) > 0 || !isdead(instance)) {
    
        playerslist.insert(instance);
        
    }
    return old_EnemyU(instance, dt);
}



// class SoldierLocalController 
void (*old_SoldierLocalController)(void* instance, float dt); // my player update offset 
void SoldierLocalController(void* instance, float dt) {
    if (instance != NULL) {
  
  /*  void *body = *(void **)((char *)instance + 0x148);
    if (body != NULL) {

            float *getBodyVelocityX = (float *)((char *)body + 0x38);
            float *getBodyVelocityY = (float *)((char *)body + 0x3c);
    } */
        
        localPlayer = instance;
    }
    return old_SoldierLocalController(instance, dt);
}

void (*old_removebody)(void* instance); // this function call when any Player leave the match or game end
void removebody(void* instance){
if (instance){

playerslist.erase(instance);

} 
return old_removebody(instance);
} 


// Add this global variable declaration at the top of DrawingManager.h


bool ESPRadar; // Add this global variable

void DrawESP(AadilDrawing esp, int width, int height) {
    if (!ESPRadar || !localPlayer) return;

    // 1. Setup Radar Position (Top Right)
    float radarRadius = 100.0f; 
    Vector2 radarCenter = Vector2(width - 120, 120);
    float scale = 29.0f; // Zoom of the radar

    // 2. Draw Radar Background (Gray Circle)
    esp.DrawCircle(Color(255, 255, 255, 150), 2.0f, radarRadius, radarCenter);
    esp.DrawFilledCircle(Color(50, 50, 50, 100), radarRadius, radarCenter);

    // 3. Draw "You" (Green Dot in center)
    esp.DrawFilledCircle(Color(0, 255, 0, 255), 4.0f, radarCenter);

    float localX = GetPositionX(localPlayer);
    float localY = GetPositionY(localPlayer);

    for (void *player : playerslist) {
        if (player && gethp(player) > 0 || !isdead(player)) {
            // Calculate distance
            float enX = GetPositionX(player);
            float enY = GetPositionY(player);

            float relX = (enX - localX) / scale;
            float relY = (enY - localY) / scale;

            // Check if enemy is within radar circle radius (Pythagoras theorem)
            if ((relX * relX + relY * relY) <= (radarRadius * radarRadius)) {
                Vector2 dotPos = Vector2(radarCenter.x + relX, radarCenter.y - relY);
                if (getTeamId(localPlayer) > 1 && getTeamId(localPlayer) != getTeamId(player)){
                esp.DrawFilledCircle(Color(255, 0, 0, 255), 4.0f, dotPos); // Red dot for enemy
                } else {
                    esp.DrawFilledCircle(Color(0, 100, 255, 255), 4.0f, dotPos);
                }
            }
        } else {
        playerslist.erase(player);
        }
    }
}

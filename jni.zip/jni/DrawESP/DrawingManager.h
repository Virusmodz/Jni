#include "VirusModz.h"
#include <unordered_set>
#include <cmath> // Added for sin/cos functions

// Import the globals
extern JavaVM *g_jvm;
extern jobject g_context;

void ShowToastFromGame(const char* msg) {
    if (!g_jvm || !g_context) return;

    JNIEnv* env;
    // Check the current status of the thread
    int getEnvStat = g_jvm->GetEnv((void**)&env, JNI_VERSION_1_6);
    
    bool needsDetach = false;

    if (getEnvStat == JNI_EDETACHED) {
        // Only attach if it wasn't already attached
        if (g_jvm->AttachCurrentThread(&env, NULL) != 0) return;
        needsDetach = true;
    } else if (getEnvStat != JNI_OK) {
        // If it's an error (like JNI_EVERSION), stop
        return;
    }

    // Call the Toast function from Setup.h
    Toast(env, g_context, msg, 1);

    // CRITICAL FIX: Only detach if WE attached it. 
    // If the game attached it, leave it alone.
    if (needsDetach) {
        g_jvm->DetachCurrentThread();
    }
}
using namespace std;



void* localPlayer = NULL;
void* StageUP = NULL;

float hpvalue, isboost;



// getClaimedAvatarName

bool (*isflying)(void* instance);

void (*returnToLobby)(void* instance);

void exitgame(){
returnToLobby(StageUP);
}


void (*old_Stage)(void *instance, float dt); 
void Stage(void *instance, float dt) {
    if (instance != NULL) {
        
        StageUP = instance;
    }
    
    return old_Stage(instance, dt);
}





float (*old_boost)(void *instance);
float Boost(void *instance){
    if (instance != NULL){
        
        isboost = old_boost(instance);
        
        
    }
    return old_boost(instance);
}

void (*old_updateNetworkObjects)(void* instance, float dt);
void updateNetworkObjects(void* instance, float dt) {
 if (instance != NULL){
 
 
 }
 return old_updateNetworkObjects(instance, dt);
}




float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);




std::string (*old_getgmail)(void *instance); 
std::string getgmail(void *instance) {

   

    if (instance != NULL) {
    
    //Gmail = old_getgmail(instance);
    //  return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getgmail(instance);
}

std::string (*old_gCode)(void *instance); // granade update offset 
std::string gCode(void *instance) {

   

    if (instance != NULL) {
    
 //   Code = old_gCode(instance);
      // return std::string("ankur123");
    }
    return old_gCode(instance);
}

bool (*old_isPlayerAuthenticated)(void* instance); 
bool isPlayerAuthenticated(void* instance){
if (instance){

//return true;

} 
return old_isPlayerAuthenticated(instance);
} 

std::string (*old_getPlayerIdentity)(void *instance); // granade update offset 
std::string getPlayerIdentity(void *instance) {

   

    if (instance != NULL) {
    
  //Code = old_getPlayerIdentity(instance);
       //return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getPlayerIdentity(instance);
}



std::string (*old_getPlayerProfileData)(void *instance); // granade update offset 
std::string getPlayerProfileData(void *instance) {

   

    if (instance != NULL) {
    
    
    
    //LOGI("Player Profile Gmail = %s", Gmail.c_str());

    //  return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getPlayerProfileData(instance);
}




// class SoldierRemoteController 
void (*old_EnemyU)(void *instance, float dt); // enemy player update offset 
void EnemyU(void *instance, float dt) {


    if (instance != NULL) {
        
      
    }
    return old_EnemyU(instance, dt);
}




// class SoldierLocalController 
void (*old_SoldierLocalController)(void* instance, float dt); // my player update offset 
void SoldierLocalController(void* instance, float dt) {
    if (instance != NULL) {
    
 if (!hasDetectedHacker && isflying(instance) && isboost < 1) {
             hasDetectedHacker = true; // Set flag immediately
             
             ShowToastFromGame("Hacker Detected: Flying without Boost!");
             
             // Optional: Add a small sleep to let the toast process before killing
             // sleep(1); 
             
             exitgame();
        }
        localPlayer = instance;
    }
    return old_SoldierLocalController(instance, dt);
}

void (*old_removebody)(void* instance); // this function call when any Player leave the match or game end
void removebody(void* instance){
if (instance){


} 
return old_removebody(instance);
} 

std::string (*old_pacage)(void* instance);
std::string pacage(void* instance){
  if (instance != NULL){
  
  
  }
 return old_pacage(instance);
}




void DrawESP(AadilDrawing esp, int width, int height) {

//std::string any = std::to_string(git);
//esp.DrawText(Color(0, 100, 255, 255), Gmail.c_str(), Vector2(width / 2, height / 3.7), 20);

//esp.DrawText(Color(0, 100, 255, 255), Code.c_str(), Vector2(width / 2, height / 2.0), 20);


}

#include "VirusModz.h"
#include <unordered_set>
#include <cmath> // Added for sin/cos functions
#include <vector>
#include <algorithm>
#include <string>
#include <sstream> // Add this at the top of your file


using namespace std;



void* localPlayer = NULL;
void* StageUP = NULL;
void* networkUp = NULL;
float hpvalue, isboost;

bool isbannefs;

// getClaimedAvatarName

bool (*isflying)(void* instance);

void (*returnToLobby)(void* instance);
void (*destroyNetwork)(void *instance);


void exitgame(){
returnToLobby(StageUP);
}

void crashgame(){
destroyNetwork(networkUp);
sleep(5);
        int *p = 0;
        *p = 0;
}

void (*old_Stage)(void *instance, float dt); 
void Stage(void *instance, float dt) {
    if (instance != NULL) {
        
        StageUP = instance;
    }
    
    return old_Stage(instance, dt);
}





float (*old_boost)(void *instance);
float Boost(void *instance){
    if (instance != NULL){
        
        isboost = old_boost(instance);
        
        
    }
    return old_boost(instance);
}



void (*old_updateNetworkObjects)(void* instance, float dt);
void updateNetworkObjects(void* instance, float dt) {
 if (instance != NULL){
 
 networkUp = instance;
 
 }
 return old_updateNetworkObjects(instance, dt);
}




float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);




std::string (*old_getgmail)(void *instance); 
std::string getgmail(void *instance) {

   

    if (instance != NULL) {
    
    //Gmail = old_getgmail(instance);
    //  return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getgmail(instance);
}

std::string (*old_gCode)(void *instance); // granade update offset 
std::string gCode(void *instance) {

   

    if (instance != NULL) {
    
 //   Code = old_gCode(instance);
      // return std::string("ankur123");
    }
    return old_gCode(instance);
}

bool (*old_isPlayerAuthenticated)(void* instance); 
bool isPlayerAuthenticated(void* instance){
if (instance){

//return true;

} 
return old_isPlayerAuthenticated(instance);
} 

std::string (*old_getPlayerIdentity)(void *instance); // granade update offset 
std::string getPlayerIdentity(void *instance) {

   

    if (instance != NULL) {
    
  //Code = old_getPlayerIdentity(instance);
       //return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getPlayerIdentity(instance);
}



std::string (*old_getPlayerProfileData)(void *instance); // granade update offset 
std::string getPlayerProfileData(void *instance) {

   

    if (instance != NULL) {
    
    
    
    //LOGI("Player Profile Gmail = %s", Gmail.c_str());

    //  return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getPlayerProfileData(instance);
}




// class SoldierRemoteController 
void (*old_EnemyU)(void *instance, float dt); // enemy player update offset 
void EnemyU(void *instance, float dt) {


    if (instance != NULL) {
        
      
    }
    return old_EnemyU(instance, dt);
}




// class SoldierLocalController 
// class SoldierLocalController 
void (*old_SoldierLocalController)(void* instance, float dt); // my player update offset 

void SoldierLocalController(void* instance, float dt) {
    // Static variable keeps its value between function calls
    static float flyTimer = 0.0f; 

    if (instance != NULL) {
        
        // Check if the condition is met
        if (isflying(instance) && isboost == 0) {
            
            // Add the time passed (dt) to our timer
            flyTimer += dt;

            // If timer exceeds 1.0 (1 second), run the code
            if (flyTimer >= 1.0f) {
                exitgame();
                flyTimer = 0.0f; // Reset timer after execution
            }

        } else {
            // If the condition is NOT met at any point, reset the timer
            // This ensures the check must be continuous for 1 second
            flyTimer = 0.0f;
        }

        localPlayer = instance;
    }
    return old_SoldierLocalController(instance, dt);
}

void (*old_removebody)(void* instance); // this function call when any Player leave the match or game end
void removebody(void* instance){
if (instance){


} 
return old_removebody(instance);
} 

std::string (*old_pacage)(void* instance);
std::string pacage(void* instance){
  if (instance != NULL){
  
  
  }
 return old_pacage(instance);
}


std::vector<std::string> bannedWords = {
   

    // English Profanity (Common)
    "fuck", "fucker", "fucking", "fucks", "bitch", "bitches", "asshole", "dick", "pussy", "slut", "whore",

    // Hindi/Urdu - Swear Words (From Document & Variations)
    "bc", "mc", "bhenchod", "behanchod", "behenchod", "bahenchod", "bhanchod",
    "madarchod", "maderchod", "maaderchod", "m*c", "b*c",
    "gand", "gaand", "gandu", "gaandu", "gndu", "ganduwa",
    "loda", "lauda", "lode", "lawda", "lowda", "lund", "land",
    "chutiya", "chutiye", "chutya", "chut", "choote", "bhosdike", "bhosike", "bhosadi",
    "harami", "saala", "sala", "kamine", "kutta", "kuttiya", "randi", "randa", "randwa",
    "bhadwa", "betichod", "baapchod", "bhonsri", "bhosari", "tatte", "tatta", "muth", "jhant",

    // Religious Terms (Gods/Deities - Exact match only)
    "god", "allah", "ram", "rama", "shiva", "shiv", "krishna", "ganesh", "hanuman", 
    "jesus", "christ", "muhammad", "prophet", "hindu", "muslim", "sikh", "isai",
    "mandir", "masjid", "church", "quran", "bible", "gita", "geeta", "dharam", "mazhab"
};



void CheckForBannedWords(std::string text) {
    // 1. Convert entire input to lowercase
    std::transform(text.begin(), text.end(), text.begin(), ::tolower);

    // 2. Replace common punctuation with spaces to avoid bypasses like "hack!"
    for (int i = 0; i < text.length(); i++) {
        if (ispunct(text[i])) text[i] = ' ';
    }

    // 3. Split the sentence into individual words
    std::stringstream ss(text);
    std::string word;
    
    while (ss >> word) {
        // 4. Compare each standalone word against the banned list
        for (const std::string& banned : bannedWords) {
            if (word == banned) {
                exitgame(); // Match found, call return lobby
                crashgame();
                isbannefs = true;
                return;
            }
        }
    }
}


void (*old_CustomAvatarLayer)(void* thiz, void* editBox, const std::string& text);
void CustomAvatarLayer(void* thiz, void* editBox, const std::string& text) {
    // Create a local copy so we can modify it if needed
    

    if (thiz) {
        // Check the original text
        CheckForBannedWords(text);
        
        // If it was banned, change our local copy
    
    }
    // Pass the filteredText instead of the original const text
    return old_CustomAvatarLayer(thiz, editBox, text);
}

void (*old_gameHUD)(void* thiz, void* editBox, const std::string& text);
void gameHUD(void* thiz, void* editBox, const std::string& text) {
    if (thiz) {
       
        
        // Check the text against the list
        CheckForBannedWords(text);
    }
    return old_gameHUD(thiz, editBox, text);
}

void (*old_PlayerLobby)(void* thiz, void* editBox, const std::string& text);
void PlayerLobby(void* thiz, void* editBox, const std::string& text) {
    if (thiz) {
        
        
        // Check the text against the list
        CheckForBannedWords(text);
    }
    return old_PlayerLobby(thiz, editBox, text);
}



void DrawESP(AadilDrawing esp, int width, int height) {

//std::string any = std::to_string(git);
//esp.DrawText(Color(0, 100, 255, 255), Gmail.c_str(), Vector2(width / 2, height / 3.7), 20);

//esp.DrawText(Color(0, 100, 255, 255), Code.c_str(), Vector2(width / 2, height / 2.0), 20);


}

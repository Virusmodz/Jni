#include "VirusModz.h"
#include <unordered_set>
#include <cmath> // Added for sin/cos functions

using namespace std;

unordered_set<void *> playerslist;


bool EnableESP, ESPLine, ESPtext, isProxy, plIDS, smapD, espname, sendfp;
int Startpos, Endpos;

float dts;
void* localPlayer = NULL;
 void** g_pWorldLayer; 

void* activatePX = NULL;
std::string namess;
std::string Gmail;
std::string Code;
float git;


/*
struct CCPoint {
    float x;
    float y;
};
*/
// Original function pointer
void (*orig_sendPositionData)(void* instance, float value, bool flag);

// Hooked function
void hook_sendPositionData(void* instance, float value, bool flag) {
    if (instance != NULL && sendfp) {
        
    value * 1.5f;
    flag = true;
    
    // Example: force flag to true
    // flag = true;

    // Example: modify value
    // value += 10.0f;

 }
    return orig_sendPositionData(instance, value, flag);
}

void (*old_updateNetworkObjects)(void* instance, float dt);
void updateNetworkObjects(void* instance, float dt) {
 if (instance != NULL){
 
 
 }
 return old_updateNetworkObjects(instance, dt);
}


void* (*sharedDirector_t)();
Vector2 (*convertToUI_t)(void* director, const Vector2& input);

// Add this with your other function pointers
Vector2 (*convertToWorldSpace)(void* node, const Vector2& pos);

Vector2 WorldToScreen(void* player) {
    if (!sharedDirector_t || !convertToUI_t || !convertToWorldSpace) {
        return Vector2(0, 0);
    }

    void* director = sharedDirector_t();
    
    // 1. Convert Player Local Position (0,0 relative to player) to World Space
    // We use Vector2(0,0) because we want the player's own anchor point
    Vector2 playerWorldPos = convertToWorldSpace(player, Vector2(0, 0));

    // 2. Convert World Space to Screen (UI) Coordinates
    Vector2 screenPos = convertToUI_t(director, playerWorldPos);

    // 3. Fix Y-Axis (Cocos2d Y is bottom-up, Android Canvas is top-down)
    // You might need to retrieve the screen height to do: height - screenPos.y
    return screenPos;
}

int (*getTeamId)(void* instance); // get players team id like 1 to 7, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead

float (*getFireAngle)(void* instance); // get enemy fire angle 0 to 360

float (*getRotation)(void* instance); // get enemy rotation angle 0 to 360

bool (*isDucked)(void* instance); // to chake enemy croush or not croush = true

bool (*getThrustFactor)(void* instance); // to chake enemy flying or not

std::string (*getPeerID)(void* instance); // to chake players id

std::string (*getPlayerName)(void* instance);

float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);


std::string reason1;


void (*addDamage)(void* instance, float damage, std::string* reason, int hitType, bool critical);



// class SoldierView and i have SoldierView class update offset 
void (*old_setPlayerName_hook)(void* self, std::string name);
void setPlayerName_hook(void* self, std::string name) {
if (self != NULL){

namess = name;
}
return old_setPlayerName_hook(self, name);
}


void (*old_FRAGNADE)(void *instance, float dt); // granade update offset 
void FRAGNADE(void *instance, float dt) {


    if (instance != NULL) {
    
     
        
    }
    return old_FRAGNADE(instance, dt);
}

std::string (*old_getgmail)(void *instance); // granade update offset 
std::string getgmail(void *instance) {

   

    if (instance != NULL) {
    
    //Gmail = old_getgmail(instance);
      //  return std::string("ankurbirpatra19@gmail.com");
    }
    return old_getgmail(instance);
}

std::string (*old_gCode)(void *instance); // granade update offset 
std::string gCode(void *instance) {

   

    if (instance != NULL) {
    
 //   Code = old_gCode(instance);
       // return std::string("ankur123");
    }
    return old_gCode(instance);
}

bool (*old_isPlayerAuthenticated)(void* instance); 
bool isPlayerAuthenticated(void* instance){
if (instance){

//return true;

} 
return old_isPlayerAuthenticated(instance);
} 

std::string (*old_getPlayerIdentity)(void *instance); // granade update offset 
std::string getPlayerIdentity(void *instance) {

   

    if (instance != NULL) {
    
  Code = old_getPlayerIdentity(instance);
       // return std::string("ankur123");
    }
    return old_getPlayerIdentity(instance);
}
// class SoldierRemoteController 
void (*old_EnemyU)(void *instance, float dt); // enemy player update offset 
void EnemyU(void *instance, float dt) {


    if (instance != NULL) {
        
        if (smapD){
    
   // addDamage(instance, damage1, &reason1, hitType1, true);
    }
    if (gethp(instance) > 0 || !isdead(instance)) {
    
        playerslist.insert(instance);
        }
    }
    return old_EnemyU(instance, dt);
}




// class SoldierLocalController 
void (*old_SoldierLocalController)(void* instance, float dt); // my player update offset 
void SoldierLocalController(void* instance, float dt) {
    if (instance != NULL) {
 void* targetBody = *(void **)((char *)instance + 0x148);
           if (targetBody != NULL){
           float targetX = *(float *)((char *)targetBody + 0x2c);
		   float targetY = *(float *)((char *)targetBody + 0x34);
		   
		   float localX = GetPositionX(instance);
           float localY = GetPositionY(instance);
           
        git = localX / targetX;
		   }
  /* void *body = *(void **)((char *)instance + 0x148);
    if (body != NULL) {

            float *getBodyVelocityX = (float *)((char *)body + 0x38);
            float *getBodyVelocityY = (float *)((char *)body + 0x3c);
    } */
        
        localPlayer = instance;
    }
    return old_SoldierLocalController(instance, dt);
}

void (*old_removebody)(void* instance); // this function call when any Player leave the match or game end
void removebody(void* instance){
if (instance){

playerslist.erase(instance);

} 
return old_removebody(instance);
} 

std::string (*old_pacage)(void* instance);
std::string pacage(void* instance){
  if (instance != NULL){
  
  reason1 = old_pacage(instance);
  }
 return old_pacage(instance);
}

// Add this global variable declaration at the top of DrawingManager.h


bool ESPRadar; // Add this global variable

void DrawESP(AadilDrawing esp, int width, int height) {

//std::string any = std::to_string(git);
esp.DrawText(Color(0, 100, 255, 255), Gmail.c_str(), Vector2(width / 2, height / 3.7), 20);

esp.DrawText(Color(0, 100, 255, 255), Code.c_str(), Vector2(width / 2, height / 2.0), 20);

//esp.DrawText(Color(0, 100, 255, 255), "virusmodz", Vector2(width / 2, height / 3.7), 20);
   Vector2 DrawFrom = Vector2(width / 2, height / 2); 
    if (!localPlayer && !ESPRadar) return;

    
    float radarRadius = 100.0f; 
    Vector2 radarCenter = Vector2(width - 120, 120);
    float scale = 29.0f; 

    
    esp.DrawCircle(Color(255, 255, 255, 150), 2.0f, radarRadius, radarCenter);
    esp.DrawFilledCircle(Color(50, 50, 50, 100), radarRadius, radarCenter);

  
    esp.DrawFilledCircle(Color(0, 100, 255, 255), 4.0f, radarCenter);

    float localX = GetPositionX(localPlayer);
    float localY = GetPositionY(localPlayer);

    for (void *player : playerslist) {
        if (player && gethp(player) > 0 || !isdead(player)) {
            // Calculate distance
            float enX = GetPositionX(player);
            float enY = GetPositionY(player);
            
            std::string pid = getPeerID(player);
             
           Vector2 endps = WorldToScreen(player);

            float relX = (enX - localX) / scale;
            float relY = (enY - localY) / scale;

            
            if ((relX * relX + relY * relY) <= (radarRadius * radarRadius)) {
                Vector2 dotPos = Vector2(radarCenter.x + relX, radarCenter.y - relY);
                
                
                if (getTeamId(localPlayer) > 1 && getTeamId(localPlayer) != getTeamId(player)){
                    esp.DrawFilledCircle(Color(255, 0, 0, 255), 4.0f, dotPos); 
                } else if(getTeamId(localPlayer) > 1 && getTeamId(localPlayer) == getTeamId(player)) {
                    esp.DrawFilledCircle(Color(0, 255, 0, 255), 4.0f, dotPos);
                } else{
                    esp.DrawFilledCircle(Color(255, 0, 0, 255), 4.0f, dotPos); 
                }

               
                if (ESPLine) {
                    float angle = getFireAngle(player); 
                    float angleRad = angle * (3.14159265f / 180.0f); 
                    float lineLength = 15.0f; 
                    float endX = dotPos.x + (lineLength * cos(angleRad));
                    float endY = dotPos.y + (lineLength * sin(angleRad));

                    esp.DrawLine(Color(255, 255, 0, 255), 1.5f, dotPos, Vector2(endX, endY));
                }
            
            }
            
            if (plIDS && (relX * relX + relY * relY) <= (radarRadius * radarRadius)){
                Vector2 dotPos = Vector2(radarCenter.x + relX, radarCenter.y - relY);
                esp.DrawText(Color(100, 185, 197, 255), pid.c_str(), dotPos, 20);
            }
  
  
        } else {
            playerslist.erase(player);
        }
    }
}

#include "VirusModz.h"
#include <unordered_set>
#include <cmath> // Added for sin/cos functions

using namespace std;

unordered_set<void *> playerslist;


bool EnableESP, ESPLine, ESPtext, isProxy, plIDS;
int Startpos, Endpos;

float dts;
void* localPlayer = NULL;
 void** g_pWorldLayer; 

void* activatePX = NULL;
std::string namess;

float git;


/*
struct CCPoint {
    float x;
    float y;
};
*/


void* (*sharedDirector_t)();
Vector2 (*convertToUI_t)(void* director, const Vector2& input);




int (*getTeamId)(void* instance); // get players team id like 1 to 7, 1 = solo 

int (*gethp)(void* instance); // get players health max hp 100

bool (*isdead)(void* instance); // chake players dead or not true = dead

float (*getFireAngle)(void* instance); // get enemy fire angle 0 to 360

float (*getRotation)(void* instance); // get enemy rotation angle 0 to 360

bool (*isDucked)(void* instance); // to chake enemy croush or not croush = true

bool (*getThrustFactor)(void* instance); // to chake enemy flying or not

std::string (*getPeerID)(void* instance); // to chake players id

float (*GetPositionY)(void* instance);
float (*GetPositionX)(void* instance);

float damage1;
std::string reason1;
int hitType1;
bool critical1;

std::string any1 = std::to_string(damage1);
std::string any2 = std::to_string(hitType1);
std::string any3 = std::to_string(critical1);



void (*orig_addDamage)(void* instance, float damage, std::string* reason, int hitType, bool critical);
void addDamage(void* instance, float damage, std::string* reason, int hitType, bool critical) {
if (instance != NULL){
damage = damage1;
*reason = reason1;
hitType = hitType1;
critical = critical1;

}
return orig_addDamage(instance, damage, reason, hitType, critical);
}

// class SoldierView and i have SoldierView class update offset 
void (*old_setPlayerName_hook)(void* self, std::string name);
void setPlayerName_hook(void* self, std::string name) {
if (self != NULL){

namess = name;
}
return old_setPlayerName_hook(self, name);
}


void (*old_FRAGNADE)(void *instance, float dt); // granade update offset 
void FRAGNADE(void *instance, float dt) {


    if (instance != NULL) {
    
     
        
    }
    return old_FRAGNADE(instance, dt);
}



// class SoldierRemoteController 
void (*old_EnemyU)(void *instance, float dt); // enemy player update offset 
void EnemyU(void *instance, float dt) {


    if (instance != NULL && gethp(instance) > 0 || !isdead(instance)) {
    
        playerslist.insert(instance);
        
    }
    return old_EnemyU(instance, dt);
}



// class SoldierLocalController 
void (*old_SoldierLocalController)(void* instance, float dt); // my player update offset 
void SoldierLocalController(void* instance, float dt) {
    if (instance != NULL) {
 void* targetBody = *(void **)((char *)instance + 0x148);
           if (targetBody != NULL){
           float targetX = *(float *)((char *)targetBody + 0x2c);
		   float targetY = *(float *)((char *)targetBody + 0x34);
		   
		   float localX = GetPositionX(instance);
           float localY = GetPositionY(instance);
           
        git = localX / targetX;
		   }
  /* void *body = *(void **)((char *)instance + 0x148);
    if (body != NULL) {

            float *getBodyVelocityX = (float *)((char *)body + 0x38);
            float *getBodyVelocityY = (float *)((char *)body + 0x3c);
    } */
        
        localPlayer = instance;
    }
    return old_SoldierLocalController(instance, dt);
}

void (*old_removebody)(void* instance); // this function call when any Player leave the match or game end
void removebody(void* instance){
if (instance){

playerslist.erase(instance);

} 
return old_removebody(instance);
} 


// Add this global variable declaration at the top of DrawingManager.h


bool ESPRadar; // Add this global variable

void DrawESP(AadilDrawing esp, int width, int height) {

std::string any = std::to_string(git);

esp.DrawText(Color(0, 100, 255, 255), any1.c_str(), Vector2(width / 2, height / 3.1), 20);
esp.DrawText(Color(0, 100, 255, 255), reason1.c_str(), Vector2(width / 2, height / 3.3), 20);
esp.DrawText(Color(0, 100, 255, 255), any2.c_str(), Vector2(width / 2, height / 3.5), 20);
esp.DrawText(Color(0, 100, 255, 255), any3.c_str(), Vector2(width / 2, height / 3.7), 20);
//esp.DrawText(Color(0, 100, 255, 255), "virusmodz", Vector2(width / 2, height / 3.7), 20);
    
    if (!localPlayer && !ESPRadar) return;

    // 1. Setup Radar Position (Top Right)
    float radarRadius = 100.0f; 
    Vector2 radarCenter = Vector2(width - 120, 120);
    float scale = 29.0f; // Zoom of the radar

    // 2. Draw Radar Background (Gray Circle)
    esp.DrawCircle(Color(255, 255, 255, 150), 2.0f, radarRadius, radarCenter);
    esp.DrawFilledCircle(Color(50, 50, 50, 100), radarRadius, radarCenter);

    // 3. Draw "You" (Green Dot in center)
    esp.DrawFilledCircle(Color(0, 100, 255, 255), 4.0f, radarCenter);

    float localX = GetPositionX(localPlayer);
    float localY = GetPositionY(localPlayer);

    for (void *player : playerslist) {
        if (player && gethp(player) > 0 || !isdead(player)) {
            // Calculate distance
            float enX = GetPositionX(player);
            float enY = GetPositionY(player);
            
            std::string pid = getPeerID(player);

            float relX = (enX - localX) / scale;
            float relY = (enY - localY) / scale;

            // Check if enemy is within radar circle radius (Pythagoras theorem)
            if ((relX * relX + relY * relY) <= (radarRadius * radarRadius)) {
                Vector2 dotPos = Vector2(radarCenter.x + relX, radarCenter.y - relY);
                
                // Draw Enemy Dot
                if (getTeamId(localPlayer) > 1 && getTeamId(localPlayer) != getTeamId(player)){
                    esp.DrawFilledCircle(Color(255, 0, 0, 255), 4.0f, dotPos); // Red dot for enemy
                } else if(getTeamId(localPlayer) > 1 && getTeamId(localPlayer) == getTeamId(player)) {
                    esp.DrawFilledCircle(Color(0, 255, 0, 255), 4.0f, dotPos);
                } else{
                    esp.DrawFilledCircle(Color(255, 0, 0, 255), 4.0f, dotPos); // Red dot for enemy
                }

                // --- NEW CODE: Radar Line ESP (View Angle) ---
                if (ESPLine) {
                    float angle = getFireAngle(player); // Get 0-360 angle
                    float angleRad = angle * (3.14159265f / 180.0f); // Convert to radians
                    float lineLength = 15.0f; // Length of the view line on radar

                    // Calculate end point of the line
                    // Note: Y is subtracted because screen coordinates Y is down, but game world Y is usually up
                    // We flip the Y component (sin) to match the radar's flipped Y axis
                    float endX = dotPos.x + (lineLength * cos(angleRad));
                    float endY = dotPos.y + (lineLength * sin(angleRad));

                    esp.DrawLine(Color(255, 255, 0, 255), 1.5f, dotPos, Vector2(endX, endY));
                }
                // ---------------------------------------------
            }
            
            if (plIDS && (relX * relX + relY * relY) <= (radarRadius * radarRadius)){
                Vector2 dotPos = Vector2(radarCenter.x + relX, radarCenter.y - relY);
                esp.DrawText(Color(100, 185, 197, 255), pid.c_str(), dotPos, 20);
            }
        } else {
            playerslist.erase(player);
        }
    }
}

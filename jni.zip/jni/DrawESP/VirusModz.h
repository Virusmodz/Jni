#include <jni.h>




class AadilDrawing {
	private:
		JNIEnv *jnienv;
		jobject espview;
		jobject canvas;
		
	public:
		AadilDrawing() {
			jnienv = nullptr;
			espview = nullptr;
			canvas = nullptr;
		}
		
		AadilDrawing(JNIEnv *env, jobject esp, jobject cvs) {
			this->jnienv = env;
			this->espview = esp;
			this->canvas = cvs;
		}
		
		bool isValid() const {
			return (jnienv && espview && canvas);
		}
		
		int getWidth() const {
			if (isValid()) {
				jclass cvs = jnienv->GetObjectClass(canvas);
				jmethodID width = jnienv->GetMethodID(cvs, "getWidth", "()I");
				return jnienv->CallIntMethod(canvas, width);
			}
		}
		
		int getHeight() const {
			if (isValid()) {
				jclass cvs = jnienv->GetObjectClass(canvas);
				jmethodID height = jnienv->GetMethodID(cvs, "getHeight", "()I");
				return jnienv->CallIntMethod(canvas, height);
			}
		}
		
		void DrawLine(Color color, float thickness, Vector2 from, Vector2 to) {
			if (isValid()) {
				jclass cvs = jnienv->GetObjectClass(espview);
				jmethodID drawline = jnienv->GetMethodID(cvs, "DrawLine", "(Landroid/graphics/Canvas;IIIIFFFFF)V");
				jnienv->CallVoidMethod(espview, drawline, canvas, (int)color.a, (int)color.r, (int)color.g, (int)color.b,
				thickness, from.X, from.Y, to.X, to.Y);
			}
		}
		
		void DrawText(Color color, const char *txt, Vector2 pos, float size) {
        if (isValid()) {
            jclass cvs = jnienv->GetObjectClass(espview);
            jmethodID drawtext = jnienv->GetMethodID(cvs, "DrawText",
                                                   "(Landroid/graphics/Canvas;IIIILjava/lang/String;FFF)V");
            jnienv->CallVoidMethod(espview, drawtext, canvas, (int) color.a, (int) color.r,
                                 (int) color.g, (int) color.b,
                                 jnienv->NewStringUTF(txt), pos.X, pos.Y, size);
        }
    }
	// Add these inside the AadilDrawing class in VirusModz.h
void DrawCircle(Color color, float thickness, float radius, Vector2 pos) {
    if (isValid()) {
        jclass cvs = jnienv->GetObjectClass(espview);
        // FIX: Changed FFF to FFFF (4 floats: thickness, radius, x, y)
        jmethodID drawcircle = jnienv->GetMethodID(cvs, "DrawCircle", "(Landroid/graphics/Canvas;IIIIFFFF)V");
        
        if (drawcircle != nullptr) {
            jnienv->CallVoidMethod(espview, drawcircle, canvas, (int)color.a, (int)color.r, (int)color.g, (int)color.b, thickness, radius, pos.X, pos.Y);
        }
    }
}

void DrawFilledCircle(Color color, float radius, Vector2 pos) {
    if (isValid()) {
        jclass cvs = jnienv->GetObjectClass(espview);
        // This takes 3 floats (radius, x, y), so FFF is correct
        jmethodID drawfcircle = jnienv->GetMethodID(cvs, "DrawFilledCircle", "(Landroid/graphics/Canvas;IIIIFFF)V");
        
        if (drawfcircle != nullptr) {
            jnienv->CallVoidMethod(espview, drawfcircle, canvas, (int)color.a, (int)color.r, (int)color.g, (int)color.b, radius, pos.X, pos.Y);
        }
    }
}
};

